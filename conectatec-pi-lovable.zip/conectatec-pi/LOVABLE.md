# ConectaTec PI — guia para o Lovable

**Do primeiro projeto à primeira oportunidade.**

Este projeto é a **versão oficial** do ConectaTec PI, para uso real por escolas, professores, estudantes e empresas do Piauí. **Não existe modo de demonstração:** sem dados fictícios, sem login sem senha e sem botão de restaurar.

## Como o código está organizado

| Pasta | O que é | No Lovable |
|---|---|---|
| `web/` | Interface em React + TypeScript (Vite), com todas as telas, textos, cores e logo | Manter telas, textos e identidade visual |
| `server/src/routes/` | API em Node/Express com **todas as regras de negócio e permissões** | Recriar no backend do Lovable (banco + políticas RLS + funções) |
| `server/migrations/` | Banco PostgreSQL completo (tabelas, status, restrições) e a lista de cursos | Usar como esquema do banco |
| `server/test/flow.test.mjs` | Teste do fluxo completo e dos bloqueios de permissão | Usar como lista de verificação |

## Regras que não podem se perder na reconstrução

**Contas e acesso**
1. **O estudante não se cadastra sozinho.** Só a escola cria contas de estudantes, uma a uma ou em lote (`Nome; matrícula`). O sistema gera um usuário e uma senha temporária.
2. O estudante entra com **usuário** (sem e-mail). Na autenticação do Lovable, use um e-mail interno gerado pelo sistema (por exemplo `usuario@alunos.conectatec.internal`) e mostre na tela só o usuário.
3. Senha temporária obriga a troca no primeiro acesso, para todos os perfis.
4. **Escolas e empresas pedem acesso** e ficam *pendentes* até a aprovação do administrador. Enquanto estiverem pendentes, a escola não cadastra pessoas e a empresa não submete demandas.
5. O primeiro administrador é criado pelo dono da plataforma, nunca por cadastro público.

**Os 5 perfis:** `admin`, `school` (gestor), `teacher` (professor-orientador), `student` e `company`.

**Fluxo:** demanda da empresa → moderação do admin → análise pedagógica do professor → autorização da escola → equipe e cronograma → entrega → validação do professor → retorno da empresa → portfólio e certificado.

**Proteção dos estudantes (14 a 18 anos)**
- **A empresa nunca vê nomes nem dados de estudantes.** Ela vê só "equipe de N estudantes", escola, turma e curso, e não pode pesquisar estudantes.
- A empresa só vê o projeto **depois da autorização da escola** e só vê o resultado **depois da validação do professor**.
- Só entram na equipe estudantes com **autorização do responsável** registrada pela escola.
- **Não existe chat privado.** A comunicação acontece só no mural do projeto, visível para o professor e a escola, que podem ocultar mensagens. Telefones e e-mails escritos no mural são trocados por `[contato removido]` e geram uma sinalização.
- O interesse da empresa em futuras oportunidades vai para a **escola**, nunca para o estudante.
- O portfólio público só aparece se a **escola autorizar** e o **estudante quiser**. Mostra só o nome abreviado (ex.: "Ana C.").

**Permissões, em todas as tabelas, com RLS**
- A escola só vê e gerencia a própria escola.
- O professor só vê as próprias turmas.
- O estudante só vê os projetos em que está na equipe.
- A empresa só vê as próprias demandas e os projetos ligados a elas.
- O admin vê tudo.

**Sem competição:** não há ranking, notas, pontuação nem premiação. O retorno da empresa é por critério, com três opções: "Atendeu", "Atendeu parcialmente" ou "Ainda em desenvolvimento".

**Anexos:** PDF, PNG, JPG ou ZIP, até 5 MB, guardados em armazenamento **privado**. Só a equipe, o professor, a escola e, depois da validação, a empresa podem baixar.

**LGPD**
- Coleta mínima: o estudante não informa e-mail, telefone nem documentos.
- Registro de ações (`audit_log`): login, recusas, decisões, entregas, downloads e alterações.
- Cada pessoa baixa os próprios dados e pode pedir correção, remoção ou exclusão. Os pedidos de estudantes e professores vão para a escola; os demais, para o admin.
- Política de Privacidade (`/privacidade`) e Termos (`/termos`) são **modelos** e precisam de revisão jurídica.
- A plataforma não afirma conformidade jurídica completa.

**Cursos técnicos:** Informática, Desenvolvimento de Sistemas, Informática para Internet, Redes de Computadores e **Marketing Digital**. O admin pode cadastrar outros.

**Identidade visual:** verde-escuro `#0A3D2E`, petróleo, branco e dourado, com fontes Bricolage Grotesque e Figtree. A logo fica em `web/public/logo.jpg` e `web/src/assets/`.

## Antes de abrir para estudantes reais
- [ ] Autorização da SEDUC-PI ou da escola.
- [ ] Responsável pelos dados e encarregado (DPO) definidos.
- [ ] Privacidade e Termos revisados pela assessoria jurídica.
- [ ] Termo de autorização dos responsáveis definido.
- [ ] Backup do banco ativo.
