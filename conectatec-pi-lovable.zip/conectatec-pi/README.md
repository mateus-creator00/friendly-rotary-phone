# ConectaTec PI

**Do primeiro projeto à primeira oportunidade.**

Plataforma que conecta escolas estaduais de tempo integral do Piauí a empresas piauienses. Demandas reais das empresas viram **projetos pedagógicos colaborativos**, desenvolvidos por estudantes dos cursos técnicos durante as atividades escolares, sob supervisão dos professores.

- **A escola é o centro:** não existe cadastro independente de estudantes. A escola habilita as contas, o professor avalia cada demanda e a coordenação autoriza a participação.
- **Sem competição:** não há desafios, rankings, pontuação competitiva ou premiação por colocação.
- **Proteção dos estudantes (14 a 18 anos):** empresas nunca veem nomes nem dados pessoais e não podem pesquisar estudantes. Não existe chat privado.

Tecnologia: React + TypeScript (Vite, instalável como PWA), Node.js + Express e PostgreSQL. Autenticação por sessão, autorização por perfil verificada no servidor, validação com Zod e anexos protegidos no banco.


> **Para importar no Lovable:** leia `LOVABLE.md` e cole o texto de `PROMPT-LOVABLE.txt` no primeiro pedido.

---

## 1. Fluxo principal

1. A **empresa verificada** submete uma demanda empresarial: necessidade, objetivos, resultados esperados, tecnologias, prazo sugerido e critérios.
2. A **administração** verifica a empresa e modera a demanda. Pode pedir redimensionamento quando o pedido substituiria trabalho remunerado.
3. O **professor-orientador** abre a demanda para uma turma e registra a análise pedagógica: relevância, segurança, viabilidade e conteúdo curricular.
4. A **coordenação da escola** autoriza, devolve ou não autoriza a participação da turma.
5. O professor **organiza a equipe colaborativa** e o cronograma. Só entram estudantes com autorização do responsável registrada pela escola.
6. A equipe desenvolve o projeto e **entrega pela plataforma**. Cada entrega tem versões, link e anexo (PDF, PNG, JPG ou ZIP, até 5 MB).
7. O professor **valida a entrega** e registra as competências desenvolvidas, ou pede ajustes.
8. A **empresa dá o retorno** por critério ("Atendeu", "Atendeu parcialmente" ou "Ainda em desenvolvimento"), sem notas. Também pode manifestar interesse em futuras oportunidades: a mensagem vai para a escola, nunca para os estudantes.
9. O projeto entra no **portfólio educacional** de cada integrante, com certificado verificável por código. O portfólio só fica público se a escola autorizar e o estudante quiser.
10. **Etapa futura:** banco de vagas reais de empresas verificadas, moderadas e acompanhadas pela escola.

Toda a comunicação do projeto acontece no **mural**. O professor e a escola acompanham as mensagens e podem ocultá-las. Telefones e e-mails são removidos automaticamente e geram sinalização.

## 2. Perfis

| Perfil | Principais telas |
|---|---|
| Escola / gestor | Painel com autorizações pendentes, pedidos de correção e interesse de empresas. Turmas e pessoas: professores, turmas, estudantes um a um ou em lote, autorização dos responsáveis, permissão de portfólio público, nova senha e desativação. Projetos e relatórios com registro de ações. |
| Professor-orientador | Painel com pendências; catálogo de demandas; página do projeto com parecer, equipe e cronograma, validação e mediação do mural; turmas. |
| Estudante | Atividades autorizadas, página do projeto com entregas e cronograma, portfólio e certificado, oportunidades, conta. |
| Empresa | Painel com demandas e projetos autorizados, já sem nomes de estudantes; nova demanda; retorno do resultado; vagas; perfil. |
| Administração | Visão geral e indicadores; aprovação de escolas e empresas; moderação de demandas e vagas; permissões; registros de acesso, sinalizações e pedidos. |


## 3. Segurança e privacidade implementadas

- Senhas com bcrypt. Senhas temporárias exigem troca no primeiro acesso, e trocar a senha encerra as outras sessões.
- Sessões no banco, com cookie `HttpOnly`, `SameSite=Lax` e `Secure` em produção. Expiram em 8 h.
- Proteção contra CSRF, limite de tentativas de login e de cadastro, e cabeçalhos de segurança (Helmet/CSP).
- Permissão verificada em cada rota:
  - a escola só gerencia a própria escola;
  - o professor só vê as próprias turmas;
  - a empresa só vê projetos das suas demandas e só depois da autorização da escola;
  - a empresa só vê o resultado depois da validação do professor.
- Coleta mínima de dados: estudantes não informam e-mail, telefone ou documentos.
- Anexos validados pelo conteúdo real do arquivo, guardados no banco e baixados apenas por quem tem permissão.
- Registro de acessos e ações relevantes: login, tentativas recusadas, decisões, entregas, downloads, alterações de cadastro e exportação de dados.
- Direitos do titular: cada pessoa baixa os próprios dados e pede correção, remoção ou exclusão. Estudantes e professores são atendidos pela escola; os demais, pela administração.

## 4. Limitações conhecidas e próximas etapas

- Não há recuperação de senha por e-mail, porque isso exige um serviço de envio. Por enquanto, a escola ou a administração gera uma senha temporária.
- Não há integração com os sistemas da SEDUC-PI (login institucional e importação de turmas). Fica para uma próxima etapa.
- Os anexos ficam no próprio banco. Com volume alto, migre para um serviço de arquivos (S3 ou similar).
- Notificações por e-mail e o banco de vagas completo também ficam para uma próxima etapa.
