export type Role = 'admin' | 'school' | 'teacher' | 'student' | 'company';

export const SLOGAN = 'Do primeiro projeto à primeira oportunidade.';

/** Etapas do projeto colaborativo, na ordem do fluxo institucional. */
export const FLOW: [string, string][] = [
  ['analise_pedagogica', 'Análise pedagógica'],
  ['aguardando_coordenacao', 'Autorização da escola'],
  ['aprovado', 'Organização da equipe'],
  ['em_andamento', 'Desenvolvimento'],
  ['entregue', 'Validação pedagógica'],
  ['validado', 'Retorno da empresa'],
  ['concluido', 'Concluído'],
];
export const P_STATUS: Record<string, [string, string]> = {
  analise_pedagogica: ['Em análise pelo professor', 'st-pend'],
  aguardando_coordenacao: ['Aguardando autorização da escola', 'st-pend'],
  nao_adequada: ['Considerada inadequada', 'st-bad'],
  nao_autorizado: ['Não autorizada pela escola', 'st-bad'],
  aprovado: ['Autorizado — organizando equipe', 'st-prog'],
  em_andamento: ['Em desenvolvimento', 'st-prog'],
  entregue: ['Entregue — em validação', 'st-sent'],
  validado: ['Validado — aguardando a empresa', 'st-eval'],
  concluido: ['Concluído', 'st-done'],
};
export const D_PHASE: Record<string, [string, string]> = {
  disponivel: ['Disponível para escolas', 'st-avail'], em_projeto: ['Em projeto', 'st-prog'], concluida: ['Concluída', 'st-done'],
  pendente: ['Aguardando moderação', 'st-pend'], ajustes: ['Ajustes solicitados', 'st-sent'], rejeitada: ['Rejeitada', 'st-bad'], encerrada: ['Encerrada', 'st-bad'],
};
export const ORG_STATUS: Record<string, [string, string]> = {
  aprovada: ['Verificada', 'st-done'], pendente: ['Em verificação', 'st-pend'], ajustes: ['Ajustes solicitados', 'st-sent'], rejeitada: ['Rejeitada', 'st-bad'],
};
export const OPP_STATUS: Record<string, [string, string]> = {
  publicada: ['Vaga verificada', 'st-done'], pendente: ['Aguardando moderação', 'st-pend'], ajustes: ['Ajustes solicitados', 'st-sent'], encerrada: ['Encerrada', 'st-bad'], rejeitada: ['Rejeitada', 'st-bad'],
};
export const CONSENT: Record<string, [string, string]> = {
  pendente: ['Autorização pendente', 'st-pend'], registrado: ['Autorização registrada', 'st-done'], nao_aplica: ['Maior de 18 anos', 'st-avail'],
};
export const LEVEL: Record<string, string> = { atendeu: 'Atendeu', parcial: 'Atendeu parcialmente', em_desenvolvimento: 'Ainda em desenvolvimento' };
export const ROLE_LABEL: Record<Role, string> = { admin: 'Administração da plataforma', school: 'Escola / gestão', teacher: 'Professor(a)-orientador(a)', student: 'Estudante', company: 'Empresa' };
export const YEARS = ['1ª série', '2ª série', '3ª série'];
export const HOME: Record<Role, string> = { admin: '/admin', school: '/escola', teacher: '/professor', student: '/estudante', company: '/empresa' };
export const REQ_KIND: Record<string, string> = { correcao: 'Correção de dados', remocao: 'Remoção de informação', exclusao_conta: 'Exclusão da conta' };

export function fmtDate(s?: string | null) {
  if (!s) return '—';
  const d = new Date(s.length === 10 ? s + 'T12:00:00' : s);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
}
export function fmtDT(s: string) {
  const d = new Date(s);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }) + ' · ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}
export function daysLeft(s: string) { return Math.ceil((new Date(s + 'T23:59:59').getTime() - Date.now()) / 864e5); }
export function pct(a: number, b: number) { return b ? Math.round((a / b) * 100) : 0; }
export function initials(n: string) { const p = String(n || '').trim().split(/\s+/); return ((p[0] || '')[0] || '') + ((p[1] || '')[0] || ''); }
export function firstName(n: string) { return String(n || '').trim().split(/\s+/)[0]; }
export function plusDays(n: number) { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); }
export function size(bytes: number) { return bytes < 1024 * 1024 ? Math.max(1, Math.round(bytes / 1024)) + ' KB' : (bytes / 1024 / 1024).toFixed(1).replace('.', ',') + ' MB'; }
