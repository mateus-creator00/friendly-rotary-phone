import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import './styles.css';
import { AuthProvider, useAuth } from './auth';
import { UiProvider } from './ui';
import { PublicLayout, AppShell, Adaptive, RequireRole, Splash } from './layout';
import { Home, ComoFunciona, Privacidade, Termos, CertificateVerify, PublicPortfolio, NotFound } from './pages/public';
import { Login, CadEscola, CadEmpresa, ChangePassword } from './pages/auth';
import { Catalog, DemandDetail } from './pages/demands';
import { ProjectPage } from './pages/project';
import { Opportunities } from './pages/opportunities';
import { StPainel, StPortfolio } from './pages/student';
import { PfPainel, PfTurmas } from './pages/teacher';
import { EscPainel, EscProjetos, EscPessoas, EscRelatorios } from './pages/school';
import { EmPainel, EmDemandaForm, EmOportunidades, EmPerfil } from './pages/company';
import { AdPainel, AdCadastros, AdDemandas, AdUsuarios, AdRegistros } from './pages/admin';
import { Conta } from './pages/account';

const R = (roles: any[], el: React.ReactNode) => <RequireRole roles={roles}>{el}</RequireRole>;

function App() {
  const { ready } = useAuth();
  if (!ready) return <Splash />;
  return <Routes>
    <Route element={<PublicLayout />}>
      <Route path="/" element={<Home />} />
      <Route path="/como-funciona" element={<ComoFunciona />} />
      <Route path="/privacidade" element={<Privacidade />} />
      <Route path="/termos" element={<Termos />} />
      <Route path="/entrar" element={<Login />} />
      <Route path="/cadastro/escola" element={<CadEscola />} />
      <Route path="/cadastro/empresa" element={<CadEmpresa />} />
      <Route path="/certificado" element={<CertificateVerify />} />
      <Route path="/certificado/:code" element={<CertificateVerify />} />
      <Route path="/p/:slug" element={<PublicPortfolio />} />
      <Route path="/trocar-senha" element={<ChangePassword />} />
    </Route>
    <Route element={<Adaptive />}>
      <Route path="/demandas" element={<Catalog />} />
      <Route path="/demandas/:id" element={<DemandDetail />} />
      <Route path="/oportunidades" element={<Opportunities />} />
    </Route>
    <Route element={<AppShell />}>
      <Route path="/conta" element={<Conta />} />
      <Route path="/projetos/:id" element={<ProjectPage />} />
      <Route path="/estudante" element={R(['student'], <StPainel />)} />
      <Route path="/estudante/portfolio" element={R(['student'], <StPortfolio />)} />
      <Route path="/professor" element={R(['teacher'], <PfPainel />)} />
      <Route path="/professor/turmas" element={R(['teacher'], <PfTurmas />)} />
      <Route path="/escola" element={R(['school'], <EscPainel />)} />
      <Route path="/escola/projetos" element={R(['school'], <EscProjetos />)} />
      <Route path="/escola/pessoas" element={R(['school'], <EscPessoas />)} />
      <Route path="/escola/relatorios" element={R(['school'], <EscRelatorios />)} />
      <Route path="/empresa" element={R(['company'], <EmPainel />)} />
      <Route path="/empresa/nova-demanda" element={R(['company'], <EmDemandaForm />)} />
      <Route path="/empresa/demandas/:id/editar" element={R(['company'], <EmDemandaForm />)} />
      <Route path="/empresa/oportunidades" element={R(['company'], <EmOportunidades />)} />
      <Route path="/empresa/perfil" element={R(['company'], <EmPerfil />)} />
      <Route path="/admin" element={R(['admin'], <AdPainel />)} />
      <Route path="/admin/cadastros" element={R(['admin'], <AdCadastros />)} />
      <Route path="/admin/demandas" element={R(['admin'], <AdDemandas />)} />
      <Route path="/admin/usuarios" element={R(['admin'], <AdUsuarios />)} />
      <Route path="/admin/registros" element={R(['admin'], <AdRegistros />)} />
    </Route>
    <Route element={<PublicLayout />}><Route path="*" element={<NotFound />} /></Route>
  </Routes>;
}

function ScrollTop() {
  const { pathname } = useLocation();
  React.useEffect(() => { window.scrollTo({ top: 0 }); }, [pathname]);
  return null;
}

const Router = BrowserRouter;
createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Router>
      <AuthProvider><UiProvider><ScrollTop /><App /></UiProvider></AuthProvider>
    </Router>
  </React.StrictMode>,
);

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => {}); });
}
