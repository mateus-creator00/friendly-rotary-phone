/** Endereço completo de uma rota do aplicativo (para copiar links). */
export function appUrl(path: string) {
  return location.origin + path;
}
