import React from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { get, post, put } from '../api';
import { useAuth } from '../auth';
import { fmtDate, plusDays } from '../lib';
import { Icon, Kpi, Empty, Note, PageHead, StatusPill, DemandPill, OrgPill, OppPill, DemoTag, useLoad, Loaded, Form, Field, Input, Select, Textarea, Check, Submit, ActionButton, useUi } from '../ui';

function Banner({ c }: { c: any }) {
  if (!c || c.status === 'aprovada') return null;
  const m: Record<string, ['warn' | 'danger', string]> = {
    pendente: ['warn', 'O cadastro está em verificação pela administração da plataforma. Você poderá submeter demandas após a aprovação.'],
    ajustes: ['warn', 'A administração pediu ajustes no cadastro: ' + (c.note || '') + ' Atualize o perfil para reenviar.'],
    rejeitada: ['danger', 'O cadastro não foi aprovado: ' + (c.note || '') + ' Você pode corrigir o perfil e reenviar.'],
  };
  const [k, t] = m[c.status];
  return <div style={{ marginBottom: 16 }}><Note kind={k} icon="alert">{t} {c.status !== 'pendente' && <Link to="/empresa/perfil">Abrir perfil</Link>}</Note></div>;
}

export function EmPainel() {
  const { toast } = useUi();
  const s = useLoad(() => get('/company/dashboard'), []);
  return <Loaded s={s}>{(d: any) => {
    const toFeedback = d.projects.filter((p: any) => p.status === 'validado');
    return <>
      <PageHead title={d.company.name} eyebrow={<>Área da empresa · {d.company.sector} <DemoTag on={d.company.isDemo} /></>} actions={d.company.status === 'aprovada' ? <Link className="btn btn-primary" to="/empresa/nova-demanda"><Icon name="plus" /> Submeter demanda</Link> : <OrgPill s={d.company.status} />} />
      <Banner c={d.company} />
      <div className="grid g4" style={{ marginBottom: 20 }}>
        <Kpi n={d.demands.filter((x: any) => x.status === 'disponivel').length} l="Demandas disponíveis" s={d.demands.filter((x: any) => x.status === 'pendente').length + ' em moderação'} />
        <Kpi n={d.analysing} l="Em análise por escolas" s="pareceres e autorizações" />
        <Kpi n={d.projects.filter((p: any) => p.status !== 'concluido').length} l="Projetos autorizados" s="em andamento" />
        <Kpi n={toFeedback.length} l="Aguardando seu retorno" s="entregas validadas" />
      </div>
      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="check" /> Aguardando seu retorno</h3></div>
            {toFeedback.length ? <ul className="list">{toFeedback.map((p: any) => <li key={p.id}><div className="grow"><b>{p.title}</b><div className="small muted">{p.school} · {p.turma}</div></div><Link className="btn btn-primary btn-sm" to={'/projetos/' + p.id}>Avaliar resultado</Link></li>)}</ul>
              : <p className="panel-b small muted">Quando o professor validar uma entrega, ela aparece aqui para o seu retorno.</p>}</div>
          <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Projetos autorizados pelas escolas</h3></div>
            {d.projects.length ? <ul className="list">{d.projects.map((p: any) => <li key={p.id}><div className="grow stack-sm"><div className="row between"><b>{p.title}</b><StatusPill s={p.status} /></div>
              <span className="small muted">{p.school} · {p.turma} · equipe de {p.teamSize} estudante(s) <DemoTag on={p.isDemo} /></span>
              {p.milestonesTotal > 0 && <div className="row" style={{ flexWrap: 'nowrap' }}><div className="meter" style={{ flex: 1 }}><span style={{ width: (p.milestonesDone / p.milestonesTotal) * 100 + '%' }} /></div><span className="small muted">{p.milestonesDone}/{p.milestonesTotal} etapas</span></div>}
              <div><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}><Icon name="msg" /> Acompanhar e orientar</Link></div></div></li>)}</ul>
              : <Empty icon="folder" title="Nenhum projeto autorizado ainda" text="Depois da análise pedagógica e da autorização da escola, os projetos aparecem aqui." />}</div>
        </div>
        <div className="panel"><div className="panel-h"><h3><Icon name="brief" /> Suas demandas</h3></div>
          {d.demands.length ? <ul className="list">{d.demands.map((x: any) => <li key={x.id}><div className="grow stack-sm"><div className="row between"><b>{x.title}</b><DemandPill s={x.phase} /></div>
            <span className="small muted">{x.area} · ~{x.hours} h · até {x.maxProjects} turma(s) · {x.activeCount} em andamento · {x.concludedCount} concluído(s)</span>
            {x.modNote && <span className="small" style={{ color: 'var(--warn)' }}>Administração: {x.modNote}</span>}
            <div className="row">{['pendente', 'ajustes'].includes(x.status) ? <Link className="btn btn-ghost btn-sm" to={`/empresa/demandas/${x.id}/editar`}>Editar e reenviar</Link> : <Link className="btn btn-ghost btn-sm" to={'/demandas/' + x.id}>Ver demanda</Link>}
              {x.status === 'disponivel' && <ActionButton action={async () => { await post(`/company/demands/${x.id}/close`); toast('Demanda encerrada para novas turmas.'); s.reload(true); }}>Encerrar para novas turmas</ActionButton>}</div></div></li>)}</ul>
            : <Empty icon="brief" title="Nenhuma demanda" text="Descreva uma necessidade real, de escopo limitado, para que escolas avaliem." />}</div>
      </div></>;
  }}</Loaded>;
}

export function EmDemandaForm() {
  const { id } = useParams();
  const nav = useNavigate();
  const { toast } = useUi();
  const { company } = useAuth();
  const courses = useLoad(() => get<any[]>('/public/courses'), []);
  const ex = useLoad(() => (id ? get(`/demands/${id}`) : Promise.resolve(null)), [id]);
  const ok = company?.status === 'aprovada';
  if (id && ex.loading) return <Loaded s={ex}>{() => null}</Loaded>;
  const d: any = ex.data || {};
  return <><PageHead title={id ? 'Editar demanda' : 'Submeter demanda empresarial'} eyebrow={id ? 'Reenviar para moderação' : 'Nova demanda'} back={['/empresa', 'Área da empresa']} />
    {!ok && <div style={{ marginBottom: 16 }}><Note kind="warn" icon="alert">A empresa precisa estar verificada para submeter demandas.</Note></div>}
    {id && d.modNote && <div style={{ marginBottom: 16 }}><Note kind="warn">Observação da administração: {d.modNote}</Note></div>}
    <div className="card" style={{ maxWidth: 920 }}><Form onSubmit={async (fd) => {
      const body: any = Object.fromEntries(['title', 'need', 'objectives', 'expectedResults', 'techs', 'area', 'suggestedDeadline', 'hours', 'maxProjects', 'criteria'].map((k) => [k, String(fd.get(k) || '')]));
      body.scopeDeclared = fd.get('scopeDeclared') === 'true';
      if (id) await put(`/company/demands/${id}`, body); else await post('/company/demands', body);
      toast('Demanda enviada para moderação. Depois, ela é encaminhada às escolas.'); nav('/empresa');
    }}>
      <Note icon="info">A demanda vira um projeto pedagógico colaborativo: a escola avalia, o professor organiza e a turma desenvolve nas aulas. Descreva uma necessidade real, com escopo limitado e adequado a estudantes do ensino médio técnico.</Note>
      <Field name="title" label="Título" required><Input name="title" type="text" maxLength={100} defaultValue={d.title} req placeholder="Ex.: Página de agendamento para barbearia" /></Field>
      <Field name="need" label="Necessidade" hint="qual problema real a empresa enfrenta" required><Textarea name="need" maxLength={1500} defaultValue={d.need} req /></Field>
      <div className="grid g2">
        <Field name="objectives" label="Objetivos" required><Textarea name="objectives" maxLength={800} defaultValue={d.objectives} req style={{ minHeight: 90 }} /></Field>
        <Field name="expectedResults" label="Resultados esperados" required><Textarea name="expectedResults" maxLength={800} defaultValue={d.expectedResults} req style={{ minHeight: 90 }} /></Field>
        <Field name="techs" label="Tecnologias" hint="separe por vírgulas" required><Input name="techs" type="text" defaultValue={d.techs?.join(', ')} req placeholder="HTML, CSS, Figma…" /></Field>
        <Field name="area" label="Área técnica" required><Select name="area" defaultValue={d.area || ''} req><option value="">Selecione</option>{courses.data?.map((c) => <option key={c.id}>{c.name}</option>)}</Select></Field>
        <Field name="suggestedDeadline" label="Prazo sugerido" hint="mínimo de 14 dias; a escola define o cronograma" required><Input name="suggestedDeadline" type="date" min={plusDays(14)} defaultValue={d.suggestedDeadline} req /></Field>
        <Field name="hours" label="Carga estimada (horas)" hint="de 4 a 80 horas" required><Input name="hours" type="number" min={4} max={80} defaultValue={d.hours || 20} req /></Field>
        <Field name="maxProjects" label="Turmas que a empresa consegue acompanhar" hint="de 1 a 5" required><Input name="maxProjects" type="number" min={1} max={5} defaultValue={d.maxProjects || 1} req /></Field>
      </div>
      <Field name="criteria" label="Critérios de avaliação do resultado" hint="um por linha, de 2 a 6 (sem notas: a empresa indica se cada critério foi atendido)" required><Textarea name="criteria" defaultValue={d.criteria?.join('\n') || 'Atende à necessidade descrita\nQualidade técnica\nClareza da apresentação'} req style={{ minHeight: 90 }} /></Field>
      <Check name="scopeDeclared" req="Confirme a declaração de escopo.">Declaro que a demanda tem escopo limitado, finalidade pedagógica e não substitui empregados ou serviços profissionais remunerados. Se o resultado for usado comercialmente, firmaremos acordo com a escola. *</Check>
      <div className="row"><Submit disabled={!ok}><Icon name="send" /> Enviar para moderação</Submit><Link className="btn btn-ghost" to="/empresa">Cancelar</Link></div>
    </Form></div></>;
}

export function EmOportunidades() {
  const { company } = useAuth();
  const { toast } = useUi();
  const s = useLoad(() => get<any[]>('/opportunities'), []);
  const ok = company?.status === 'aprovada';
  return <><PageHead title="Vagas reais (etapa futura)" eyebrow="Banco de oportunidades" />
    <div style={{ marginBottom: 16 }}><Note>Divulgue apenas vagas reais. Elas passam por moderação e são acompanhadas pela escola. A empresa vê quantos estudantes registraram interesse, mas não os nomes: a seleção segue o seu processo seletivo, com mediação institucional.</Note></div>
    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,420px),1fr))', alignItems: 'start' }}>
      <div className="card">{ok ? <Form onSubmit={async (fd, form) => {
        await post('/company/opportunities', Object.fromEntries(['title', 'area', 'city', 'requirements', 'description', 'workload', 'selectionInfo'].map((k) => [k, String(fd.get(k) || '')])));
        form.reset(); toast('Vaga enviada para moderação.'); s.reload(true);
      }}>
        <h3>Divulgar vaga</h3>
        <Field name="title" label="Cargo" required><Input name="title" type="text" maxLength={90} req placeholder="Jovem Aprendiz — Suporte de TI" /></Field>
        <div className="grid g2"><Field name="area" label="Área" required><Input name="area" type="text" maxLength={50} req /></Field><Field name="city" label="Município" required><Input name="city" type="text" maxLength={60} req /></Field></div>
        <Field name="workload" label="Carga horária" required><Input name="workload" type="text" maxLength={60} req placeholder="20 h semanais" /></Field>
        <Field name="requirements" label="Requisitos" hint="separe por vírgulas" required><Input name="requirements" type="text" req /></Field>
        <Field name="description" label="Atividades" hint="mínimo de 30 caracteres" required><Textarea name="description" maxLength={1000} req /></Field>
        <Field name="selectionInfo" label="Processo seletivo" hint="como será feita a seleção, com acompanhamento da escola" required><Textarea name="selectionInfo" maxLength={400} req style={{ minHeight: 70 }} /></Field>
        <div><Submit><Icon name="send" /> Enviar para moderação</Submit></div>
      </Form> : <Note kind="warn" icon="alert">A empresa precisa estar verificada.</Note>}</div>
      <div className="panel"><div className="panel-h"><h3>Suas vagas</h3></div>
        <Loaded s={s}>{(list) => { const mine = list.filter((o) => o.mine); return mine.length ? <ul className="list">{mine.map((o) => <li key={o.id}><div className="grow stack-sm"><div className="row"><b>{o.title}</b><OppPill s={o.status} /></div><span className="small muted">{o.area} · {o.city} · {o.interestCount ?? 0} estudante(s) com interesse</span>{o.modNote && <span className="small" style={{ color: 'var(--warn)' }}>{o.modNote}</span>}</div>
          {o.status === 'publicada' && <ActionButton action={async () => { await post(`/company/opportunities/${o.id}/close`); toast('Vaga encerrada.'); s.reload(true); }}>Encerrar</ActionButton>}</li>)}</ul>
          : <Empty icon="brief" title="Nenhuma vaga cadastrada" text="Use o formulário para divulgar uma vaga real." />; }}</Loaded></div>
    </div></>;
}

export function EmPerfil() {
  const { refresh } = useAuth();
  const { toast } = useUi();
  const s = useLoad(() => get('/company/dashboard'), []);
  return <><PageHead title="Perfil da empresa" eyebrow="Cadastro empresarial" />
    <Loaded s={s}>{(d: any) => { const c = d.company; return <><Banner c={c} />
      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="card"><Form onSubmit={async (fd) => {
          const r = await put('/company/profile', Object.fromEntries(['name', 'sector', 'city', 'description', 'responsibleName'].map((k) => [k, String(fd.get(k) || '')])));
          await refresh(); s.reload(true); toast(r.resent ? 'Perfil atualizado e reenviado para verificação.' : 'Perfil atualizado.');
        }}>
          <div className="row between"><h3>Dados da empresa</h3><OrgPill s={c.status} /></div>
          <Field name="name" label="Nome" required><Input name="name" type="text" defaultValue={c.name} req /></Field>
          <Field name="sector" label="Setor" required><Input name="sector" type="text" defaultValue={c.sector} req /></Field>
          <Field name="city" label="Município" required><Input name="city" type="text" defaultValue={c.city} req /></Field>
          <Field name="responsibleName" label="Responsável pelas demandas" required><Input name="responsibleName" type="text" defaultValue={c.responsibleName} req /></Field>
          <Field name="description" label="Descrição" required><Textarea name="description" defaultValue={c.description} req /></Field>
          <div><Submit><Icon name="check" /> Salvar</Submit></div>
        </Form></div>
        <div className="card stack-sm"><h3><Icon name="shield" /> Compromissos da empresa</h3><ul className="small muted" style={{ margin: 0, paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <li>Comunicação somente no mural do projeto, acessível ao professor.</li><li>Nenhum contato privado com estudantes.</li><li>Sem acesso a nomes ou dados pessoais dos estudantes.</li>
          <li>Demandas de escopo limitado, que não substituem trabalho remunerado.</li><li>Feedback construtivo, sem notas competitivas.</li><li>Interesse em oportunidades é comunicado à escola, nunca diretamente aos estudantes.</li></ul></div>
      </div></>; }}</Loaded></>;
}
