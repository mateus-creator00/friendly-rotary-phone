import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { get, post, api } from '../api';
import { useAuth } from '../auth';
import { HOME, LEVEL, ROLE_LABEL, fmtDate, fmtDT, initials, plusDays, size } from '../lib';
import { ApiLink, Icon, Empty, Note, PageHead, StatusPill, ConsentPill, DemoTag, Flow, useLoad, Loaded, Form, Field, Input, Textarea, Check, Submit, FieldError, ActionButton, useUi, ExtLink } from '../ui';

type P = any;

export function ReviewBlock({ r }: { r: any }) {
  const label = r.kind === 'ajustes' ? ['Ajustes solicitados', 'chip-warn'] : r.kind === 'validacao' ? ['Validação pedagógica', 'chip-petrol'] : ['Retorno da empresa', 'chip-gold'];
  return <div className="card stack-sm" style={{ boxShadow: 'none', padding: 14 }}>
    <div className="row between"><div className="row"><b className="small">{r.author}</b><span className={'chip ' + label[1]}>{label[0]}</span></div><span className="small muted">{fmtDate(r.createdAt)}</span></div>
    {r.criteria && <div className="small stack-sm" style={{ gap: 2 }}>{Object.entries(r.criteria).map(([k, v]) => <div key={k}>{k}: <b>{LEVEL[v as string]}</b></div>)}</div>}
    {r.competencies?.length > 0 && <div className="row">{r.competencies.map((c: string) => <span key={c} className="chip chip-petrol"><Icon name="check" /> {c}</span>)}</div>}
    <p className="small" style={{ whiteSpace: 'pre-wrap' }}>{r.text}</p></div>;
}

function Mural({ p }: { p: P }) {
  const { toast } = useUi();
  const s = useLoad(() => get(`/projects/${p.id}/posts`), [p.id]);
  const open = p.status !== 'concluido' || p.access === 'teacher' || p.access === 'school';
  return <div className="panel"><div className="panel-h"><h3><Icon name="msg" /> Mural do projeto</h3><span className="chip"><Icon name="eye" /> Visível ao professor responsável</span></div><div className="panel-b">
    {s.loading && !s.data ? <div className="skel" style={{ height: 80 }} /> : s.error ? <p className="err">{s.error}</p> :
      s.data.posts.length ? s.data.posts.map((m: any) => <div key={m.id} className="post" style={m.hidden ? { opacity: .55 } : undefined}>
        <span className={'avatar ' + ({ teacher: 't', company: 'c', admin: 'a', school: 'a' } as any)[m.role]}>{initials(m.author)}</span>
        <div className="minw0" style={{ flex: 1 }}><div className="small"><b>{m.author}</b> <span className="muted">· {ROLE_LABEL[m.role as keyof typeof ROLE_LABEL]} · {fmtDT(m.createdAt)}</span> {m.masked && <span className="chip chip-warn">contato ocultado</span>} {m.hidden && <span className="chip chip-danger">oculta pela mediação</span>}</div>
          <p style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{m.text}</p></div>
        {s.data.canModerate && <ActionButton className="btn btn-ghost btn-sm" action={async () => { const r = await post(`/posts/${m.id}/hide`); toast(r.hidden ? 'Mensagem ocultada.' : 'Mensagem exibida novamente.'); s.reload(true); }}>{m.hidden ? 'Reexibir' : 'Ocultar'}</ActionButton>}
      </div>) : <Empty icon="msg" title="Nenhuma mensagem ainda" text="Use o mural para orientações, dúvidas e combinados do projeto." />}
    {open && <Form className="stack-sm" onSubmit={async (fd, form) => {
      const r = await post(`/projects/${p.id}/posts`, { text: String(fd.get('text') || '') }); form.reset(); s.reload(true);
      toast(r.flagged ? 'Mensagem publicada. Dados de contato foram ocultados e a escola foi notificada.' : 'Mensagem publicada.', r.flagged ? 'warn' : '');
    }}>
      <Field name="text" label="Nova mensagem" hint="Não compartilhe telefone, e-mail ou redes sociais."><Textarea name="text" maxLength={800} req="Escreva uma mensagem." style={{ minHeight: 70 }} /></Field>
      <div><Submit className="btn btn-primary btn-sm"><Icon name="send" /> Publicar no mural</Submit></div>
    </Form>}</div></div>;
}

function Pedagogical({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const [dec, setDec] = useState('favoravel');
  if (p.status === 'analise_pedagogica' && p.access === 'teacher') return <div className="card"><Form onSubmit={async (fd) => {
    await post(`/projects/${p.id}/pedagogical`, { decision: dec, relevance: fd.get('relevance'), safety: fd.get('safety'), feasibility: fd.get('feasibility'), curriculum: fd.get('curriculum') });
    toast(dec === 'favoravel' ? 'Parecer enviado à coordenação da escola.' : 'Demanda registrada como inadequada para a turma.'); reload();
  }}>
    <div className="stack-sm"><span className="eyebrow">Etapa 1 · Professor-orientador</span><h3>Análise pedagógica</h3><p className="small muted">Avalie se a demanda é adequada à turma antes de qualquer participação dos estudantes.</p></div>
    <Field name="relevance" label="Relevância pedagógica" hint="quais conteúdos e competências a demanda trabalha" required><Textarea name="relevance" maxLength={1200} req /></Field>
    <Field name="safety" label="Segurança dos estudantes" hint="dados pessoais, exposição, comunicação" required><Textarea name="safety" maxLength={1200} req /></Field>
    <Field name="feasibility" label="Viabilidade" hint="carga horária, disponibilidade da turma, recursos" required><Textarea name="feasibility" maxLength={1200} req /></Field>
    <Field name="curriculum" label="Conteúdo curricular relacionado"><Input name="curriculum" type="text" maxLength={400} placeholder="Ex.: HTML e CSS — 3º bimestre" /></Field>
    <div className="level" role="radiogroup" aria-label="Parecer">
      <label><input type="radio" name="dec" checked={dec === 'favoravel'} onChange={() => setDec('favoravel')} /> Parecer favorável — enviar à coordenação</label>
      <label><input type="radio" name="dec" checked={dec === 'inadequada'} onChange={() => setDec('inadequada')} /> Demanda inadequada para esta turma</label></div>
    <div><Submit><Icon name="send" /> Registrar parecer</Submit></div>
  </Form></div>;
  if (!p.pedagogical || !p.pedagogical.at) return null;
  return <div className="card stack-sm"><span className="eyebrow">Análise pedagógica · {fmtDate(p.pedagogical.at)}</span>
    <dl className="dl"><dt>Relevância</dt><dd>{p.pedagogical.relevance}</dd><dt>Segurança</dt><dd>{p.pedagogical.safety}</dd><dt>Viabilidade</dt><dd>{p.pedagogical.feasibility}</dd>{p.pedagogical.curriculum && <><dt>Currículo</dt><dd>{p.pedagogical.curriculum}</dd></>}</dl></div>;
}

function Coordination({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const [dec, setDec] = useState('autorizar');
  if (p.status === 'aguardando_coordenacao' && p.access === 'school') return <div className="card"><Form onSubmit={async (fd) => {
    await post(`/projects/${p.id}/coordination`, { decision: dec, note: String(fd.get('note') || '') });
    toast({ autorizar: 'Participação autorizada. O professor já pode organizar a equipe.', devolver: 'Devolvido ao professor para nova análise.', negar: 'Participação não autorizada.' }[dec]!); reload();
  }}>
    <div className="stack-sm"><span className="eyebrow">Etapa 2 · Coordenação escolar</span><h3>Autorizar a participação da turma</h3><p className="small muted">Confira o parecer pedagógico ao lado. O projeto só começa com a sua autorização.</p></div>
    <div className="level" role="radiogroup" aria-label="Decisão">
      <label><input type="radio" name="dec" checked={dec === 'autorizar'} onChange={() => setDec('autorizar')} /> Autorizar</label>
      <label><input type="radio" name="dec" checked={dec === 'devolver'} onChange={() => setDec('devolver')} /> Devolver ao professor</label>
      <label><input type="radio" name="dec" checked={dec === 'negar'} onChange={() => setDec('negar')} /> Não autorizar</label></div>
    <Field name="note" label="Observação" hint="obrigatória para devolver ou não autorizar"><Textarea name="note" maxLength={600} style={{ minHeight: 70 }} /></Field>
    <div><Submit><Icon name="check" /> Registrar decisão</Submit></div>
  </Form></div>;
  if (p.status === 'aguardando_coordenacao') return <Note icon="clock">Aguardando a autorização da coordenação da escola.</Note>;
  if (p.coordination?.at) return <Note icon="school" kind={p.status === 'nao_autorizado' ? 'danger' : 'ok'}>Decisão da coordenação em {fmtDate(p.coordination.at)}{p.coordination.note ? `: ${p.coordination.note}` : '.'}</Note>;
  return null;
}

function Organize({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const [sel, setSel] = useState<string[]>(p.team.map((m: any) => m.id));
  const [ms, setMs] = useState<{ title: string; dueDate: string }[]>(p.milestones.length ? p.milestones.map((m: any) => ({ title: m.title, dueDate: m.dueDate }))
    : [{ title: 'Levantamento com a empresa', dueDate: plusDays(7) }, { title: 'Primeira versão', dueDate: plusDays(21) }, { title: 'Entrega final', dueDate: p.demand.suggestedDeadline }]);
  const editing = p.status === 'em_andamento';
  return <div className="card"><Form onSubmit={async () => {
    await post(`/projects/${p.id}/organize`, { members: sel, milestones: ms });
    toast(editing ? 'Equipe e cronograma atualizados.' : 'Projeto iniciado! A equipe já vê a atividade no painel.'); reload();
  }} validate={() => { const e: Record<string, string> = {}; if (sel.length < 2) e.members = 'Selecione pelo menos 2 estudantes.'; if (ms.some((m) => m.title.trim().length < 3 || !m.dueDate)) e.milestones = 'Preencha o nome e a data de todas as etapas.'; return e; }}>
    <div className="stack-sm"><span className="eyebrow">Etapa 3 · Professor-orientador</span><h3>{editing ? 'Equipe e cronograma' : 'Organizar a equipe colaborativa'}</h3>
      <p className="small muted">Forme um grupo que favoreça a colaboração e a participação de todos. Estudantes sem autorização registrada pela escola não podem participar.</p></div>
    <div className="field"><span className="lbl">Estudantes da turma <span className="hint">{sel.length} selecionado(s)</span></span><input type="hidden" name="members" />
      <div className="checks">{p.turmaStudents.map((s: any) => { const blocked = s.consentStatus === 'pendente'; return <label key={s.id} style={blocked ? { opacity: .6 } : undefined}>
        <input type="checkbox" disabled={blocked} checked={sel.includes(s.id)} onChange={(e) => setSel(e.target.checked ? [...sel, s.id] : sel.filter((x) => x !== s.id))} />
        <span className="minw0">{s.name}{blocked && <> <span className="chip chip-warn">autorização pendente</span></>}</span></label>; })}</div><FieldError name="members" /></div>
    <div className="field"><span className="lbl">Cronograma</span><input type="hidden" name="milestones" />
      <div className="stack-sm">{ms.map((m, i) => <div key={i} className="row" style={{ flexWrap: 'nowrap' }}>
        <input type="text" aria-label={'Etapa ' + (i + 1)} value={m.title} maxLength={120} onChange={(e) => setMs(ms.map((x, j) => j === i ? { ...x, title: e.target.value } : x))} />
        <input type="date" aria-label={'Data da etapa ' + (i + 1)} value={m.dueDate} onChange={(e) => setMs(ms.map((x, j) => j === i ? { ...x, dueDate: e.target.value } : x))} style={{ maxWidth: 170 }} />
        <button type="button" className="iconbtn" aria-label="Remover etapa" disabled={ms.length === 1} onClick={() => setMs(ms.filter((_, j) => j !== i))}><Icon name="x" /></button></div>)}
        <div><button type="button" className="btn btn-ghost btn-sm" disabled={ms.length >= 12} onClick={() => setMs([...ms, { title: '', dueDate: plusDays(14) }])}><Icon name="plus" /> Adicionar etapa</button></div></div><FieldError name="milestones" /></div>
    <div><Submit><Icon name={editing ? 'check' : 'send'} /> {editing ? 'Salvar alterações' : 'Iniciar projeto com esta equipe'}</Submit></div>
  </Form></div>;
}

function Deliver({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const lastAdj = p.reviews.find((r: any) => r.role === 'teacher');
  return <div className="card"><Form validate={(fd) => {
    const e: Record<string, string> = {};
    const link = String(fd.get('link') || '').trim(); if (link && !/^https?:\/\/\S+\.\S+/.test(link)) e.link = 'Informe um link válido começando com https://';
    const d = String(fd.get('description') || '').trim(); if (d && d.length < 40) e.description = 'Descreva o trabalho com pelo menos 40 caracteres.';
    const f = fd.get('file') as File | null;
    if (f && f.size > 0) { if (!/\.(pdf|png|jpe?g|zip)$/i.test(f.name)) e.file = 'Use PDF, PNG, JPG ou ZIP.'; else if (f.size > 5 * 1024 * 1024) e.file = `O arquivo tem ${(f.size / 1024 / 1024).toFixed(1)} MB. O limite é 5 MB.`; }
    return e;
  }} onSubmit={async (fd, form) => {
    const f = fd.get('file') as File | null; if (f && f.size === 0) fd.delete('file');
    await api(`/projects/${p.id}/submissions`, { method: 'POST', form: fd }); form.reset();
    toast('Entrega enviada! O professor foi avisado para fazer a validação.'); reload();
  }}>
    <div className="stack-sm"><span className="eyebrow">Etapa 4 · Equipe</span><h3>Enviar entrega · versão {p.submissions.length + 1}</h3></div>
    {lastAdj?.kind === 'ajustes' && <Note kind="warn">O professor pediu ajustes: "{lastAdj.text}"</Note>}
    <Field name="title" label="Título da entrega" required><Input name="title" type="text" maxLength={100} req placeholder="Ex.: Página da Mercearia — versão final" /></Field>
    <Field name="description" label="Descrição" hint="o que a equipe fez, como e o que aprendeu" required><Textarea name="description" maxLength={2000} req /></Field>
    <Field name="link" label="Link do trabalho" hint="repositório, protótipo ou página publicada" required><Input name="link" type="url" req placeholder="https://…" /></Field>
    <Field name="file" label="Anexo" hint="opcional · PDF, PNG, JPG ou ZIP até 5 MB"><Input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.zip" /></Field>
    <Check name="confirm" req="Confirme a autoria e a ausência de dados pessoais.">Confirmo que o trabalho foi produzido pela equipe, cita as fontes usadas e não contém dados pessoais de ninguém. *</Check>
    <div><Submit busyLabel="Enviando entrega…"><Icon name="send" /> Enviar entrega</Submit></div>
  </Form></div>;
}

function Validate({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const suggestions = [...new Set([...p.demand.techs, 'Trabalho em equipe', 'Comunicação', 'Resolução de problemas'])];
  const [comps, setComps] = useState<string[]>([]);
  const [extra, setExtra] = useState('');
  const [dec, setDec] = useState('validar');
  return <div className="card"><Form onSubmit={async (fd) => {
    const all = [...comps, ...extra.split(',').map((x) => x.trim()).filter(Boolean)];
    await post(`/projects/${p.id}/validation`, { decision: dec, text: String(fd.get('text') || ''), competencies: all });
    toast(dec === 'validar' ? 'Entrega validada. A empresa já pode dar o retorno.' : 'Ajustes solicitados. A equipe pode enviar nova versão.'); reload();
  }} validate={(): Record<string, string> => (dec === 'validar' && comps.length + extra.split(',').filter((x) => x.trim()).length === 0 ? { competencies: 'Indique pelo menos uma competência desenvolvida.' } : {})}>
    <div className="stack-sm"><span className="eyebrow">Etapa 5 · Professor-orientador</span><h3>Validação pedagógica</h3><p className="small muted">Sem notas ou comparação entre equipes: registre o que foi aprendido e o que pode melhorar.</p></div>
    <div className="level" role="radiogroup" aria-label="Decisão">
      <label><input type="radio" name="dec" checked={dec === 'validar'} onChange={() => setDec('validar')} /> Validar a entrega</label>
      <label><input type="radio" name="dec" checked={dec === 'ajustes'} onChange={() => setDec('ajustes')} /> Pedir ajustes à equipe</label></div>
    {dec === 'validar' && <div className="field"><span className="lbl">Competências desenvolvidas</span><input type="hidden" name="competencies" />
      <div className="checks">{suggestions.map((c) => <label key={c}><input type="checkbox" checked={comps.includes(c)} onChange={(e) => setComps(e.target.checked ? [...comps, c] : comps.filter((x) => x !== c))} /> {c}</label>)}</div>
      <input type="text" aria-label="Outras competências" placeholder="Outras competências, separadas por vírgula" value={extra} onChange={(e) => setExtra(e.target.value)} style={{ marginTop: 6 }} /><FieldError name="competencies" /></div>}
    <Field name="text" label="Feedback para a equipe" hint="construtivo: o que funcionou e o que melhorar" required><Textarea name="text" maxLength={1500} req /></Field>
    <div><Submit><Icon name="check" /> Registrar</Submit></div>
  </Form></div>;
}

function CompanyFeedback({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const [crit, setCrit] = useState<Record<string, string>>({});
  const [interest, setInterest] = useState(false);
  return <div className="card"><Form validate={(): Record<string, string> => { const miss = p.demand.criteria.filter((c: string) => !crit[c]); return miss.length ? { criteria: `Indique o resultado em: ${miss.join(', ')}.` } : {}; }}
    onSubmit={async (fd) => {
      await post(`/projects/${p.id}/company-feedback`, { criteria: crit, text: String(fd.get('text') || ''), interest, interestMessage: String(fd.get('interestMessage') || '') });
      toast('Retorno registrado. O projeto foi concluído e a equipe recebeu os certificados.'); reload();
    }}>
    <div className="stack-sm"><span className="eyebrow">Etapa 6 · Empresa</span><h3>Retorno da empresa</h3><p className="small muted">Avalie o resultado com base nos critérios da demanda, sem notas. O feedback é lido pela equipe e pelo professor.</p></div>
    <input type="hidden" name="criteria" />
    {p.demand.criteria.map((c: string) => <div key={c} className="field"><span className="lbl">{c}</span><div className="level" role="radiogroup" aria-label={c}>
      {Object.entries(LEVEL).map(([k, l]) => <label key={k}><input type="radio" name={'c-' + c} checked={crit[c] === k} onChange={() => setCrit({ ...crit, [c]: k })} /> {l}</label>)}</div></div>)}
    <FieldError name="criteria" />
    <Field name="text" label="Feedback construtivo" required><Textarea name="text" maxLength={1500} req placeholder="O que foi útil, o que pode melhorar e como o resultado será usado." /></Field>
    <label className="check"><input type="checkbox" checked={interest} onChange={(e) => setInterest(e.target.checked)} /> <span>Temos interesse em futuras oportunidades profissionais com estudantes desta escola (a mensagem vai para a coordenação, não para os estudantes).</span></label>
    {interest && <Field name="interestMessage" label="Mensagem para a escola"><Textarea name="interestMessage" maxLength={600} style={{ minHeight: 70 }} placeholder="Tipo de oportunidade, prazo previsto, contato institucional." /></Field>}
    <div><Submit><Icon name="check" /> Registrar retorno e concluir</Submit></div>
  </Form></div>;
}

function Milestones({ p, reload }: { p: P; reload: () => void }) {
  const { toast } = useUi();
  const can = (p.access === 'teacher' || p.access === 'member') && ['em_andamento', 'entregue'].includes(p.status);
  if (!p.milestones.length) return null;
  const done = p.milestones.filter((m: any) => m.done).length;
  return <div className="panel"><div className="panel-h"><h3><Icon name="calendar" /> Cronograma</h3><span className="small muted">{done} de {p.milestones.length} etapas</span></div><div className="panel-b">
    <div className="meter" style={{ marginBottom: 8 }}><span style={{ width: (done / p.milestones.length) * 100 + '%' }} /></div>
    {p.milestones.map((m: any) => <div key={m.id} className={'ms' + (m.done ? ' done' : '')}>
      {can ? <input type="checkbox" checked={m.done} aria-label={'Concluída: ' + m.title} onChange={async () => { try { await post(`/projects/${p.id}/milestones/${m.id}`); reload(); } catch (e: any) { toast(e.message, 'err'); } }} /> : <Icon name={m.done ? 'check' : 'clock'} />}
      <span className="t" style={{ flex: 1 }}>{m.title}</span><span className="small muted">{fmtDate(m.dueDate)}</span></div>)}
  </div></div>;
}

export function ProjectPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast, confirm } = useUi();
  const s = useLoad(() => get(`/projects/${id}`), [id]);
  const reload = () => { s.reload(true); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  return <Loaded s={s}>{(p: P) => {
    const a = p.access;
    const back: [string, string] = [HOME[user!.role], 'Voltar ao painel'];
    return <>
      <PageHead title={p.demand.title} back={back} eyebrow={<>{p.school.name} · {p.turma.name} · {p.demand.company.name} <DemoTag on={p.isDemo} /></>} actions={<StatusPill s={p.status} />} />
      <div className="panel" style={{ padding: 16, marginBottom: 16 }}><Flow s={p.status} /></div>
      {a === 'turma' && <div style={{ marginBottom: 16 }}><Note>Este projeto foi autorizado para a sua turma. Você não faz parte da equipe, por isso vê apenas o resumo e o cronograma.</Note></div>}
      {a === 'company' && <div style={{ marginBottom: 16 }}><Note icon="shield">A empresa acompanha o andamento autorizado pela escola. Os estudantes não são identificados, e toda comunicação passa pelo mural, acompanhado pelo professor.</Note></div>}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,440px),1fr))', alignItems: 'start' }}>
        <div className="stack">
          {p.status === 'analise_pedagogica' && a !== 'teacher' && <Note icon="clock">O professor-orientador {p.teacher?.name ? `(${p.teacher.name}) ` : ''}está avaliando a adequação pedagógica desta demanda.</Note>}
          <Pedagogical p={p} reload={reload} />
          <Coordination p={p} reload={reload} />
          {a === 'teacher' && ['aprovado', 'em_andamento'].includes(p.status) && <Organize p={p} reload={reload} />}
          {p.status === 'aprovado' && a !== 'teacher' && <Note icon="users">Autorizado pela escola. O professor está organizando a equipe e o cronograma.</Note>}
          {a === 'member' && p.status === 'em_andamento' && <Deliver p={p} reload={reload} />}
          {p.status === 'entregue' && a === 'teacher' && <Validate p={p} reload={reload} />}
          {p.status === 'entregue' && a === 'member' && <Note icon="clock">Entrega enviada. Aguardando a validação do professor.</Note>}
          {p.status === 'validado' && a === 'company' && <CompanyFeedback p={p} reload={reload} />}
          {p.status === 'validado' && a === 'teacher' && <Note icon="clock">Aguardando o retorno da empresa. Se a empresa não responder até o prazo, você pode concluir o projeto mesmo assim. <button className="linkbtn" onClick={() => confirm({ title: 'Concluir sem retorno da empresa', ok: 'Concluir projeto', text: 'O projeto será concluído e os certificados emitidos para a equipe, sem o retorno da empresa.', onOk: async () => { await post(`/projects/${p.id}/conclude`); toast('Projeto concluído.'); reload(); } })}>Concluir agora</button></Note>}
          {p.status === 'concluido' && <Note kind="ok" icon="award">Projeto concluído em {fmtDate(p.concludedAt)}. {a === 'member' ? <>O certificado está no seu <Link to="/estudante/portfolio">portfólio</Link>.</> : 'Os integrantes receberam certificados de participação.'}</Note>}
          {p.interest && <Note icon="brief"><b>Interesse em futuras oportunidades:</b> {p.interest.message}{a !== 'company' && ' A escola decide como divulgar aos estudantes.'}</Note>}

          {a !== 'turma' && (p.submissions.length > 0 || ['em_andamento', 'entregue', 'validado', 'concluido'].includes(p.status)) && <div className="panel"><div className="panel-h"><h3><Icon name="clip" /> {a === 'company' ? 'Resultado entregue' : 'Entregas e histórico'}</h3><span className="small muted">{p.submissions.length} versão(ões)</span></div>
            {p.submissions.length ? <ul className="list">{p.submissions.map((x: any) => <li key={x.id}><div className="grow stack-sm">
              <b>v{x.version} — {x.title}</b><span className="small muted">{x.by ? `Enviada por ${x.by} · ` : ''}{fmtDT(x.createdAt)}</span>
              <p className="small" style={{ whiteSpace: 'pre-wrap' }}>{x.description}</p>
              <div className="small"><Icon name="link" /> <ExtLink url={x.link} /></div>
              {x.file && <div className="small"><ApiLink href={`/api/submissions/${x.id}/file`}><Icon name="download" /> {x.file.name}</ApiLink> <span className="muted">· {size(x.file.size)}</span></div>}
              {p.reviews.filter((r: any) => r.submissionId === x.id).map((r: any) => <ReviewBlock key={r.id} r={r} />)}
            </div></li>)}</ul> : <Empty icon="clip" title={a === 'company' ? 'Resultado ainda não validado' : 'Nenhuma entrega ainda'} text={a === 'company' ? 'A empresa vê o resultado depois da validação pedagógica do professor.' : 'A equipe envia as versões por aqui.'} />}</div>}
          {p.reviews.filter((r: any) => !r.submissionId).map((r: any) => <ReviewBlock key={r.id} r={r} />)}

          <div className="card stack"><span className="eyebrow">Demanda empresarial</span>
            <div className="stack-sm"><b className="small">Necessidade</b><p className="small muted" style={{ whiteSpace: 'pre-wrap' }}>{p.demand.need}</p></div>
            <div className="stack-sm"><b className="small">Objetivos</b><p className="small muted" style={{ whiteSpace: 'pre-wrap' }}>{p.demand.objectives}</p></div>
            <div className="stack-sm"><b className="small">Resultados esperados</b><p className="small muted" style={{ whiteSpace: 'pre-wrap' }}>{p.demand.expectedResults}</p></div>
            <div className="row">{p.demand.techs.map((t: string) => <span key={t} className="chip">{t}</span>)}<span className="chip"><Icon name="clock" /> ~{p.demand.hours} h</span></div>
            <div className="small"><b>Critérios:</b> {p.demand.criteria.join(' · ')}</div>
            <Link className="small" to={'/demandas/' + p.demand.id}>Ver a demanda no catálogo</Link></div>
        </div>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="users" /> Equipe autorizada</h3><span className="small muted">{p.teamCount} estudante(s)</span></div>
            <div className="panel-b stack-sm">
              {p.teacher && <div className="small"><b>Professor-orientador:</b> {p.teacher.name}</div>}
              <div className="small"><b>Escola:</b> {p.school.name} ({p.school.city})</div>
              {a === 'company' ? <p className="small muted">Equipe de {p.teamCount} estudantes da turma {p.turma.name}. Os nomes não são exibidos para empresas.</p>
                : p.team.length ? <div className="row">{p.team.map((m: any) => <span key={m.id} className="chip">{m.isMe ? <b>Você</b> : m.name}{m.code ? ` · ${m.code}` : ''}</span>)}</div>
                  : <p className="small muted">A equipe ainda não foi organizada.</p>}
              {(a === 'teacher' || a === 'school') && p.turmaStudents && <details className="small"><summary style={{ cursor: 'pointer' }}>Autorizações da turma</summary><ul style={{ margin: '6px 0 0', paddingLeft: 0, listStyle: 'none' }}>{p.turmaStudents.map((s: any) => <li key={s.id} className="row between" style={{ padding: '4px 0' }}><span>{s.name}</span><ConsentPill s={s.consentStatus} /></li>)}</ul></details>}
            </div></div>
          <Milestones p={p} reload={() => s.reload(true)} />
          {p.canMural ? <Mural p={p} /> : <div className="panel"><div className="panel-h"><h3><Icon name="msg" /> Mural do projeto</h3></div><Empty icon="lock" title="Mural restrito" text="O mural é acessível à equipe, ao professor responsável, à escola e à empresa." /></div>}
        </div>
      </div></>;
  }}</Loaded>;
}
