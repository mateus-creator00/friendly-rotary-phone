import React, { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { D_PHASE, fmtDate } from '../lib';
import { Icon, Empty, Note, PageHead, DemandPill, StatusPill, DemoTag, Deadline, useLoad, Loaded, useUi, ActionButton } from '../ui';

function Wrap({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  return user ? <>{children}</> : <section className="sec"><div className="wrap">{children}</div></section>;
}

export function DemandCard({ d }: { d: any }) {
  return <article className="ch-card">
    <div className="row between"><span className="chip chip-petrol">{d.area}</span><DemandPill s={d.phase} /></div>
    <h3>{d.title}</h3>
    <div className="co"><Icon name="building" />{d.company.name} <span className="muted">· {d.city}</span> <DemoTag on={d.isDemo} /></div>
    <p className="small muted">{d.objectives}</p>
    <div className="meta">{d.techs.map((t: string) => <span key={t} className="chip">{t}</span>)}</div>
    <div className="foot"><span className="small muted">~{d.hours} h · {d.slotsLeft > 0 ? `${d.slotsLeft} turma(s) ainda podem atender` : 'sem novas vagas para turmas'}</span><Link className="btn btn-primary btn-sm" to={'/demandas/' + d.id}>Ver demanda</Link></div>
  </article>;
}

export function Catalog() {
  const { user } = useAuth();
  const s = useLoad(() => get<any[]>('/demands'), [user?.id]);
  const courses = useLoad(() => get<any[]>('/public/courses'), []);
  const [f, setF] = useState({ q: '', area: '', city: '', tec: '', phase: '' });
  const list = s.data || [];
  const techs = useMemo(() => [...new Set(list.flatMap((d) => d.techs))].sort(), [list]);
  const cities = useMemo(() => [...new Set(list.map((d) => d.city))].sort(), [list]);
  const res = list.filter((d) => (!f.q || (d.title + ' ' + d.need + ' ' + d.objectives + ' ' + d.techs.join(' ') + ' ' + d.company.name).toLowerCase().includes(f.q.toLowerCase()))
    && (!f.area || d.area === f.area) && (!f.city || d.city === f.city) && (!f.tec || d.techs.includes(f.tec)) && (!f.phase || d.phase === f.phase));
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const any = Object.values(f).some(Boolean);
  return <Wrap>
    <PageHead title="Catálogo de demandas empresariais" eyebrow="Necessidades reais para projetos colaborativos"
      actions={user?.role === 'company' ? <Link className="btn btn-primary" to="/empresa/nova-demanda"><Icon name="plus" /> Submeter demanda</Link> : undefined} />
    <div style={{ marginBottom: 16 }}><Note>{user?.role === 'teacher' || user?.role === 'school'
      ? 'Abra uma demanda para iniciar a análise pedagógica para uma turma. A participação só começa depois da autorização da coordenação.'
      : 'Todas as demandas foram moderadas pela administração. Escolas e professores avaliam cada uma antes de qualquer participação dos estudantes.'}</Note></div>
    <div className="filters" role="search" style={{ marginBottom: 18 }}>
      <div className="field f-q"><label htmlFor="c-q" className="lbl">Pesquisar</label><input id="c-q" type="search" placeholder="Título, necessidade, tecnologia ou empresa" value={f.q} onChange={set('q')} /></div>
      <div className="field"><label htmlFor="c-area" className="lbl">Área técnica</label><select id="c-area" value={f.area} onChange={set('area')}><option value="">Todas</option>{courses.data?.map((c) => <option key={c.id}>{c.name}</option>)}</select></div>
      <div className="field"><label htmlFor="c-city" className="lbl">Município</label><select id="c-city" value={f.city} onChange={set('city')}><option value="">Todos</option>{cities.map((c) => <option key={c}>{c}</option>)}</select></div>
      <div className="field"><label htmlFor="c-tec" className="lbl">Tecnologia</label><select id="c-tec" value={f.tec} onChange={set('tec')}><option value="">Todas</option>{techs.map((t) => <option key={t}>{t}</option>)}</select></div>
      <div className="field"><label htmlFor="c-st" className="lbl">Status</label><select id="c-st" value={f.phase} onChange={set('phase')}><option value="">Todos</option>{['disponivel', 'em_projeto', 'concluida'].map((k) => <option key={k} value={k}>{D_PHASE[k][0]}</option>)}</select></div>
    </div>
    <Loaded s={s}>{() => <>
      <div className="row between" style={{ marginBottom: 12 }}><span className="small muted">{res.length} de {list.length} demandas</span>{any && <button className="linkbtn" onClick={() => setF({ q: '', area: '', city: '', tec: '', phase: '' })}>Limpar filtros</button>}</div>
      {res.length ? <div className="grid g3">{res.map((d) => <DemandCard key={d.id} d={d} />)}</div>
        : <div className="panel">{list.length ? <Empty icon="search" title="Nenhuma demanda encontrada" text="Tente remover algum filtro ou pesquisar outra palavra." /> : <Empty icon="brief" title="Ainda não há demandas disponíveis" text="Empresas verificadas submetem demandas, que aparecem aqui depois da moderação." />}</div>}
    </>}</Loaded>
  </Wrap>;
}

export function DemandDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useUi();
  const nav = useNavigate();
  const s = useLoad(() => get(`/demands/${id}`), [id, user?.id]);
  const [turma, setTurma] = useState('');
  return <Wrap><Loaded s={s}>{(d: any) => {
    const canStart = (user?.role === 'teacher' || user?.role === 'school') && d.status === 'disponivel' && d.slotsLeft > 0;
    const options = (d.myTurmas || []).filter((t: any) => !t.projectId && t.hasTeacher && t.schoolApproved);
    return <>
      <PageHead title={d.title} eyebrow={<>{d.company.name} · {d.area} <DemoTag on={d.isDemo} /></>} back={['/demandas', 'Catálogo de demandas']}
        actions={<DemandPill s={d.phase} />} />
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,420px),1fr))', alignItems: 'start' }}>
        <div className="card stack">
          <div className="row"><Deadline d={d.suggestedDeadline} /><span className="chip"><Icon name="clock" /> ~{d.hours} h estimadas</span><span className="chip"><Icon name="users" /> até {d.maxProjects} turma(s)</span></div>
          <div className="stack-sm"><span className="eyebrow">Necessidade da empresa</span><p style={{ whiteSpace: 'pre-wrap' }}>{d.need}</p></div>
          <div className="stack-sm"><span className="eyebrow">Objetivos</span><p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{d.objectives}</p></div>
          <div className="stack-sm"><span className="eyebrow">Resultados esperados</span><p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{d.expectedResults}</p></div>
          <div className="grid g2">
            <div className="stack-sm"><span className="eyebrow">Tecnologias</span><div className="row">{d.techs.map((t: string) => <span key={t} className="chip">{t}</span>)}</div></div>
            <div className="stack-sm"><span className="eyebrow">Critérios de avaliação</span><ul className="small" style={{ margin: 0, paddingLeft: 18 }}>{d.criteria.map((c: string) => <li key={c}>{c}</li>)}</ul></div>
          </div>
          <dl className="dl"><dt>Empresa</dt><dd>{d.company.name} <span className="muted">· {d.company.sector}</span></dd><dt>Município</dt><dd>{d.city}</dd><dt>Prazo sugerido</dt><dd>{fmtDate(d.suggestedDeadline)} (a escola define o cronograma final)</dd><dt>Publicada em</dt><dd>{fmtDate(d.createdAt)}</dd></dl>
          <p className="small muted"><Icon name="shield" /> A empresa declarou que a demanda é de escopo limitado e não substitui trabalho remunerado.</p>
        </div>
        <div className="stack">
          {d.status !== 'disponivel' && <Note kind="warn">Situação na moderação: <b>{D_PHASE[d.status]?.[0]}</b>{d.modNote ? ` — ${d.modNote}` : ''}</Note>}
          {canStart && <div className="card stack"><div className="stack-sm"><span className="eyebrow">{user!.role === 'teacher' ? 'Professor-orientador' : 'Escola'}</span><h3>Analisar para uma turma</h3>
            <p className="small muted">Abre a análise pedagógica (relevância, segurança e viabilidade). {user!.role === 'school' ? 'O professor-orientador da turma faz o parecer.' : 'Depois do seu parecer, a coordenação decide.'}</p></div>
            {options.length ? <><div className="field"><label htmlFor="d-turma" className="lbl">Turma</label><select id="d-turma" value={turma} onChange={(e) => setTurma(e.target.value)}><option value="">Selecione</option>{options.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
              <div><ActionButton className="btn btn-primary" disabled={!turma} action={async () => { const r = await post('/projects', { demandId: d.id, turmaId: turma }); toast('Análise pedagógica iniciada.'); nav('/projetos/' + r.id); }}><Icon name="clip" /> Iniciar análise pedagógica</ActionButton></div></>
              : <p className="small muted">Nenhuma turma disponível: todas já analisaram esta demanda, ou falta definir o professor-orientador.</p>}
          </div>}
          {(d.myTurmas || []).some((t: any) => t.projectId) && <div className="panel"><div className="panel-h"><h3>Suas turmas com esta demanda</h3></div><ul className="list">{d.myTurmas.filter((t: any) => t.projectId).map((t: any) =>
            <li key={t.id}><div className="grow"><b>{t.name}</b></div><div className="row"><StatusPill s={t.projectStatus} /><Link className="btn btn-ghost btn-sm" to={'/projetos/' + t.projectId}>Abrir projeto</Link></div></li>)}</ul></div>}
          {user?.role === 'company' && <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Projetos autorizados</h3>{d.inAnalysis > 0 && <span className="chip chip-warn">{d.inAnalysis} em análise por escolas</span>}</div>
            {d.projects.length ? <ul className="list">{d.projects.map((p: any) => <li key={p.id}><div className="grow"><b>{p.school}</b><div className="small muted">{p.turma}</div></div><div className="row"><StatusPill s={p.status} /><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}>Acompanhar</Link></div></li>)}</ul>
              : <Empty icon="folder" title="Nenhum projeto autorizado ainda" text="Quando uma escola autorizar a participação de uma turma, o projeto aparece aqui." />}</div>}
          {user?.role === 'admin' && <div className="panel"><div className="panel-h"><h3>Projetos</h3><Link to="/admin/demandas">Moderação</Link></div>{d.projects.length ? <ul className="list">{d.projects.map((p: any) => <li key={p.id}><div className="grow"><b>{p.school}</b><div className="small muted">{p.turma}</div></div><div className="row"><StatusPill s={p.status} /><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}>Abrir</Link></div></li>)}</ul> : <p className="panel-b small muted">Nenhum projeto.</p>}</div>}
          {!user && <Note icon="lock">Escolas e professores entram com o <Link to="/entrar">login institucional</Link> para analisar esta demanda.</Note>}
        </div>
      </div></>;
  }}</Loaded></Wrap>;
}
