import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { Icon, Note, PageHead, Empty, useLoad, Loaded, ActionButton, useUi, OppPill, DemoTag } from '../ui';

export function Opportunities() {
  const { user } = useAuth();
  const { toast } = useUi();
  const s = useLoad(() => get<any[]>('/opportunities'), [user?.id]);
  const [f, setF] = useState({ area: '', city: '' });
  const list = (s.data || []).filter((o) => o.status === 'publicada');
  const areas = [...new Set(list.map((o) => o.area))].sort(), cities = [...new Set(list.map((o) => o.city))].sort();
  const res = list.filter((o) => (!f.area || o.area === f.area) && (!f.city || o.city === f.city));
  const body = <>
    <PageHead title="Banco de oportunidades" eyebrow="Etapa futura · vagas reais verificadas" actions={user?.role === 'company' ? <Link className="btn btn-primary" to="/empresa/oportunidades"><Icon name="plus" /> Divulgar vaga</Link> : undefined} />
    <div style={{ marginBottom: 16 }}><Note>Esta área recebe somente vagas reais de empresas verificadas, moderadas pela administração. Cada vaga segue o processo seletivo próprio da empresa, com acompanhamento da escola. Participar de projetos não garante contratação.</Note></div>
    <div className="row" style={{ marginBottom: 16, gap: 12 }}>
      <div className="field" style={{ minWidth: 180 }}><label htmlFor="o-a" className="lbl">Área</label><select id="o-a" value={f.area} onChange={(e) => setF({ ...f, area: e.target.value })}><option value="">Todas</option>{areas.map((a) => <option key={a}>{a}</option>)}</select></div>
      <div className="field" style={{ minWidth: 180 }}><label htmlFor="o-c" className="lbl">Município</label><select id="o-c" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })}><option value="">Todos</option>{cities.map((a) => <option key={a}>{a}</option>)}</select></div>
    </div>
    <Loaded s={s}>{() => res.length ? <div className="grid g2">{res.map((o) => <article key={o.id} className="ch-card">
      <div className="row between"><span className="chip chip-petrol"><Icon name="brief" /> {o.area}</span><div className="row"><DemoTag on={o.isDemo} /><OppPill s={o.status} /></div></div>
      <h3>{o.title}</h3>
      <div className="co"><Icon name="building" />{o.companyName} <span className="muted">· {o.city}</span></div>
      <p className="small muted" style={{ whiteSpace: 'pre-wrap' }}>{o.description}</p>
      <dl className="dl"><dt>Carga</dt><dd>{o.workload}</dd><dt>Requisitos</dt><dd>{o.requirements.join('; ')}</dd><dt>Seleção</dt><dd>{o.selectionInfo}</dd></dl>
      {user?.role === 'student' && <div className="foot"><span className="small muted">{o.interested ? 'Interesse registrado. A escola acompanha.' : 'A empresa vê só a quantidade de interessados; a escola media o contato.'}</span>
        <ActionButton className={'btn btn-sm ' + (o.interested ? 'btn-ghost' : 'btn-primary')} action={async () => { const r = await post(`/student/opportunities/${o.id}/interest`); toast(r.interested ? 'Interesse registrado. Converse com a coordenação sobre os próximos passos.' : 'Interesse retirado.'); s.reload(true); }}>{o.interested ? 'Retirar interesse' : 'Registrar interesse'}</ActionButton></div>}
    </article>)}</div> : <div className="panel"><Empty icon="brief" title="Nenhuma vaga publicada no momento" text="Quando empresas verificadas divulgarem vagas reais, elas aparecem aqui." /></div>}</Loaded>
  </>;
  return user ? body : <section className="sec"><div className="wrap">{body}</div></section>;
}
