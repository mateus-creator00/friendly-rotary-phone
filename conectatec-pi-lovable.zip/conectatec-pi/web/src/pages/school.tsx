import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post, put } from '../api';
import { useAuth } from '../auth';
import { P_STATUS, REQ_KIND, ROLE_LABEL, YEARS, fmtDate, fmtDT, pct } from '../lib';
import { appUrl } from '../env';
import { Icon, Kpi, Bars, Empty, Note, PageHead, StatusPill, OrgPill, ConsentPill, DemoTag, useLoad, Loaded, Form, Field, Input, Select, Textarea, Submit, ActionButton, useUi, Modal, copyText } from '../ui';

function Pending({ school }: { school: any }) {
  if (!school || school.status === 'aprovada') return null;
  const t = { pendente: 'A solicitação de acesso institucional está em análise pela administração da plataforma. O cadastro de professores, turmas e estudantes será liberado após a aprovação.',
    ajustes: 'A administração pediu ajustes: ' + (school.note || ''), rejeitada: 'A solicitação não foi aprovada: ' + (school.note || '') }[school.status as string];
  return <div style={{ marginBottom: 16 }}><Note kind={school.status === 'rejeitada' ? 'danger' : 'warn'} icon="alert">{t}</Note></div>;
}

export function EscPainel() {
  const { toast } = useUi();
  const s = useLoad(() => get('/school/dashboard'), []);
  const [resp, setResp] = useState<any>(null);
  return <Loaded s={s}>{(d: any) => {
    const k = d.kpis, waiting = d.projects.filter((p: any) => p.status === 'aguardando_coordenacao');
    return <>
      <PageHead title={d.school.name} eyebrow={<>Painel da escola · {d.school.city} <DemoTag on={d.school.isDemo} /></>} actions={<OrgPill s={d.school.status} />} />
      <Pending school={d.school} />
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,170px),1fr))', marginBottom: 20 }}>
        <Kpi n={k.students} l="Estudantes habilitados" s={k.consent_pending ? `${k.consent_pending} com autorização pendente` : 'autorizações em dia'} />
        <Kpi n={k.teachers} l="Professores" s={k.turmas + ' turmas'} />
        <Kpi n={waiting.length} l="Aguardando autorização" s="pareceres favoráveis" />
        <Kpi n={k.active_projects} l="Projetos em andamento" />
        <Kpi n={k.concluded} l="Projetos concluídos" s={`${pct(k.participants, k.students)}% dos estudantes participaram`} />
      </div>
      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="school" /> Aguardando sua autorização</h3></div>
            {waiting.length ? <ul className="list">{waiting.map((p: any) => <li key={p.id}><div className="grow"><b>{p.title}</b><div className="small muted">{p.turmaName} · {p.companyName} · parecer de {p.teacherName}</div></div><Link className="btn btn-primary btn-sm" to={'/projetos/' + p.id}>Analisar e decidir</Link></li>)}</ul>
              : <Empty icon="check" title="Nenhuma decisão pendente" text="Quando um professor registrar parecer favorável, o projeto aparece aqui para autorização." />}</div>
          <div className="panel"><div className="panel-h"><h3><Icon name="clip" /> Pedidos de correção e remoção</h3></div>
            {d.corrections.length ? <ul className="list">{d.corrections.map((c: any) => <li key={c.id}><div className="grow stack-sm"><div className="row"><b className="small">{c.name}</b><span className="chip">{REQ_KIND[c.kind]}</span>{c.status === 'resolvido' ? <span className="pill st-done">Resolvido</span> : <span className="pill st-pend">Aberto</span>}</div><p className="small">{c.text}</p><span className="small muted">{fmtDT(c.createdAt)}</span></div>
              {c.status === 'aberto' && <button className="btn btn-ghost btn-sm" onClick={() => setResp(c)}>Responder</button>}</li>)}</ul> : <p className="panel-b small muted">Nenhum pedido.</p>}</div>
          {d.flags.length > 0 && <div className="panel"><div className="panel-h"><h3><Icon name="flag" /> Sinalizações de segurança</h3></div><ul className="list">{d.flags.map((f: any) => <li key={f.id}><div className="grow"><b className="small">{f.type}</b><p className="small">{f.text}</p><span className="small muted">{fmtDT(f.createdAt)}</span></div>
            <div className="row">{f.projectId && <Link className="btn btn-ghost btn-sm" to={'/projetos/' + f.projectId}>Ver mural</Link>}<ActionButton action={async () => { await post(`/school/flags/${f.id}/resolve`); s.reload(true); }} success="Sinalização resolvida.">Resolver</ActionButton></div></li>)}</ul></div>}
        </div>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Projetos recentes</h3><Link to="/escola/projetos">Ver todos</Link></div>
            {d.projects.length ? <ul className="list">{d.projects.slice(0, 6).map((p: any) => <li key={p.id}><div className="grow"><b>{p.title}</b><div className="small muted">{p.turmaName} · {p.companyName}</div></div><div className="row"><StatusPill s={p.status} /><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}>Abrir</Link></div></li>)}</ul>
              : <Empty icon="brief" title="Nenhum projeto ainda" text="Professores iniciam análises a partir do catálogo de demandas."><Link className="btn btn-primary btn-sm" to="/demandas">Ver demandas</Link></Empty>}</div>
          <div className="panel"><div className="panel-h"><h3><Icon name="brief" /> Interesse de empresas em oportunidades futuras</h3></div>
            {d.interests.length ? <ul className="list">{d.interests.map((i: any, n: number) => <li key={n}><div className="grow stack-sm"><b className="small">{i.companyName}</b><p className="small">{i.message}</p><span className="small muted">A partir do projeto "{i.title}" · {fmtDate(i.createdAt)}</span></div></li>)}</ul>
              : <p className="panel-b small muted">As empresas podem manifestar interesse ao concluir um projeto. A mensagem chega à escola, não aos estudantes.</p>}</div>
          {d.oppInterests.length > 0 && <div className="panel"><div className="panel-h"><h3>Estudantes interessados em vagas</h3></div><ul className="list">{d.oppInterests.map((o: any, n: number) => <li key={n}><div className="grow"><b className="small">{o.name}</b><div className="small muted">{o.title} · {o.companyName}</div></div></li>)}</ul></div>}
        </div>
      </div>
      {resp && <Modal title="Responder pedido" onClose={() => setResp(null)}><Form onSubmit={async (fd) => { await post(`/school/corrections/${resp.id}/resolve`, { response: String(fd.get('response') || '') }); toast('Resposta registrada.'); setResp(null); s.reload(true); }}>
        <p className="small"><b>{resp.name}</b>: {resp.text}</p><Note>Faça a correção em "Turmas e pessoas" (ou oculte a mensagem no mural do projeto) e registre aqui o que foi feito.</Note>
        <Field name="response" label="Resposta ao solicitante" required><Textarea name="response" maxLength={600} req /></Field><div><Submit>Marcar como resolvido</Submit></div></Form></Modal>}
    </>;
  }}</Loaded>;
}

export function EscProjetos() {
  const s = useLoad(() => get('/school/dashboard'), []);
  const [f, setF] = useState('');
  return <><PageHead title="Projetos da escola" eyebrow="Acompanhamento institucional" />
    <Loaded s={s}>{(d: any) => { const list = d.projects.filter((p: any) => !f || p.status === f); return <>
      <div className="field" style={{ maxWidth: 320, marginBottom: 16 }}><label htmlFor="ep-f" className="lbl">Situação</label><select id="ep-f" value={f} onChange={(e) => setF(e.target.value)}><option value="">Todas</option>{Object.entries(P_STATUS).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}</select></div>
      <div className="panel">{list.length ? <div className="scroll-x"><table className="tbl"><thead><tr><th>Projeto</th><th>Turma</th><th>Empresa</th><th>Orientação</th><th className="num">Equipe</th><th>Situação</th><th></th></tr></thead><tbody>
        {list.map((p: any) => <tr key={p.id}><td><b>{p.title}</b> <DemoTag on={p.isDemo} /></td><td className="small">{p.turmaName}</td><td className="small">{p.companyName}</td><td className="small">{p.teacherName || '—'}</td><td className="num">{p.members}</td><td><StatusPill s={p.status} /></td><td><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}>Abrir</Link></td></tr>)}</tbody></table></div>
        : <Empty icon="folder" title="Nenhum projeto nesta situação" text="Altere o filtro." />}</div></>; }}</Loaded></>;
}

function Credentials({ creds, onClose }: { creds: any[]; onClose: () => void }) {
  const { toast } = useUi();
  const text = creds.map((c) => `${c.name}\tusuário: ${c.login}\tsenha temporária: ${c.temporaryPassword}`).join('\n');
  return <Modal title="Credenciais de acesso" wide onClose={onClose} foot={<><button className="btn btn-ghost" onClick={() => copyText(text, toast)}><Icon name="copy" /> Copiar todas</button><button className="btn btn-ghost" onClick={() => window.print()}><Icon name="print" /> Imprimir</button><button className="btn btn-primary" onClick={onClose}>Pronto, entreguei</button></>}>
    <div className="stack"><Note kind="warn">As senhas temporárias não serão mostradas novamente. Entregue cada credencial individualmente e com discrição (por exemplo, em papel na sala de aula). No primeiro acesso, o sistema exige a troca da senha.</Note>
      <div className="scroll-x"><table className="cred"><thead><tr><th>Nome</th><th>Usuário</th><th>Senha temporária</th></tr></thead><tbody>{creds.map((c) => <tr key={c.login}><td>{c.name}</td><td><code>{c.login}</code></td><td><code>{c.temporaryPassword}</code></td></tr>)}</tbody></table></div>
      <p className="small muted">Endereço de acesso: {appUrl('/entrar')}</p></div></Modal>;
}

export function EscPessoas() {
  const { toast, confirm } = useUi();
  const { school } = useAuth();
  const s = useLoad(() => get('/school/people'), []);
  const courses = useLoad(() => get<any[]>('/public/courses'), []);
  const [tab, setTab] = useState('estudantes');
  const [creds, setCreds] = useState<any[] | null>(null);
  const [batch, setBatch] = useState(false);
  const [q, setQ] = useState(''); const [ft, setFt] = useState('');
  if (school && school.status !== 'aprovada') return <><PageHead title="Turmas e pessoas" /><Pending school={school} /></>;
  return <><PageHead title="Turmas e pessoas" eyebrow="Cadastro controlado pela escola" />
    <div className="tabs" role="tablist">{[['estudantes', 'Estudantes'], ['turmas', 'Turmas'], ['professores', 'Professores']].map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    <Loaded s={s}>{(d: any) => <>
      {tab === 'estudantes' && <div className="stack">
        {!d.turmas.length ? <Note kind="warn">Cadastre uma turma antes de habilitar estudantes.</Note> : <div className="card">
          <div className="row between" style={{ marginBottom: 12 }}><h3>Habilitar {batch ? 'vários estudantes' : 'estudante'}</h3><button className="linkbtn" onClick={() => setBatch(!batch)}>{batch ? 'Cadastrar um por vez' : 'Cadastrar vários de uma vez'}</button></div>
          <Form onSubmit={async (fd, form) => {
            const base = { turmaId: String(fd.get('turmaId')), isMinor: fd.get('isMinor') !== 'false' };
            const r = batch ? await post('/school/students/batch', { ...base, lines: String(fd.get('lines') || '') }) : await post('/school/students', { ...base, name: String(fd.get('name') || '').trim(), studentCode: String(fd.get('studentCode') || '') });
            form.reset(); setCreds(r.credentials); s.reload(true);
          }}>
            <div className="grid g2">
              <Field name="turmaId" label="Turma" required><Select name="turmaId" req defaultValue=""><option value="">Selecione</option>{d.turmas.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select></Field>
              <Field name="isMinor" label="Faixa etária" required><Select name="isMinor" defaultValue="true"><option value="true">Menor de 18 anos (exige autorização do responsável)</option><option value="false">18 anos ou mais</option></Select></Field>
              {!batch && <><Field name="name" label="Nome completo" required><Input name="name" type="text" maxLength={80} req /></Field><Field name="studentCode" label="Identificação interna" hint="matrícula ou código da escola"><Input name="studentCode" type="text" maxLength={30} /></Field></>}
            </div>
            {batch && <Field name="lines" label="Lista de estudantes" hint="um por linha: Nome completo; matrícula" required><Textarea name="lines" req style={{ minHeight: 140, fontFamily: 'var(--f-mono)', fontSize: '.84rem' }} placeholder={'Ana Clara Sousa; 2026001\nBruno Lima Carvalho; 2026002'} /></Field>}
            <p className="small muted">O sistema gera um usuário institucional e uma senha temporária para cada estudante. Não é pedido e-mail, telefone ou documento.</p>
            <div><Submit><Icon name="plus" /> Habilitar acesso</Submit></div>
          </Form></div>}
        <div className="panel"><div className="panel-h"><h3>Estudantes ({d.students.length})</h3><div className="row"><input type="search" aria-label="Buscar estudante" placeholder="Buscar por nome ou identificação" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 240 }} />
          <select aria-label="Filtrar turma" value={ft} onChange={(e) => setFt(e.target.value)} style={{ maxWidth: 220 }}><option value="">Todas as turmas</option>{d.turmas.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div></div>
          {d.students.length ? <div className="scroll-x"><table className="tbl"><thead><tr><th>Estudante</th><th>Turma</th><th>Autorização do responsável</th><th>Portfólio público</th><th>Acesso</th></tr></thead><tbody>
            {d.students.filter((x: any) => (!ft || x.turmaId === ft) && (!q || (x.name + ' ' + (x.code || '') + ' ' + x.login).toLowerCase().includes(q.toLowerCase()))).map((x: any) => <tr key={x.id} style={x.active ? undefined : { opacity: .55 }}>
              <td><b>{x.name}</b> <DemoTag on={x.isDemo} /><div className="small muted">{x.code || 'sem identificação'} · <span className="mono">{x.login}</span></div></td>
              <td><select aria-label={'Turma de ' + x.name} value={x.turmaId || ''} onChange={async (e) => { try { await put(`/school/students/${x.id}`, { turmaId: e.target.value }); toast('Turma atualizada.'); s.reload(true); } catch (er: any) { toast(er.message, 'err'); } }}>{d.turmas.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></td>
              <td>{x.isMinor ? <div className="stack-sm"><ConsentPill s={x.consentStatus} />
                <ActionButton className="btn btn-ghost btn-sm" action={async () => { await put(`/school/students/${x.id}`, { consentStatus: x.consentStatus === 'registrado' ? 'pendente' : 'registrado' }); s.reload(true); }} success="Autorização atualizada.">{x.consentStatus === 'registrado' ? 'Marcar como pendente' : 'Registrar autorização'}</ActionButton></div> : <ConsentPill s="nao_aplica" />}</td>
              <td><label className="check"><input type="checkbox" checked={x.portfolioAllowed} onChange={async (e) => { try { await put(`/school/students/${x.id}`, { portfolioAllowed: e.target.checked }); toast(e.target.checked ? 'Publicação do portfólio autorizada.' : 'Autorização revogada; o portfólio deixou de ser público.'); s.reload(true); } catch (er: any) { toast(er.message, 'err'); } }} /> <span className="small">Autorizado</span></label></td>
              <td><div className="stack-sm"><span className="small muted">{x.mustChangePassword ? 'senha temporária' : x.lastLoginAt ? 'acessou em ' + fmtDate(x.lastLoginAt) : 'nunca acessou'}</span><div className="row">
                <ActionButton action={async () => { const r = await post(`/school/users/${x.id}/reset-password`); setCreds([{ name: x.name, login: r.login, temporaryPassword: r.temporaryPassword }]); s.reload(true); }}>Nova senha</ActionButton>
                <button className="btn btn-ghost btn-sm" onClick={() => confirm({ title: x.active ? 'Desativar acesso' : 'Reativar acesso', danger: x.active, ok: x.active ? 'Desativar' : 'Reativar', text: x.active ? `${x.name} não conseguirá mais entrar. O histórico de projetos é mantido.` : `${x.name} voltará a acessar a plataforma.`, onOk: async () => { await put(`/school/students/${x.id}`, { active: !x.active }); s.reload(true); } })}>{x.active ? 'Desativar' : 'Reativar'}</button></div></div></td>
            </tr>)}</tbody></table></div> : <Empty icon="users" title="Nenhum estudante habilitado" text="Use o formulário acima para habilitar o acesso dos estudantes." />}</div>
      </div>}
      {tab === 'turmas' && <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="panel">{d.turmas.length ? <div className="scroll-x"><table className="tbl"><thead><tr><th>Turma</th><th>Professor-orientador</th><th className="num">Estudantes</th></tr></thead><tbody>
          {d.turmas.map((t: any) => <tr key={t.id}><td><b>{t.name}</b> <DemoTag on={t.isDemo} /></td><td><select aria-label={'Orientador de ' + t.name} value={t.teacherId || ''} onChange={async (e) => { try { await put(`/school/turmas/${t.id}`, { teacherId: e.target.value }); toast('Professor-orientador atualizado.'); s.reload(true); } catch (er: any) { toast(er.message, 'err'); } }}><option value="">Sem orientador</option>{d.teachers.filter((p: any) => p.active).map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></td><td className="num">{t.students}</td></tr>)}</tbody></table></div>
          : <Empty icon="users" title="Nenhuma turma" text="Cadastre a primeira turma ao lado." />}</div>
        <div className="card"><Form onSubmit={async (fd, form) => { await post('/school/turmas', Object.fromEntries(['course', 'year', 'letter', 'teacherId'].map((k) => [k, String(fd.get(k) || '')]))); form.reset(); toast('Turma cadastrada.'); s.reload(true); }}>
          <h3>Cadastrar turma</h3>
          <Field name="course" label="Curso técnico" required><Select name="course" req defaultValue=""><option value="">Selecione</option>{courses.data?.map((c) => <option key={c.id}>{c.name}</option>)}</Select></Field>
          <div className="grid g2"><Field name="year" label="Série" required><Select name="year" req defaultValue=""><option value="">Selecione</option>{YEARS.map((y) => <option key={y}>{y}</option>)}</Select></Field><Field name="letter" label="Identificação" required><Input name="letter" type="text" maxLength={4} placeholder="A" req /></Field></div>
          <Field name="teacherId" label="Professor-orientador"><Select name="teacherId" defaultValue=""><option value="">Definir depois</option>{d.teachers.filter((p: any) => p.active).map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></Field>
          <div><Submit><Icon name="plus" /> Cadastrar turma</Submit></div></Form></div></div>}
      {tab === 'professores' && <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="panel">{d.teachers.length ? <ul className="list">{d.teachers.map((t: any) => <li key={t.id} style={t.active ? undefined : { opacity: .55 }}><div className="grow"><b>{t.name}</b> <DemoTag on={t.isDemo} /><div className="small muted">{t.login} · {t.mustChangePassword ? 'senha temporária' : t.lastLoginAt ? 'acessou em ' + fmtDate(t.lastLoginAt) : 'nunca acessou'}</div></div>
          <div className="row"><ActionButton action={async () => { const r = await post(`/school/users/${t.id}/reset-password`); setCreds([{ name: t.name, login: r.login, temporaryPassword: r.temporaryPassword }]); s.reload(true); }}>Nova senha</ActionButton>
            <ActionButton action={async () => { await put(`/school/teachers/${t.id}`, { active: !t.active }); s.reload(true); }} success={t.active ? 'Acesso desativado.' : 'Acesso reativado.'}>{t.active ? 'Desativar' : 'Reativar'}</ActionButton></div></li>)}</ul>
          : <Empty icon="cap" title="Nenhum professor" text="Cadastre os professores-orientadores ao lado." />}</div>
        <div className="card"><Form onSubmit={async (fd, form) => { const r = await post('/school/teachers', { name: String(fd.get('name') || ''), email: String(fd.get('email') || '') }); form.reset(); setCreds([{ name: String(fd.get('name')), login: r.login, temporaryPassword: r.temporaryPassword }]); s.reload(true); }}>
          <h3>Cadastrar professor(a)</h3><Field name="name" label="Nome completo" required><Input name="name" type="text" maxLength={80} req /></Field><Field name="email" label="E-mail institucional" required><Input name="email" type="email" req /></Field>
          <div><Submit><Icon name="plus" /> Cadastrar e gerar senha</Submit></div></Form></div></div>}
    </>}</Loaded>
    {creds && <Credentials creds={creds} onClose={() => setCreds(null)} />}
  </>;
}

export function EscRelatorios() {
  const { school } = useAuth();
  const s = useLoad(() => get('/school/report'), []);
  if (school && school.status !== 'aprovada') return <><PageHead title="Relatórios" /><Pending school={school} /></>;
  return <><PageHead title="Relatórios institucionais" eyebrow={school?.name} actions={<button className="btn btn-ghost no-print" onClick={() => window.print()}><Icon name="print" /> Imprimir</button>} />
    <Loaded s={s}>{(d: any) => <div className="stack">
      <div className="panel"><div className="panel-h"><h3>Participação por turma</h3><span className="small muted">sem comparação entre estudantes</span></div><div className="scroll-x"><table className="tbl"><thead><tr><th>Turma</th><th className="num">Estudantes</th><th className="num">Participaram</th><th className="num">Projetos ativos</th><th className="num">Concluídos</th><th className="num">Certificados</th></tr></thead><tbody>
        {d.byTurma.map((t: any) => <tr key={t.name}><td>{t.name}</td><td className="num">{t.students}</td><td className="num">{t.participants} ({pct(t.participants, t.students)}%)</td><td className="num">{t.active}</td><td className="num">{t.concluded}</td><td className="num">{t.certificates}</td></tr>)}</tbody></table></div></div>
      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="panel"><div className="panel-h"><h3><Icon name="chart" /> Projetos por situação</h3></div><div className="panel-b">{d.byStatus.length ? <Bars rows={d.byStatus.map((r: any) => [P_STATUS[r.status]?.[0] || r.status, r.n])} /> : <p className="small muted">Nenhum projeto.</p>}</div></div>
        <div className="panel"><div className="panel-h"><h3><Icon name="clip" /> Registro de ações da escola</h3></div>
          {d.audit.length ? <ul className="list" style={{ maxHeight: 420, overflow: 'auto' }}>{d.audit.map((a: any, i: number) => <li key={i}><div className="grow small"><b>{a.action}</b>{a.detail && <> · {a.detail}</>}<div className="muted">{a.user || '—'} ({ROLE_LABEL[a.role as keyof typeof ROLE_LABEL] || a.role || 'sistema'})</div></div><span className="small muted">{fmtDT(a.createdAt)}</span></li>)}</ul> : <p className="panel-b small muted">Sem registros.</p>}</div>
      </div></div>}</Loaded></>;
}
