import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { get } from '../api';
import { useAuth } from '../auth';
import { HOME, LEVEL, SLOGAN, fmtDate } from '../lib';
import markUrl from '../assets/mark.jpg';
import { Icon, LogoFull, useLoad, Loaded, Empty, Note, DemandPill, DemoTag } from '../ui';

const STEPS: [string, string, string][] = [
  ['building', 'Empresa verificada submete uma demanda', 'Uma necessidade real, de escopo limitado, adequada ao nível dos cursos técnicos.'],
  ['shield', 'Administração verifica e encaminha', 'A empresa é verificada e a demanda é moderada antes de chegar às escolas.'],
  ['cap', 'Professor avalia a adequação pedagógica', 'Relevância para o currículo, segurança dos estudantes e viabilidade.'],
  ['school', 'Escola autoriza a participação da turma', 'A coordenação aprova antes de o projeto começar.'],
  ['users', 'Turma desenvolve em equipe', 'Trabalho colaborativo nas atividades pedagógicas, com supervisão do professor.'],
  ['send', 'Equipe entrega pela plataforma', 'Entregas com versões, link e anexos protegidos.'],
  ['check', 'Professor valida e empresa dá retorno', 'Validação pedagógica e feedback construtivo, sem notas competitivas.'],
  ['award', 'Projeto entra no portfólio educacional', 'Com certificado verificável e respeito à autoria e à privacidade.'],
  ['brief', 'Oportunidades futuras', 'Vagas reais de empresas verificadas, com acompanhamento da escola e processos seletivos próprios.'],
];

export function Home() {
  const { user } = useAuth();
  const stats = useLoad(() => get('/public/stats'), []);
  const ds = useLoad(() => get<any[]>('/demands'), []);
  const s = stats.data;
  return <>
    <section className="hero"><div className="wrap hero-in"><div className="stack" style={{ gap: 18 }}>
      <span className="hero-name">Conecta<em>Tec</em> PI</span>
      <h1>Do primeiro projeto<br />à <span>primeira oportunidade.</span></h1>
      <p className="lead">Escolas estaduais de tempo integral do Piauí recebem demandas reais de empresas piauienses e as transformam em projetos pedagógicos colaborativos, desenvolvidos por estudantes dos cursos técnicos sob supervisão dos professores.</p>
      <div className="row">
        <Link className="btn btn-gold" to="/demandas"><Icon name="brief" /> Conheça as demandas</Link>
        {user ? <Link className="btn btn-light" to={HOME[user.role]}>Ir para meu painel</Link> : <>
          <Link className="btn btn-light" to="/entrar">Acesso institucional</Link>
          <Link className="btn btn-light" to="/cadastro/escola">Sou escola</Link>
          <Link className="btn btn-light" to="/cadastro/empresa">Sou empresa</Link></>}
      </div></div>
      <div className="hero-logo"><LogoFull max={440} /></div></div></section>
    {s && (s.schools > 0 || s.demands > 0) && <section className="wrap" style={{ paddingBlock: 24 }}><div className="grid g4">
      <div className="kpi"><span className="l">Escolas participantes</span><span className="n">{s.schools}</span></div>
      <div className="kpi"><span className="l">Empresas verificadas</span><span className="n">{s.companies}</span></div>
      <div className="kpi"><span className="l">Demandas disponíveis</span><span className="n">{s.demands}</span></div>
      <div className="kpi"><span className="l">Projetos concluídos</span><span className="n">{s.concluded}</span></div></div></section>}
    <section className="sec"><div className="wrap">
      <div className="sec-h"><span className="eyebrow">A escola no centro</span><h2>A escola organiza, protege e acompanha cada etapa</h2>
        <p className="muted">Estudantes não se cadastram sozinhos: a escola habilita as contas, o professor avalia cada demanda e a coordenação autoriza a participação da turma. Empresas nunca pesquisam estudantes nem acessam dados pessoais.</p></div>
      <div className="grid g3">
        <div className="card stack-sm"><h3><Icon name="school" /> Escola</h3><p className="small muted">Cadastra turmas, professores e estudantes, analisa as demandas recebidas, autoriza a participação e acompanha relatórios institucionais.</p></div>
        <div className="card stack-sm"><h3><Icon name="cap" /> Professor-orientador</h3><p className="small muted">Avalia a adequação pedagógica, organiza grupos colaborativos, media a comunicação com a empresa e valida as entregas.</p></div>
        <div className="card stack-sm"><h3><Icon name="building" /> Empresa</h3><p className="small muted">Apresenta necessidades reais, orienta pelo mural do projeto e dá retorno ao resultado final, sem acesso direto aos estudantes.</p></div>
      </div></div></section>
    <section className="sec" style={{ background: 'var(--surface-2)' }}><div className="wrap">
      <div className="sec-h"><span className="eyebrow">Como funciona</span><h2>Da demanda ao portfólio</h2></div>
      <div className="grid g3">{STEPS.slice(0, 8).map(([ic, t, d], i) => <div key={t} className="step"><div className="row" style={{ flexWrap: 'nowrap' }}><span className="num" style={{ fontSize: '1.6rem' }}>{i + 1}</span><h3 style={{ fontSize: '1rem' }}>{t}</h3></div><p className="muted small" style={{ marginTop: 6 }}>{d}</p></div>)}
        <div className="step" style={{ borderStyle: 'dashed' }}><div className="row" style={{ flexWrap: 'nowrap' }}><span className="num" style={{ fontSize: '1.6rem' }}>9</span><h3 style={{ fontSize: '1rem' }}>{STEPS[8][1]}</h3></div><p className="muted small" style={{ marginTop: 6 }}>{STEPS[8][2]} Etapa futura.</p></div>
      </div>
      <div style={{ marginTop: 16 }}><Link className="btn btn-ghost" to="/como-funciona">Ver o fluxo completo <Icon name="right" /></Link></div></div></section>
    <section className="sec"><div className="wrap"><div className="grid g2" style={{ alignItems: 'start' }}>
      <div className="stack"><div className="sec-h" style={{ margin: 0 }}><span className="eyebrow">Princípios</span><h2>Aprender junto, sem competição</h2></div>
        <ul className="stack-sm" style={{ margin: 0, paddingLeft: 18 }}>
          <li><b>Colaboração:</b> equipes trabalham juntas; não há ranking, pontuação competitiva ou premiação por colocação.</li>
          <li><b>Aprendizagem:</b> cada projeto parte do conteúdo curricular e da disponibilidade da turma.</li>
          <li><b>Inclusão:</b> o professor organiza grupos que valorizam a participação de todos.</li>
          <li><b>Responsabilidade:</b> demandas não substituem empregados ou serviços profissionais remunerados. Pedidos maiores são redimensionados ou encaminhados para contratação.</li>
        </ul></div>
      <div className="card stack-sm"><span className="eyebrow">Proteção dos estudantes</span><h3>Pensado para jovens de 14 a 18 anos</h3>
        <ul className="small" style={{ margin: 0, paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <li>Contas de estudantes criadas apenas pela escola</li><li>Nenhum chat privado entre empresa e estudante</li><li>Toda comunicação do projeto é visível ao professor, que pode moderar</li>
          <li>Telefones e e-mails escritos no mural são ocultados automaticamente</li><li>Empresas não veem nomes nem dados pessoais dos estudantes</li><li>Portfólio público só com autorização da escola</li><li>Registro de acessos e ações relevantes</li></ul>
        <div><Link className="btn btn-ghost btn-sm" to="/privacidade"><Icon name="shield" /> Política de privacidade</Link></div></div>
    </div></div></section>
    <section className="sec" style={{ paddingTop: 0 }}><div className="wrap"><div className="row between" style={{ marginBottom: 16 }}><div className="sec-h" style={{ margin: 0 }}><span className="eyebrow">Catálogo</span><h2>Demandas empresariais</h2></div><Link className="btn btn-ghost" to="/demandas">Ver catálogo <Icon name="right" /></Link></div>
      {ds.data && ds.data.length ? <div className="grid g3">{ds.data.slice(0, 3).map((d) => <DemandCardMini key={d.id} d={d} />)}</div>
        : <div className="panel"><Empty icon="brief" title="Novas demandas em breve" text="Empresas verificadas submetem demandas, que ficam visíveis aqui depois da moderação." /></div>}</div></section>
  </>;
}
function DemandCardMini({ d }: { d: any }) {
  return <div className="ch-card"><div className="row between"><span className="chip chip-petrol">{d.area}</span><DemandPill s={d.phase} /></div><h3>{d.title}</h3>
    <div className="co"><Icon name="building" />{d.company.name} · {d.city} <DemoTag on={d.isDemo} /></div><p className="small muted">{d.objectives}</p>
    <div className="foot"><span className="small muted">~{d.hours} h</span><Link className="btn btn-primary btn-sm" to={'/demandas/' + d.id}>Ver demanda</Link></div></div>;
}

export function ComoFunciona() {
  return <section className="sec"><div className="wrap stack" style={{ gap: 28 }}>
    <div className="sec-h"><span className="eyebrow">Fluxo institucional</span><h1>Como funciona o ConectaTec PI</h1><p className="muted">{SLOGAN} Cada projeto passa pela escola antes, durante e depois do desenvolvimento.</p></div>
    <ol className="panel list" style={{ margin: 0 }}>{STEPS.map(([ic, t, d], i) => <li key={t}><div className="row" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}><span className="avatar" style={{ background: i === 8 ? 'var(--surface-2)' : 'var(--petrol)', color: i === 8 ? 'var(--muted)' : '#fff' }}>{i + 1}</span>
      <div className="stack-sm" style={{ gap: 2 }}><b>{t}{i === 8 && ' (etapa futura)'}</b><span className="small muted">{d}</span></div></div><Icon name={ic} /></li>)}</ol>
    <div className="panel"><div className="panel-h"><h3>Quem faz o quê</h3></div><div className="scroll-x"><table className="tbl"><thead><tr><th>Perfil</th><th>Responsabilidades</th></tr></thead><tbody>
      <tr><td><b>Escola / gestor</b></td><td>Gerencia turmas, cursos, professores e estudantes autorizados; registra as autorizações dos responsáveis; analisa demandas; autoriza a participação; acompanha projetos; consulta relatórios; responde pedidos de correção.</td></tr>
      <tr><td><b>Professor-orientador</b></td><td>Avalia relevância pedagógica, segurança e viabilidade; organiza grupos e cronograma; media a comunicação no mural; valida as entregas e registra feedback.</td></tr>
      <tr><td><b>Estudante</b></td><td>Acessa com a conta habilitada pela escola; acompanha as atividades autorizadas; colabora com a equipe; envia entregas; consulta histórico e portfólio.</td></tr>
      <tr><td><b>Empresa</b></td><td>Submete demandas de escopo limitado; acompanha o andamento autorizado; orienta pelo mural; avalia o resultado com critérios claros; pode manifestar interesse em oportunidades futuras à escola.</td></tr>
      <tr><td><b>Administração da plataforma</b></td><td>Aprova escolas e empresas; modera demandas e vagas; gerencia permissões; acompanha indicadores e registros.</td></tr>
    </tbody></table></div></div>
    <Note icon="info">A participação em projetos não garante emprego. Oportunidades futuras dependem da existência de vagas, dos requisitos e dos processos seletivos de cada empresa, sempre com acompanhamento da escola.</Note>
  </div></section>;
}

export function Privacidade() {
  const H = ({ n, t, children }: { n: number; t: string; children: React.ReactNode }) => <div className="stack-sm"><h3>{n}. {t}</h3><p className="small">{children}</p></div>;
  return <section className="sec"><div className="wrap stack" style={{ maxWidth: 860 }}>
    <div className="sec-h"><span className="eyebrow">LGPD</span><h1>Política de privacidade</h1><p className="muted">Como o ConectaTec PI trata dados de estudantes, responsáveis, professores, gestores escolares e representantes de empresas.</p></div>
    <Note kind="warn" icon="alert">Texto-modelo. Antes do uso oficial, deve ser revisado pelo encarregado de dados (DPO) e pela assessoria jurídica da instituição responsável, que deve ser indicada como controladora. A plataforma não afirma conformidade jurídica completa sem essa avaliação.</Note>
    <div className="card stack">
      <H n={1} t="Dados coletados (coleta mínima)">Estudantes: nome, identificação interna da escola (ex.: matrícula), turma, curso, ano escolar, faixa etária, situação da autorização do responsável, entregas, mensagens no mural do projeto, validações e certificados. Professores e gestores: nome, e-mail institucional e vínculo escolar. Empresas: razão social, CNPJ (opcional), setor, município, descrição, nome e e-mail do responsável. Não são coletados telefone, endereço residencial, CPF, RG ou dados sensíveis.</H>
      <H n={2} t="Finalidade">Organizar projetos pedagógicos colaborativos a partir de demandas reais, acompanhar entregas, registrar validações, emitir certificados de participação e compor o portfólio educacional. Os dados não são vendidos nem usados para publicidade.</H>
      <H n={3} t="Base legal e autorizações">O tratamento ocorre no contexto das atividades educacionais da rede pública, com orientação institucional e jurídica. Para estudantes menores de idade, a escola registra a autorização dos responsáveis conforme seu procedimento oficial, e o tratamento observa o melhor interesse do adolescente (art. 14 da LGPD e ECA).</H>
      <H n={4} t="Quem vê o quê">A escola vê os dados dos seus estudantes. O professor vê os estudantes das suas turmas. Empresas veem apenas o nome da escola, a série e o curso da turma, o tamanho da equipe e os resultados autorizados — nunca nomes ou dados pessoais dos estudantes. A administração da plataforma vê dados necessários à gestão e à segurança.</H>
      <H n={5} t="Comunicação">Não existe chat privado. A comunicação de cada projeto acontece no mural, acessível ao professor responsável, que pode ocultar mensagens. Telefones e e-mails são ocultados automaticamente e geram sinalização para a escola.</H>
      <H n={6} t="Portfólio público">Só existe com autorização da escola e escolha do estudante. Mostra nome abreviado, escola, curso, projetos, competências e certificados. Não mostra identificação interna, login, responsável, telefone ou endereço.</H>
      <H n={7} t="Seus direitos">Na página "Conta", qualquer usuário pode baixar uma cópia dos seus dados e pedir correção, remoção de informações ou exclusão da conta. Pedidos de estudantes e professores são respondidos pela escola; os demais, pela administração.</H>
      <H n={8} t="Segurança e registros">Senhas criptografadas (bcrypt), sessões que expiram, permissões verificadas no servidor, anexos acessíveis somente a quem tem permissão e registro de acessos e ações relevantes.</H>
      <H n={9} t="Retenção">Os dados são mantidos enquanto a conta estiver ativa ou pelo período definido pela instituição responsável. Contas excluídas têm os dados pessoais removidos; entregas da equipe permanecem sem identificação do autor.</H>
    </div></div></section>;
}

export function Termos() {
  return <section className="sec"><div className="wrap stack" style={{ maxWidth: 860 }}>
    <div className="sec-h"><span className="eyebrow">Regras de uso</span><h1>Termos de uso</h1></div>
    <Note kind="warn" icon="alert">Texto-modelo, a ser revisado pela assessoria jurídica da instituição responsável antes do uso oficial.</Note>
    <div className="card stack small">
      <p><b>Natureza pedagógica.</b> Os projetos são atividades educacionais supervisionadas, sem competição entre estudantes ou equipes, sem rankings e sem premiação por colocação. Não configuram estágio, emprego ou prestação de serviço.</p>
      <p><b>Escopo das demandas.</b> Empresas apresentam necessidades reais de escopo limitado. É vedado usar a plataforma para obter trabalho gratuito que substitua empregados ou serviços profissionais remunerados. Demandas maiores devem ser redimensionadas ou encaminhadas para contratação adequada. A administração e a escola podem recusar ou pedir ajustes.</p>
      <p><b>Escolas</b> cadastram e gerenciam os estudantes autorizados, registram as autorizações dos responsáveis, analisam e autorizam a participação das turmas e respondem pedidos de correção.</p>
      <p><b>Professores</b> avaliam a adequação pedagógica, organizam os grupos, mediam a comunicação e validam as entregas.</p>
      <p><b>Estudantes</b> entregam trabalhos produzidos pela equipe, citam fontes, respeitam colegas e não compartilham dados pessoais nos murais.</p>
      <p><b>Empresas</b> não fazem contato privado com estudantes, mantêm a comunicação no mural do projeto, dão feedback construtivo e não prometem contratação. Os resultados não podem ser usados comercialmente sem acordo formal com a escola, respeitando a autoria dos estudantes.</p>
      <p>Condutas que violem estes termos podem levar à suspensão do acesso.</p>
    </div></div></section>;
}

export function CertificateVerify() {
  const { code } = useParams();
  const nav = useNavigate();
  const [input, setInput] = useState(code || '');
  const s = useLoad(() => (code ? get('/public/certificates/' + encodeURIComponent(code)) : Promise.resolve(null)), [code]);
  return <section className="sec"><div className="wrap stack" style={{ maxWidth: 720 }}>
    <div className="sec-h"><span className="eyebrow">Certificados</span><h1>Verificar certificado</h1><p className="muted">Digite o código impresso no certificado para confirmar que ele foi emitido pelo ConectaTec PI.</p></div>
    <form className="row" onSubmit={(e) => { e.preventDefault(); if (input.trim()) nav('/certificado/' + input.trim().toUpperCase()); }}>
      <input type="text" aria-label="Código do certificado" placeholder="CTPI-XXXXXXXXXX" value={input} onChange={(e) => setInput(e.target.value)} style={{ maxWidth: 320 }} />
      <button className="btn btn-primary" type="submit"><Icon name="search" /> Verificar</button></form>
    {code && (s.loading ? <div className="skel" style={{ height: 160 }} /> : s.error ? <Note kind="danger" icon="alert">{s.error}</Note> : s.data && <CertificateCard c={s.data} />)}
  </div></section>;
}
export function CertificateCard({ c }: { c: any }) {
  return <div className="cert">{c.isDemo && <div className="wm">DEMONSTRAÇÃO<br />DADOS FICTÍCIOS</div>}
    <div className="row" style={{ justifyContent: 'center' }}><img className="mark" src={markUrl} width={48} height={48} alt="" /></div>
    <span className="eyebrow">ConectaTec PI · Certificado de participação em projeto colaborativo</span><h3>{c.studentName}</h3>
    <p className="small">participou do projeto <b>"{c.projectTitle}"</b>, desenvolvido por estudantes do <b>{c.schoolName}</b> a partir de demanda apresentada por {c.companyName}, com carga estimada de {c.hours} horas.</p>
    {c.competencies?.length > 0 && <p className="small muted">Competências desenvolvidas: {c.competencies.join(', ')}</p>}
    <div className="row between small" style={{ marginTop: 10 }}><span>Emitido em {fmtDate(c.createdAt)}</span><span className="mono">{c.code}</span></div>
    <span className="chip chip-petrol" style={{ alignSelf: 'center' }}><Icon name="check" /> Certificado válido</span>
    <p className="small muted">Certificado de participação em atividade pedagógica. Não substitui diploma ou certificação oficial do curso técnico.</p></div>;
}

export function PublicPortfolio() {
  const { slug } = useParams();
  const s = useLoad(() => get('/public/portfolio/' + encodeURIComponent(slug || '')), [slug]);
  return <section className="sec"><div className="wrap"><Loaded s={s}>{(p) => <PortfolioView p={p} publicView />}</Loaded></div></section>;
}

export function PortfolioView({ p, publicView, onCert }: { p: any; publicView?: boolean; onCert?: (c: any) => void }) {
  return <div className="stack">
    <div className="card" style={{ background: 'var(--brand)', color: 'var(--on-brand)', borderColor: 'transparent' }}><div className="row" style={{ gap: 16 }}>
      <span className="avatar" style={{ width: 64, height: 64, fontSize: '1.3rem' }}>{p.name.split(' ').map((x: string) => x[0]).slice(0, 2).join('')}</span>
      <div className="stack-sm minw0" style={{ flex: '1 1 240px' }}><div className="row"><h2>{p.name}</h2><DemoTag on={p.isDemo} /></div><span>{p.course} · {p.year} · {p.schoolName} ({p.city})</span>
        {!publicView && <span className="small" style={{ opacity: .75 }}>Identificação interna: {p.code || '—'} · usuário {p.login} (visível só para você e para a escola)</span>}</div>
      <div className="row">{[[p.projects.length, 'projetos concluídos'], [p.projects.filter((x: any) => x.certificate).length, 'certificados'], [p.competencies.length, 'competências']].map(([n, l]) =>
        <div key={l as string} style={{ textAlign: 'center', padding: '6px 12px', borderLeft: '1px solid rgba(255,255,255,.2)' }}><div style={{ fontFamily: 'var(--f-display)', fontWeight: 800, fontSize: '1.6rem', lineHeight: 1 }}>{n}</div><div className="small" style={{ opacity: .8 }}>{l}</div></div>)}</div></div></div>
    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,380px),1fr))', alignItems: 'start' }}>
      <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Projetos concluídos</h3></div>
        {p.projects.length ? <ul className="list">{p.projects.map((x: any, i: number) => <li key={i}><div className="grow stack-sm">
          <b>{x.title}</b>
          <span className="small muted">Projeto desenvolvido por estudantes do {x.schoolName}, a partir de demanda de {x.companyName} · equipe de {x.teamSize} · {fmtDate(x.concludedAt)}</span>
          {x.description && <p className="small">{x.description}</p>}
          <div className="row">{x.techs.map((t: string) => <span key={t} className="chip">{t}</span>)}</div>
          {x.competencies.length > 0 && <div className="row">{x.competencies.map((c: string) => <span key={c} className="chip chip-petrol"><Icon name="check" /> {c}</span>)}</div>}
          {x.teacherFeedback && <p className="small muted" style={{ borderLeft: '3px solid var(--petrol)', paddingLeft: 10 }}>"{x.teacherFeedback}" — Professor(a)-orientador(a)</p>}
          {x.companyFeedback && <p className="small muted" style={{ borderLeft: '3px solid var(--gold-fill)', paddingLeft: 10 }}>"{x.companyFeedback}" — {x.companyName}</p>}
          {x.companyCriteria && <div className="small">{Object.entries(x.companyCriteria).map(([k, v]) => <div key={k}>{k}: <b>{LEVEL[v as string]}</b></div>)}</div>}
          {x.certificate && (onCert ? <div><button className="btn btn-ghost btn-sm" onClick={() => onCert({ ...x.certificate, studentName: p.name, projectTitle: x.demandTitle, schoolName: x.schoolName, companyName: x.companyName, hours: x.hours, competencies: x.competencies, isDemo: p.isDemo })}><Icon name="award" /> Ver certificado</button></div>
            : <Link className="small" to={'/certificado/' + x.certificate.code}><Icon name="award" /> Certificado {x.certificate.code}</Link>)}
        </div></li>)}</ul> : <Empty icon="folder" title="Nenhum projeto concluído ainda" text="Projetos validados pelo professor aparecem aqui depois de concluídos." />}</div>
      <div className="panel"><div className="panel-h"><h3><Icon name="target" /> Competências e tecnologias</h3></div><div className="panel-b stack-sm">
        <span className="eyebrow">Competências desenvolvidas</span><div className="row">{p.competencies.length ? p.competencies.map((x: string) => <span key={x} className="chip chip-petrol">{x}</span>) : <span className="small muted">Registradas pelo professor na validação dos projetos.</span>}</div>
        <span className="eyebrow" style={{ marginTop: 8 }}>Tecnologias usadas</span><div className="row">{p.techs.length ? p.techs.map((x: string) => <span key={x} className="chip">{x}</span>) : <span className="small muted">—</span>}</div></div></div>
    </div></div>;
}

export function NotFound() {
  return <section className="sec"><div className="wrap"><div className="panel"><Empty icon="search" title="Página não encontrada" text="O endereço pode ter mudado. Volte para a página inicial."><Link className="btn btn-primary btn-sm" to="/">Página inicial</Link></Empty></div></div></section>;
}
