import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { get, put } from '../api';
import { useAuth } from '../auth';
import { firstName, fmtDate } from '../lib';
import { Icon, Kpi, Empty, Note, PageHead, StatusPill, ConsentPill, DemoTag, useLoad, Loaded, useUi, Modal, copyText, ActionButton } from '../ui';
import { PortfolioView, CertificateCard } from './public';
import { appUrl } from '../env';

export function StPainel() {
  const { user, school, turma } = useAuth();
  const s = useLoad(() => get('/student/dashboard'), []);
  return <Loaded s={s}>{(d: any) => {
    const active = d.projects.filter((p: any) => p.status !== 'concluido'), done = d.projects.filter((p: any) => p.status === 'concluido');
    const next = active.flatMap((p: any) => (p.milestones || []).filter((m: any) => !m.done).map((m: any) => ({ ...m, project: p.title, id: p.id }))).sort((a: any, b: any) => (a.dueDate < b.dueDate ? -1 : 1)).slice(0, 5);
    return <>
      <PageHead title={'Olá, ' + firstName(user!.name) + '!'} eyebrow={`${turma?.name || 'Sem turma'} · ${school?.name || ''}`} actions={<Link className="btn btn-ghost" to="/estudante/portfolio"><Icon name="award" /> Meu portfólio</Link>} />
      {user!.consentStatus === 'pendente' && <div style={{ marginBottom: 16 }}><Note kind="warn" icon="shield">A escola ainda está registrando a autorização do seu responsável. Até lá, você não pode ser incluído(a) em equipes de projeto.</Note></div>}
      <div className="grid g4" style={{ marginBottom: 20 }}>
        <Kpi n={active.filter((p: any) => p.status === 'em_andamento').length} l="Em desenvolvimento" s="projetos da sua equipe" />
        <Kpi n={active.filter((p: any) => ['entregue', 'validado'].includes(p.status)).length} l="Em validação" s="aguardando professor ou empresa" />
        <Kpi n={done.length} l="Concluídos" s="no seu portfólio" />
        <Kpi n={d.certificates} l="Certificados" s="verificáveis" />
      </div>
      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Meus projetos</h3></div>
            {d.projects.length ? <ul className="list">{d.projects.map((p: any) => <li key={p.id}><div className="grow stack-sm">
              <div className="row between"><b>{p.title}</b><StatusPill s={p.status} /></div>
              <span className="small muted">Demanda de {p.companyName} <DemoTag on={p.isDemo} /></span>
              {p.lastReview && <p className="small" style={{ borderLeft: '3px solid ' + (p.lastReview.kind === 'ajustes' ? 'var(--warn)' : 'var(--petrol)'), paddingLeft: 10 }}>
                <b>{p.lastReview.kind === 'ajustes' ? 'Ajustes pedidos pelo professor' : p.lastReview.role === 'company' ? 'Retorno da empresa' : 'Validação do professor'}:</b> {p.lastReview.text}</p>}
              <div><Link className={'btn btn-sm ' + (p.status === 'em_andamento' ? 'btn-primary' : 'btn-ghost')} to={'/projetos/' + p.id}>{p.status === 'em_andamento' ? <><Icon name="send" /> Abrir e entregar</> : 'Abrir projeto'}</Link></div>
            </div></li>)}</ul> : <Empty icon="folder" title="Você ainda não está em uma equipe" text="Quando o professor organizar uma equipe com você, o projeto aparece aqui." />}</div>
          {d.turmaProjects.length > 0 && <div className="panel"><div className="panel-h"><h3><Icon name="users" /> Outras atividades autorizadas para a turma</h3></div>
            <ul className="list">{d.turmaProjects.map((p: any) => <li key={p.id}><div className="grow"><b>{p.title}</b><div className="small muted">{p.companyName}</div></div><div className="row"><StatusPill s={p.status} /><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}>Ver resumo</Link></div></li>)}</ul></div>}
        </div>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="calendar" /> Próximas etapas</h3></div>
            {next.length ? <ul className="list">{next.map((m: any, i: number) => <li key={i}><div className="grow"><b>{m.title}</b><div className="small muted">{m.project}</div></div><span className="chip"><Icon name="clock" /> {fmtDate(m.dueDate)}</span></li>)}</ul>
              : <Empty icon="calendar" title="Nenhuma etapa pendente" text="O cronograma dos projetos em andamento aparece aqui." />}</div>
          <div className="card stack-sm"><h3><Icon name="school" /> Seu acesso</h3><dl className="dl"><dt>Escola</dt><dd>{d.school?.name}</dd><dt>Turma</dt><dd>{d.turma?.name || '—'}</dd><dt>Orientação</dt><dd>{d.turma?.teacher_name || '—'}</dd><dt>Autorização</dt><dd><ConsentPill s={user!.consentStatus} /></dd></dl>
            <p className="small muted">Sua conta foi habilitada pela escola. Dados incorretos? Peça correção em <Link to="/conta">Conta</Link>.</p></div>
        </div>
      </div></>;
  }}</Loaded>;
}

export function StPortfolio() {
  const { toast } = useUi();
  const [pub, setPub] = useState(false);
  const [cert, setCert] = useState<any>(null);
  const me = useLoad(() => get('/student/portfolio'), []);
  const view = useLoad(() => (pub ? get('/student/portfolio?view=public') : Promise.resolve(null)), [pub]);
  const p = me.data;
  const link = p?.publicSlug ? appUrl('/p/' + p.publicSlug) : '';
  return <>
    <PageHead title="Portfólio educacional" eyebrow={pub ? 'Como visitantes veriam (simulação)' : 'Seus projetos concluídos'} actions={<>
      <button className="btn btn-ghost" onClick={() => setPub(!pub)} aria-pressed={pub}><Icon name="eye" /> {pub ? 'Voltar à minha visão' : 'Ver versão pública'}</button>
      <button className="btn btn-ghost no-print" onClick={() => window.print()}><Icon name="print" /> Imprimir / salvar PDF</button></>} />
    {p && <div className="card stack-sm" style={{ marginBottom: 16 }}>
      {p.publicAllowed ? <>
        <div className="row between"><b>Portfólio público</b><span className={'pill ' + (p.isPublic ? 'st-done' : 'st-avail')}>{p.isPublic ? 'Ativo' : 'Desativado'}</span></div>
        <p className="small muted">A escola autorizou a publicação. O link mostra nome abreviado, escola, curso, projetos, competências e certificados — sem login, identificação interna ou dados pessoais.</p>
        <div className="row"><ActionButton className={'btn btn-sm ' + (p.isPublic ? 'btn-ghost' : 'btn-primary')} action={async () => { await put('/student/portfolio', { public: !p.isPublic }); toast(p.isPublic ? 'Portfólio público desativado.' : 'Portfólio público ativado.'); me.reload(true); }}>{p.isPublic ? 'Desativar link público' : 'Ativar link público'}</ActionButton>
          {p.isPublic && <button className="btn btn-ghost btn-sm" onClick={() => copyText(link, toast)}><Icon name="copy" /> Copiar link</button>}</div>
        {p.isPublic && <span className="small mono" style={{ wordBreak: 'break-all' }}>{link}</span>}
      </> : <p className="small"><Icon name="lock" /> O portfólio é visível só para você e para a escola. A publicação depende de autorização institucional da escola.</p>}
    </div>}
    {pub ? <Loaded s={view}>{(v) => <PortfolioView p={v} publicView />}</Loaded>
      : <Loaded s={me}>{(v) => <PortfolioView p={v} onCert={setCert} />}</Loaded>}
    {cert && <Modal title="Certificado de participação" onClose={() => setCert(null)} foot={<><button className="btn btn-ghost" onClick={() => copyText(appUrl('/certificado/' + cert.code), toast)}><Icon name="copy" /> Copiar link de verificação</button><button className="btn btn-primary" onClick={() => setCert(null)}>Fechar</button></>}>
      <CertificateCard c={cert} /></Modal>}
  </>;
}
