import React from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { post } from '../api';
import { useAuth } from '../auth';
import { HOME } from '../lib';
import { Icon, LogoFull, Form, Field, Input, Textarea, Check, Submit, Note, useUi, ActionButton } from '../ui';

export const fdStr = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();
export const fdBool = (fd: FormData, k: string) => fd.get(k) === 'true';
export const pwRule = (pw: string) => (pw.length < 8 || !/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) ? 'Use pelo menos 8 caracteres, com letras e números.' : '';

export function Login() {
  const { user, setSession } = useAuth();
  const { toast } = useUi();
  const nav = useNavigate();
  const loc = useLocation() as any;
  if (user) return <Navigate to={user.mustChangePassword ? '/trocar-senha' : HOME[user.role]} replace />;
  const done = (d: any) => {
    setSession(d); toast('Bem-vindo(a), ' + d.user.name.split(' ')[0] + '!');
    nav(d.user.mustChangePassword ? '/trocar-senha' : (loc.state?.from || HOME[d.user.role as keyof typeof HOME]), { replace: true });
  };
  return <section className="sec"><div className="wrap grid g2" style={{ alignItems: 'start', gap: 28 }}>
    <div className="card stack">
      <div style={{ display: 'flex', justifyContent: 'center', background: '#FDFCF8', borderRadius: 10, padding: 12 }}><LogoFull max={240} /></div>
      <div className="stack-sm"><span className="eyebrow">Login institucional</span><h2>Entrar no ConectaTec PI</h2>
        <p className="small muted">Estudantes usam o usuário e a senha fornecidos pela escola. Escolas, professores e empresas usam o e-mail cadastrado.</p></div>
      <Form onSubmit={async (fd) => done(await post('/auth/login', { login: fdStr(fd, 'login'), password: String(fd.get('password') || '') }))}>
        <Field name="login" label="E-mail ou usuário institucional" required><Input name="login" type="text" autoComplete="username" autoCapitalize="none" req="Informe o e-mail ou usuário." /></Field>
        <Field name="password" label="Senha" required><Input name="password" type="password" autoComplete="current-password" req="Informe a senha." /></Field>
        <Submit busyLabel="Entrando…"><Icon name="lock" /> Entrar</Submit>
      </Form>
      <p className="small muted">Esqueceu a senha? Estudantes e professores: procure a coordenação da escola. Escolas e empresas: fale com a administração da plataforma.</p>
    </div>
    <div className="stack">
      <div className="card stack-sm"><h3><Icon name="school" /> Sou escola</h3><p className="small muted">A escola solicita o acesso institucional. Depois da aprovação, cadastra professores, turmas e estudantes.</p><div><Link className="btn btn-primary btn-sm" to="/cadastro/escola">Solicitar acesso institucional</Link></div></div>
      <div className="card stack-sm"><h3><Icon name="building" /> Sou empresa</h3><p className="small muted">Cadastre a empresa. A administração verifica o cadastro antes de você submeter demandas.</p><div><Link className="btn btn-ghost btn-sm" to="/cadastro/empresa">Cadastrar empresa</Link></div></div>
      <Note icon="cap">Estudantes não criam conta: o acesso é habilitado pela escola.</Note>
    </div></div></section>;
}

export function CadEscola() {
  const { setSession, user } = useAuth();
  const { toast } = useUi();
  const nav = useNavigate();
  if (user) return <Navigate to={HOME[user.role]} replace />;
  return <section className="sec"><div className="wrap" style={{ maxWidth: 820 }}>
    <Link className="back link-plain" to="/entrar"><Icon name="left" /> Voltar para o acesso</Link>
    <div className="phead"><div className="t"><span className="eyebrow">Acesso institucional</span><h1>Solicitar acesso da escola</h1></div></div>
    <div className="card"><Form validate={(fd) => { const e: Record<string, string> = {}; const pw = String(fd.get('password') || ''); if (pw && pwRule(pw)) e.password = pwRule(pw); return e; }}
      onSubmit={async (fd) => {
        const d = await post('/auth/register/school', { schoolName: fdStr(fd, 'schoolName'), city: fdStr(fd, 'city'), inep: fdStr(fd, 'inep'), name: fdStr(fd, 'name'), role: fdStr(fd, 'role'), email: fdStr(fd, 'email'), password: String(fd.get('password')), terms: fdBool(fd, 'terms') });
        setSession(d); toast('Solicitação enviada para aprovação da administração.'); nav('/escola', { replace: true });
      }}>
      <Note icon="info">A administração da plataforma confere a solicitação antes de liberar o cadastro de professores, turmas e estudantes.</Note>
      <div className="grid g2">
        <Field name="schoolName" label="Nome da escola" required><Input name="schoolName" type="text" maxLength={120} req placeholder="CETI ..." /></Field>
        <Field name="city" label="Município" required><Input name="city" type="text" maxLength={60} req /></Field>
        <Field name="inep" label="Código INEP" hint="opcional, 8 dígitos"><Input name="inep" type="text" inputMode="numeric" maxLength={8} /></Field>
        <Field name="name" label="Nome do responsável" required><Input name="name" type="text" maxLength={80} req /></Field>
        <Field name="role" label="Cargo" required><Input name="role" type="text" maxLength={80} req placeholder="Diretor(a), coordenador(a) pedagógico(a)…" /></Field>
        <Field name="email" label="E-mail institucional" required><Input name="email" type="email" req /></Field>
        <Field name="password" label="Senha" hint="mínimo de 8 caracteres, com letras e números" required><Input name="password" type="password" autoComplete="new-password" req /></Field>
      </div>
      <Check name="terms" req="Confirme que você está autorizado(a) pela direção da escola.">Declaro que estou autorizado(a) pela direção da escola a solicitar este acesso e li os <Link to="/termos" target="_blank">termos de uso</Link> e a <Link to="/privacidade" target="_blank">política de privacidade</Link>. *</Check>
      <div className="row"><Submit><Icon name="send" /> Enviar solicitação</Submit><Link className="btn btn-ghost" to="/entrar">Cancelar</Link></div>
    </Form></div></div></section>;
}

export function CadEmpresa() {
  const { setSession, user } = useAuth();
  const { toast } = useUi();
  const nav = useNavigate();
  if (user) return <Navigate to={HOME[user.role]} replace />;
  return <section className="sec"><div className="wrap" style={{ maxWidth: 820 }}>
    <Link className="back link-plain" to="/entrar"><Icon name="left" /> Voltar para o acesso</Link>
    <div className="phead"><div className="t"><span className="eyebrow">Cadastro empresarial</span><h1>Cadastrar empresa</h1></div></div>
    <div className="card"><Form validate={(fd) => { const e: Record<string, string> = {}; const pw = String(fd.get('password') || ''); if (pw && pwRule(pw)) e.password = pwRule(pw); const d = fdStr(fd, 'description'); if (d && d.length < 40) e.description = 'Use pelo menos 40 caracteres.'; return e; }}
      onSubmit={async (fd) => {
        const d = await post('/auth/register/company', { name: fdStr(fd, 'name'), cnpj: fdStr(fd, 'cnpj'), sector: fdStr(fd, 'sector'), city: fdStr(fd, 'city'), description: fdStr(fd, 'description'), responsibleName: fdStr(fd, 'responsibleName'), email: fdStr(fd, 'email'), password: String(fd.get('password')), terms: fdBool(fd, 'terms') });
        setSession(d); toast('Cadastro enviado para verificação.'); nav('/empresa', { replace: true });
      }}>
      <Note icon="info">O acesso das empresas é separado do acesso escolar. A administração verifica o cadastro antes de liberar o envio de demandas.</Note>
      <div className="grid g2">
        <Field name="name" label="Nome da empresa" required><Input name="name" type="text" maxLength={80} req /></Field>
        <Field name="cnpj" label="CNPJ" hint="ajuda na verificação"><Input name="cnpj" type="text" inputMode="numeric" maxLength={18} /></Field>
        <Field name="sector" label="Setor" required><Input name="sector" type="text" maxLength={60} req placeholder="Comércio, saúde, tecnologia…" /></Field>
        <Field name="city" label="Município (PI)" required><Input name="city" type="text" maxLength={60} req /></Field>
        <Field name="responsibleName" label="Responsável pelas demandas" required><Input name="responsibleName" type="text" maxLength={80} req /></Field>
        <Field name="email" label="E-mail de acesso" required><Input name="email" type="email" req /></Field>
        <Field name="password" label="Senha" hint="mínimo de 8 caracteres, com letras e números" required><Input name="password" type="password" autoComplete="new-password" req /></Field>
      </div>
      <Field name="description" label="Descrição da empresa" hint="mínimo de 40 caracteres" required><Textarea name="description" maxLength={800} req /></Field>
      <Check name="terms" req="É preciso aceitar os compromissos com a escola e os estudantes.">Concordo com os <Link to="/termos" target="_blank">termos de uso</Link>: não fazer contato privado com estudantes, manter a comunicação no mural do projeto, não usar a plataforma para substituir trabalho remunerado e não prometer contratação. *</Check>
      <div className="row"><Submit><Icon name="send" /> Enviar para verificação</Submit><Link className="btn btn-ghost" to="/entrar">Cancelar</Link></div>
    </Form></div></div></section>;
}

export function ChangePassword() {
  const { user, refresh } = useAuth();
  const { toast } = useUi();
  const nav = useNavigate();
  if (!user) return <Navigate to="/entrar" replace />;
  return <div className="center-page"><div className="card stack">
    <div className="stack-sm"><span className="eyebrow">Segurança</span><h2>{user.mustChangePassword ? 'Crie sua senha' : 'Trocar senha'}</h2>
      {user.mustChangePassword && <p className="small muted">Você entrou com uma senha temporária fornecida {user.role === 'student' ? 'pela escola' : 'pela administração'}. Crie uma senha pessoal para continuar.</p>}</div>
    <PasswordForm onDone={async () => { await refresh(); toast('Senha alterada.'); nav(HOME[user.role], { replace: true }); }} />
  </div></div>;
}
export function PasswordForm({ onDone }: { onDone: () => Promise<void> | void }) {
  return <Form validate={(fd) => { const e: Record<string, string> = {}; const pw = String(fd.get('newPassword') || ''); if (pw && pwRule(pw)) e.newPassword = pwRule(pw); if (pw !== String(fd.get('confirm') || '')) e.confirm = 'As senhas não conferem.'; return e; }}
    onSubmit={async (fd, form) => { await post('/auth/change-password', { current: String(fd.get('current')), newPassword: String(fd.get('newPassword')) }); form.reset(); await onDone(); }}>
    <Field name="current" label="Senha atual" required><Input name="current" type="password" autoComplete="current-password" req /></Field>
    <Field name="newPassword" label="Nova senha" hint="mínimo de 8 caracteres, com letras e números" required><Input name="newPassword" type="password" autoComplete="new-password" req /></Field>
    <Field name="confirm" label="Confirmar nova senha" required><Input name="confirm" type="password" autoComplete="new-password" req /></Field>
    <div><Submit><Icon name="key" /> Salvar nova senha</Submit></div>
  </Form>;
}
