import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { get, post, put, del } from '../api';
import { useAuth } from '../auth';
import { REQ_KIND, ROLE_LABEL, fmtDate, fmtDT } from '../lib';
import { Icon, Kpi, Bars, Empty, Note, PageHead, OrgPill, DemandPill, OppPill, DemoTag, useLoad, Loaded, Form, Field, Input, Textarea, Submit, ActionButton, useUi, Modal, copyText } from '../ui';

export function AdPainel() {
  const s = useLoad(() => get('/admin/dashboard'), []);
  return <Loaded s={s}>{(d: any) => { const k = d.kpis; return <>
    <PageHead title="Visão geral da plataforma" eyebrow="Administração" />
    <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,170px),1fr))', marginBottom: 20 }}>
      <Kpi n={k.schools} l="Escolas aprovadas" s={k.students + ' estudantes · ' + k.teachers + ' professores'} /><Kpi n={k.companies} l="Empresas verificadas" />
      <Kpi n={k.demands} l="Demandas disponíveis" /><Kpi n={k.active_projects} l="Projetos em andamento" /><Kpi n={k.concluded} l="Projetos concluídos" />
      <Kpi n={k.flags + k.requests} l="Pendências de segurança" s={`${k.flags} sinalizações · ${k.requests} pedidos`} />
    </div>
    <div className="grid g3" style={{ alignItems: 'start', marginBottom: 16 }}>
      <div className="panel"><div className="panel-h"><h3><Icon name="school" /> Escolas aguardando</h3><Link to="/admin/cadastros">Analisar</Link></div>
        {d.pendingSchools.length ? <ul className="list">{d.pendingSchools.map((x: any) => <li key={x.id}><div className="grow"><b>{x.name}</b><div className="small muted">{x.city} · {fmtDate(x.created_at)}</div></div><OrgPill s={x.status} /></li>)}</ul> : <p className="panel-b small muted">Nenhuma.</p>}</div>
      <div className="panel"><div className="panel-h"><h3><Icon name="building" /> Empresas aguardando</h3><Link to="/admin/cadastros?tab=empresas">Analisar</Link></div>
        {d.pendingCompanies.length ? <ul className="list">{d.pendingCompanies.map((x: any) => <li key={x.id}><div className="grow"><b>{x.name}</b><div className="small muted">{x.sector} · {x.city}</div></div><OrgPill s={x.status} /></li>)}</ul> : <p className="panel-b small muted">Nenhuma.</p>}</div>
      <div className="panel"><div className="panel-h"><h3><Icon name="brief" /> Para moderar</h3><Link to="/admin/demandas">Moderar</Link></div>
        {d.pendingDemands.length || d.pendingOpps ? <ul className="list">{d.pendingDemands.map((x: any) => <li key={x.id}><div className="grow"><b>{x.title}</b><div className="small muted">Demanda · {x.companyName}</div></div></li>)}
          {d.pendingOpps > 0 && <li><div className="grow"><b>{d.pendingOpps} vaga(s)</b><div className="small muted">aguardando moderação</div></div></li>}</ul> : <p className="panel-b small muted">Nada pendente.</p>}</div>
    </div>
    <div className="grid g2" style={{ alignItems: 'start' }}>
      <div className="panel"><div className="panel-h"><h3>Indicadores por município</h3><span className="small muted">dados registrados na plataforma</span></div><div className="scroll-x"><table className="tbl"><thead><tr><th>Município</th><th className="num">Escolas</th><th className="num">Estudantes</th><th className="num">Em andamento</th><th className="num">Concluídos</th></tr></thead>
        <tbody>{d.byCity.map((r: any) => <tr key={r.city}><td>{r.city}</td><td className="num">{r.schools}</td><td className="num">{r.students}</td><td className="num">{r.active}</td><td className="num">{r.concluded}</td></tr>)}</tbody></table></div></div>
      <div className="stack">
        <div className="panel"><div className="panel-h"><h3><Icon name="chart" /> Projetos por área técnica</h3></div><div className="panel-b"><Bars rows={d.byArea.map((r: any) => [r.area, r.projects])} /></div></div>
        <div className="panel"><div className="panel-h"><h3><Icon name="clock" /> Atividade recente</h3><Link to="/admin/registros">Registros</Link></div><ul className="list">{d.activity.map((a: any, i: number) => <li key={i}><div className="grow small"><b>{a.action}</b>{a.detail && ` · ${a.detail}`}<div className="muted">{a.user || 'sistema'}</div></div><span className="small muted">{fmtDT(a.createdAt)}</span></li>)}</ul></div>
      </div>
    </div></>; }}</Loaded>;
}

function Decision({ options, onDecide }: { options: [string, string, string][]; onDecide: (v: string, note: string) => Promise<void> }) {
  const v = useRef(options[0][0]);
  return <Form className="stack-sm" onSubmit={async (fd) => { await onDecide(v.current, String(fd.get('note') || '').trim()); }}>
    <Field name="note" label="Observação" hint="obrigatória para ajustes ou rejeição"><Input name="note" type="text" maxLength={400} /></Field>
    <div className="row">{options.map(([val, label, cls]) => <Submit key={val} className={'btn btn-sm ' + cls} onClick={() => { v.current = val; }} busyLabel="Salvando…">{label}</Submit>)}</div>
  </Form>;
}

export function AdCadastros() {
  const { toast } = useUi();
  const [tab, setTab] = useState(new URLSearchParams(location.search).get('tab') === 'empresas' ? 'empresas' : 'escolas');
  const [f, setF] = useState('pendente');
  const schools = useLoad(() => get<any[]>('/admin/schools'), []);
  const companies = useLoad(() => get<any[]>('/admin/companies'), []);
  const flt = (x: any) => f === 'todas' || x.status === f || (f === 'pendente' && x.status === 'ajustes');
  const filters = <div className="row" style={{ marginBottom: 12 }}>{[['pendente', 'Aguardando'], ['aprovada', 'Aprovadas'], ['rejeitada', 'Rejeitadas'], ['todas', 'Todas']].map(([k, l]) => <button key={k} className={'btn btn-sm ' + (f === k ? 'btn-primary' : 'btn-ghost')} onClick={() => setF(k)}>{l}</button>)}</div>;
  const opts: [string, string, string][] = [['aprovada', 'Aprovar', 'btn-primary'], ['ajustes', 'Solicitar ajustes', 'btn-ghost'], ['rejeitada', 'Rejeitar', 'btn-danger']];
  return <><PageHead title="Escolas e empresas" eyebrow="Aprovação de acessos" />
    <div className="tabs" role="tablist">{[['escolas', 'Escolas'], ['empresas', 'Empresas']].map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    {filters}
    {tab === 'escolas' ? <Loaded s={schools}>{(list) => { const r = list.filter(flt); return r.length ? <div className="stack">{r.map((x) => <div key={x.id} className="panel"><div className="panel-h"><div className="row"><h3>{x.name}</h3><DemoTag on={x.isDemo} /></div><OrgPill s={x.status} /></div><div className="panel-b stack">
      <dl className="dl"><dt>Município</dt><dd>{x.city}</dd><dt>INEP</dt><dd>{x.inep || 'não informado'}</dd><dt>Gestores</dt><dd>{x.managers.map((m: any) => `${m.name} (${m.login})`).join(', ') || '—'}</dd><dt>Cadastro</dt><dd>{x.turmas} turmas · {x.students} estudantes · desde {fmtDate(x.createdAt)}</dd>{x.note && <><dt>Observação</dt><dd>{x.note}</dd></>}</dl>
      <Note>Confirme o vínculo do solicitante com a escola (por exemplo, por ofício ou e-mail institucional da SEDUC-PI) antes de aprovar.</Note>
      <Decision options={opts} onDecide={async (v, note) => { await post(`/admin/schools/${x.id}/status`, { status: v, note }); toast('Decisão registrada.'); schools.reload(true); }} />
    </div></div>)}</div> : <div className="panel"><Empty icon="school" title="Nenhuma escola nesta situação" text="Altere o filtro." /></div>; }}</Loaded>
      : <Loaded s={companies}>{(list) => { const r = list.filter(flt); return r.length ? <div className="stack">{r.map((x) => <div key={x.id} className="panel"><div className="panel-h"><div className="row"><h3>{x.name}</h3><DemoTag on={x.isDemo} /></div><OrgPill s={x.status} /></div><div className="panel-b stack">
        <dl className="dl"><dt>CNPJ</dt><dd>{x.cnpj || 'não informado'}</dd><dt>Setor</dt><dd>{x.sector}</dd><dt>Município</dt><dd>{x.city}</dd><dt>Responsável</dt><dd>{x.responsibleName} · {x.email}</dd><dt>Descrição</dt><dd>{x.description}</dd><dt>Demandas</dt><dd>{x.demands}</dd>{x.note && <><dt>Observação</dt><dd>{x.note}</dd></>}</dl>
        <Note>Confira o CNPJ na Receita Federal e o contato do responsável antes de aprovar.</Note>
        <Decision options={opts} onDecide={async (v, note) => { await post(`/admin/companies/${x.id}/status`, { status: v, note }); toast('Decisão registrada.'); companies.reload(true); }} />
      </div></div>)}</div> : <div className="panel"><Empty icon="building" title="Nenhuma empresa nesta situação" text="Altere o filtro." /></div>; }}</Loaded>}
  </>;
}

export function AdDemandas() {
  const { toast } = useUi();
  const ds = useLoad(() => get<any[]>('/admin/demands'), []);
  const os = useLoad(() => get<any[]>('/opportunities'), []);
  const [tab, setTab] = useState('demandas');
  return <><PageHead title="Moderação" eyebrow="Antes de chegar às escolas" />
    <div className="tabs" role="tablist">{[['demandas', 'Demandas empresariais'], ['vagas', 'Vagas (etapa futura)']].map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    {tab === 'demandas' ? <><div style={{ marginBottom: 16 }}><Note icon="shield">Verifique se a demanda é real, de escopo limitado, adequada a estudantes de 14 a 18 anos, sem dados pessoais ou sigilosos e se não substitui trabalho remunerado. Peça redimensionamento quando necessário.</Note></div>
      <Loaded s={ds}>{(list) => { const pend = list.filter((d) => d.status === 'pendente' || d.status === 'ajustes'), rest = list.filter((d) => !(d.status === 'pendente' || d.status === 'ajustes')); return <div className="stack">
        {pend.length ? pend.map((d) => <div key={d.id} className="panel"><div className="panel-h"><div className="row"><h3>{d.title}</h3><DemoTag on={d.isDemo} /></div><DemandPill s={d.status} /></div><div className="panel-b stack">
          <dl className="dl"><dt>Empresa</dt><dd>{d.company.name} <OrgPill s={d.company.status} /></dd><dt>Necessidade</dt><dd>{d.need}</dd><dt>Objetivos</dt><dd>{d.objectives}</dd><dt>Resultados</dt><dd>{d.expectedResults}</dd>
            <dt>Escopo</dt><dd>~{d.hours} h · até {d.maxProjects} turma(s) · prazo {fmtDate(d.suggestedDeadline)} · {d.scopeDeclared ? 'declaração de escopo confirmada' : 'sem declaração'}</dd><dt>Área</dt><dd>{d.area} · {d.techs.join(', ')}</dd><dt>Critérios</dt><dd>{d.criteria.join(' · ')}</dd>{d.modNote && <><dt>Observação</dt><dd>{d.modNote}</dd></>}</dl>
          {d.status === 'pendente' ? <Decision options={[['disponivel', 'Aprovar e encaminhar às escolas', 'btn-primary'], ['ajustes', 'Pedir ajustes ou redimensionamento', 'btn-ghost'], ['rejeitada', 'Rejeitar', 'btn-danger']]}
            onDecide={async (v, note) => { await post(`/admin/demands/${d.id}/moderation`, { status: v, note }); toast('Decisão registrada.'); ds.reload(true); }} /> : <Note>Aguardando a empresa reenviar com os ajustes.</Note>}
        </div></div>) : <div className="panel"><Empty icon="check" title="Nenhuma demanda aguardando moderação" text="Novas demandas de empresas verificadas aparecem aqui." /></div>}
        {rest.length > 0 && <div className="panel"><div className="panel-h"><h3>Demais demandas</h3></div><ul className="list">{rest.map((d) => <li key={d.id}><div className="grow"><b>{d.title}</b> <DemoTag on={d.isDemo} /><div className="small muted">{d.company.name} · {d.activeCount} em andamento · {d.concludedCount} concluído(s)</div></div>
          <div className="row"><DemandPill s={d.phase} /><Link className="btn btn-ghost btn-sm" to={'/demandas/' + d.id}>Abrir</Link>{d.status === 'disponivel' && <ActionButton className="btn btn-danger btn-sm" action={async () => { await post(`/admin/demands/${d.id}/moderation`, { status: 'encerrada', note: 'Encerrada pela administração.' }); ds.reload(true); }} success="Demanda encerrada.">Encerrar</ActionButton>}</div></li>)}</ul></div>}
      </div>; }}</Loaded></>
      : <Loaded s={os}>{(list) => list.length ? <div className="stack">{list.map((o) => <div key={o.id} className="panel"><div className="panel-h"><div className="row"><h3>{o.title}</h3><DemoTag on={o.isDemo} /></div><OppPill s={o.status} /></div><div className="panel-b stack">
        <dl className="dl"><dt>Empresa</dt><dd>{o.companyName}</dd><dt>Área</dt><dd>{o.area} · {o.city} · {o.workload}</dd><dt>Requisitos</dt><dd>{o.requirements.join('; ')}</dd><dt>Atividades</dt><dd>{o.description}</dd><dt>Seleção</dt><dd>{o.selectionInfo}</dd><dt>Interessados</dt><dd>{o.interestCount ?? 0}</dd></dl>
        {o.status !== 'encerrada' && <Decision options={o.status === 'publicada' ? [['encerrada', 'Encerrar vaga', 'btn-ghost']] : [['publicada', 'Publicar como vaga verificada', 'btn-primary'], ['ajustes', 'Pedir ajustes', 'btn-ghost'], ['rejeitada', 'Rejeitar', 'btn-danger']]}
          onDecide={async (v, note) => { await post(`/admin/opportunities/${o.id}/moderation`, { status: v, note }); toast('Decisão registrada.'); os.reload(true); }} />}
      </div></div>)}</div> : <div className="panel"><Empty icon="brief" title="Nenhuma vaga" text="Vagas enviadas por empresas verificadas aparecem aqui." /></div>}</Loaded>}
  </>;
}

export function AdUsuarios() {
  const { user } = useAuth();
  const { toast, confirm } = useUi();
  const s = useLoad(() => get<any[]>('/admin/users'), []);
  const [q, setQ] = useState(''); const [role, setRole] = useState('');
  const [pw, setPw] = useState<any>(null);
  return <><PageHead title="Permissões e contas" eyebrow="Administração" />
    <div style={{ marginBottom: 16 }}><Note>Estudantes e professores são gerenciados pela escola. Aqui a administração pode desativar qualquer conta, redefinir senhas de gestores e empresas e excluir contas a pedido (LGPD). Nomes de estudantes aparecem abreviados.</Note></div>
    <div className="card" style={{ marginBottom: 16 }}><Form onSubmit={async (fd, form) => { const r = await post('/admin/users', { name: String(fd.get('name') || ''), email: String(fd.get('email') || '') }); form.reset(); setPw({ name: String(fd.get('name')), ...r }); s.reload(true); }} className="row">
      <div className="field" style={{ flex: '1 1 220px' }}><Field name="name" label="Nome do novo administrador" required><Input name="name" type="text" maxLength={80} req /></Field></div>
      <div className="field" style={{ flex: '1 1 220px' }}><Field name="email" label="E-mail" required><Input name="email" type="email" req /></Field></div>
      <div style={{ alignSelf: 'flex-end' }}><Submit className="btn btn-primary"><Icon name="plus" /> Criar administrador</Submit></div></Form></div>
    <div className="panel"><div className="panel-h"><h3>Contas</h3><div className="row"><input type="search" aria-label="Buscar" placeholder="Buscar nome ou login" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 220 }} />
      <select aria-label="Perfil" value={role} onChange={(e) => setRole(e.target.value)} style={{ maxWidth: 220 }}><option value="">Todos os perfis</option>{Object.entries(ROLE_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></div></div>
      <Loaded s={s}>{(list) => <div className="scroll-x"><table className="tbl"><thead><tr><th>Nome</th><th>Perfil</th><th>Vínculo</th><th>Situação</th><th>Ações</th></tr></thead><tbody>
        {list.filter((u) => (!role || u.role === role) && (!q || (u.name + ' ' + u.login).toLowerCase().includes(q.toLowerCase()))).map((u) => <tr key={u.id} style={u.active ? undefined : { opacity: .55 }}>
          <td><b>{u.name}</b> <DemoTag on={u.isDemo} /><div className="small muted">{u.login}</div></td><td className="small">{ROLE_LABEL[u.role as keyof typeof ROLE_LABEL]}</td><td className="small">{u.companyName || u.schoolName || '—'}</td>
          <td>{u.active ? <span className="pill st-done">Ativa</span> : <span className="pill st-bad">Desativada</span>}<div className="small muted">{u.lastLoginAt ? 'acesso ' + fmtDate(u.lastLoginAt) : 'sem acesso'}</div></td>
          <td>{u.id === user!.id ? <span className="small muted">você</span> : <div className="row">
            <ActionButton action={async () => { await put(`/admin/users/${u.id}`, { active: !u.active }); s.reload(true); }} success={u.active ? 'Conta desativada.' : 'Conta reativada.'}>{u.active ? 'Desativar' : 'Reativar'}</ActionButton>
            {u.role !== 'student' && <ActionButton action={async () => { const r = await post(`/admin/users/${u.id}/reset-password`); setPw({ name: u.name, ...r }); }}>Nova senha</ActionButton>}
            <button className="btn btn-danger btn-sm" onClick={() => confirm({ title: 'Excluir conta', danger: true, ok: 'Excluir definitivamente', text: <>A conta de <b>{u.name}</b> e os dados pessoais serão apagados. Use apenas para pedidos de exclusão ou cadastros indevidos. Não pode ser desfeito.</>, onOk: async () => { await del(`/admin/users/${u.id}`); toast('Conta excluída.'); s.reload(true); } })}>Excluir</button></div>}</td></tr>)}</tbody></table></div>}</Loaded></div>
    {pw && <Modal title="Senha temporária" onClose={() => setPw(null)} foot={<button className="btn btn-primary" onClick={() => setPw(null)}>Pronto</button>}><div className="stack">
      <p>Entregue a <b>{pw.name}</b> por canal oficial. A troca é obrigatória no primeiro acesso.</p>
      <div className="pwbox"><span className="small muted">Usuário</span><code>{pw.login}</code><span className="small muted">Senha temporária</span><code>{pw.temporaryPassword}</code><div><button className="btn btn-ghost btn-sm" onClick={() => copyText(`${pw.login} / ${pw.temporaryPassword}`, toast)}><Icon name="copy" /> Copiar</button></div></div>
      <Note kind="warn">Esta senha não será mostrada novamente.</Note></div></Modal>}
  </>;
}

export function AdRegistros() {
  const { toast } = useUi();
  const [tab, setTab] = useState('acessos');
  const [q, setQ] = useState(''); const [term, setTerm] = useState('');
  const audit = useLoad(() => get<any[]>('/admin/audit' + (term ? '?q=' + encodeURIComponent(term) : '')), [term]);
  const flags = useLoad(() => get<any[]>('/admin/flags'), []);
  const reqs = useLoad(() => get<any[]>('/admin/requests'), []);
  const [resp, setResp] = useState<any>(null);
  return <><PageHead title="Registros e segurança" eyebrow="Administração" />
    <div className="tabs" role="tablist">{[['acessos', 'Registro de acessos e ações'], ['sinalizacoes', 'Sinalizações'], ['pedidos', 'Pedidos de correção']].map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    {tab === 'acessos' && <div className="panel"><div className="panel-h"><h3>Últimos registros</h3><form className="row" onSubmit={(e) => { e.preventDefault(); setTerm(q); }}><input type="search" aria-label="Buscar no registro" placeholder="Buscar ação, pessoa ou detalhe" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 260 }} /><button className="btn btn-ghost btn-sm" type="submit">Buscar</button></form></div>
      <Loaded s={audit}>{(list) => list.length ? <div className="scroll-x"><table className="tbl"><thead><tr><th>Quando</th><th>Quem</th><th>Ação</th><th>Detalhe</th><th>Escola</th><th>IP</th></tr></thead><tbody>
        {list.map((a, i) => <tr key={i}><td className="small" style={{ whiteSpace: 'nowrap' }}>{fmtDT(a.createdAt)}</td><td className="small">{a.user || '—'}<div className="muted">{ROLE_LABEL[a.role as keyof typeof ROLE_LABEL] || a.role || ''}</div></td><td className="small"><b>{a.action}</b></td><td className="small">{a.detail}</td><td className="small">{a.schoolName || '—'}</td><td className="small mono">{a.ip || '—'}</td></tr>)}</tbody></table></div>
        : <Empty icon="clip" title="Nenhum registro" text="Altere a busca." />}</Loaded></div>}
    {tab === 'sinalizacoes' && <Loaded s={flags}>{(list) => list.length ? <div className="panel"><ul className="list">{list.map((f) => <li key={f.id}><div className="grow stack-sm"><div className="row"><b>{f.type}</b><span className={'pill ' + (f.status === 'aberta' ? 'st-pend' : 'st-done')}>{f.status === 'aberta' ? 'Aberta' : 'Resolvida'}</span></div><p className="small">{f.text}</p><span className="small muted">{f.schoolName || '—'} · {fmtDT(f.createdAt)}</span></div>
      <div className="row">{f.projectId && <Link className="btn btn-ghost btn-sm" to={'/projetos/' + f.projectId}>Ver mural</Link>}{f.status === 'aberta' && <ActionButton className="btn btn-primary btn-sm" action={async () => { await post(`/admin/flags/${f.id}/resolve`); flags.reload(true); }} success="Sinalização resolvida.">Resolver</ActionButton>}</div></li>)}</ul></div>
      : <div className="panel"><Empty icon="shield" title="Nenhuma sinalização" text="Contatos pessoais nos murais geram sinalizações automáticas." /></div>}</Loaded>}
    {tab === 'pedidos' && <Loaded s={reqs}>{(list) => list.length ? <div className="panel"><ul className="list">{list.map((r) => <li key={r.id}><div className="grow stack-sm"><div className="row"><b className="small">{r.name}</b><span className="chip">{ROLE_LABEL[r.role as keyof typeof ROLE_LABEL]}</span><span className="chip">{REQ_KIND[r.kind]}</span><span className={'pill ' + (r.status === 'aberto' ? 'st-pend' : 'st-done')}>{r.status === 'aberto' ? 'Aberto' : 'Resolvido'}</span></div><p className="small">{r.text}</p>{r.response && <p className="small muted">Resposta: {r.response}</p>}</div>
      {r.status === 'aberto' && <button className="btn btn-ghost btn-sm" onClick={() => setResp(r)}>Responder</button>}</li>)}</ul></div>
      : <div className="panel"><Empty icon="clip" title="Nenhum pedido" text="Pedidos de escolas, empresas e administradores aparecem aqui. Pedidos de estudantes e professores vão para a escola." /></div>}</Loaded>}
    {resp && <Modal title="Responder pedido" onClose={() => setResp(null)}><Form onSubmit={async (fd) => { await post(`/admin/requests/${resp.id}/resolve`, { response: String(fd.get('response') || '') }); toast('Resposta registrada.'); setResp(null); reqs.reload(true); }}>
      <p className="small"><b>{resp.name}</b>: {resp.text}</p><Field name="response" label="Resposta" required><Textarea name="response" maxLength={600} req /></Field><div><Submit>Marcar como resolvido</Submit></div></Form></Modal>}
  </>;
}
