import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { get } from '../api';
import { useAuth } from '../auth';
import { firstName, fmtDate, fmtDT } from '../lib';
import { Icon, Kpi, Empty, Note, PageHead, StatusPill, ConsentPill, DemoTag, useLoad, Loaded } from '../ui';

export function ProjectList({ list, empty }: { list: any[]; empty: [string, string] }) {
  return list.length ? <ul className="list">{list.map((p) => <li key={p.id}><div className="grow"><div className="row"><b>{p.title}</b><DemoTag on={p.isDemo} /></div>
    <div className="small muted">{p.turmaName ? p.turmaName + ' · ' : ''}{p.companyName}{p.members ? ` · equipe de ${p.members}` : ''}{p.lastSubmission ? ` · última entrega ${fmtDT(p.lastSubmission)}` : ''}</div></div>
    <div className="row"><StatusPill s={p.status} /><Link className="btn btn-ghost btn-sm" to={'/projetos/' + p.id}>Abrir</Link></div></li>)}</ul>
    : <p className="panel-b small muted">{empty[1]}</p>;
}

export function PfPainel() {
  const { user } = useAuth();
  const s = useLoad(() => get('/teacher/dashboard'), []);
  return <Loaded s={s}>{(d: any) => {
    const by = (...st: string[]) => d.projects.filter((p: any) => st.includes(p.status));
    const action = by('analise_pedagogica', 'aprovado', 'entregue');
    return <>
      <PageHead title={'Olá, prof. ' + firstName(user!.name) + '!'} eyebrow={'Professor-orientador · ' + (d.school?.name || '')} actions={<Link className="btn btn-primary" to="/demandas"><Icon name="brief" /> Ver demandas</Link>} />
      {!d.turmas.length && <div style={{ marginBottom: 16 }}><Note kind="warn">Você ainda não tem turmas vinculadas. A coordenação da escola faz esse vínculo.</Note></div>}
      <div className="grid g4" style={{ marginBottom: 20 }}>
        <Kpi n={by('analise_pedagogica').length} l="Análises pendentes" s="pareceres a registrar" />
        <Kpi n={by('aprovado').length} l="Equipes a organizar" s="autorizados pela escola" />
        <Kpi n={by('entregue').length} l="Entregas a validar" />
        <Kpi n={by('em_andamento').length} l="Em desenvolvimento" />
      </div>
      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="clip" /> Precisam da sua ação</h3></div><ProjectList list={action} empty={['', 'Nenhuma pendência no momento.']} /></div>
          <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Todos os projetos</h3></div><ProjectList list={d.projects} empty={['', 'Abra o catálogo de demandas para iniciar a primeira análise pedagógica.']} /></div>
        </div>
        <div className="stack">
          <div className="panel"><div className="panel-h"><h3><Icon name="calendar" /> Próximas etapas</h3></div>
            {d.milestones.length ? <ul className="list">{d.milestones.map((m: any, i: number) => <li key={i}><div className="grow"><b>{m.title}</b><div className="small muted">{m.projectTitle}</div></div><Link className="chip link-plain" to={'/projetos/' + m.projectId}><Icon name="clock" /> {fmtDate(m.dueDate)}</Link></li>)}</ul> : <p className="panel-b small muted">Sem etapas pendentes.</p>}</div>
          <div className="panel"><div className="panel-h"><h3><Icon name="msg" /> Mensagens recentes nos murais</h3></div>
            {d.posts.length ? <ul className="list">{d.posts.map((m: any, i: number) => <li key={i}><div className="grow"><div className="small"><b>{m.author}</b> <span className="muted">· {m.title} · {fmtDT(m.createdAt)}</span> {m.masked && <span className="chip chip-warn">contato ocultado</span>}</div><p className="small">{m.text}</p></div><Link className="btn btn-ghost btn-sm" to={'/projetos/' + m.projectId}>Mediar</Link></li>)}</ul> : <p className="panel-b small muted">Nenhuma mensagem ainda.</p>}</div>
          <div className="panel"><div className="panel-h"><h3><Icon name="users" /> Turmas</h3></div>
            {d.turmas.length ? <ul className="list">{d.turmas.map((t: any) => <li key={t.id}><div className="grow"><b>{t.name}</b><div className="small muted">{t.students} estudantes{t.consentPending ? ` · ${t.consentPending} com autorização pendente` : ''}</div></div><Link className="btn btn-ghost btn-sm" to={'/professor/turmas?turma=' + t.id}>Abrir</Link></li>)}</ul> : <p className="panel-b small muted">Nenhuma turma.</p>}</div>
        </div>
      </div></>;
  }}</Loaded>;
}

export function PfTurmas() {
  const [sp, setSp] = useSearchParams();
  const dash = useLoad(() => get('/teacher/dashboard'), []);
  const turmas = dash.data?.turmas || [];
  const tid = sp.get('turma') || turmas[0]?.id || '';
  const s = useLoad(() => (tid ? get(`/teacher/turmas/${tid}`) : Promise.resolve(null)), [tid]);
  if (dash.loading && !dash.data) return <Loaded s={dash}>{() => null}</Loaded>;
  if (!turmas.length) return <><PageHead title="Turmas" /><div className="panel"><Empty icon="users" title="Nenhuma turma vinculada" text="A coordenação da escola vincula professores às turmas." /></div></>;
  return <><PageHead title="Turmas" eyebrow="Professor-orientador" />
    <div className="tabs" role="tablist">{turmas.map((t: any) => <button key={t.id} role="tab" aria-selected={t.id === tid} className={t.id === tid ? 'on' : ''} onClick={() => setSp({ turma: t.id })}>{t.name}</button>)}</div>
    <Loaded s={s}>{(d: any) => <div className="grid g2" style={{ alignItems: 'start' }}>
      <div className="panel"><div className="panel-h"><h3><Icon name="users" /> Estudantes</h3><span className="small muted">{d.students.length}</span></div>
        {d.students.length ? <div className="scroll-x"><table className="tbl"><thead><tr><th>Nome</th><th>Identificação</th><th>Autorização</th><th className="num">Projetos</th></tr></thead><tbody>
          {d.students.map((x: any) => <tr key={x.id}><td><b>{x.name}</b><div className="small muted">{x.lastLoginAt ? 'último acesso ' + fmtDate(x.lastLoginAt) : 'ainda não acessou'}</div></td><td className="small mono">{x.code || '—'}</td><td><ConsentPill s={x.consentStatus} /></td><td className="num">{x.projects}</td></tr>)}</tbody></table></div>
          : <Empty icon="users" title="Nenhum estudante" text="A coordenação habilita as contas dos estudantes." />}
        <p className="panel-b small muted" style={{ borderTop: '1px solid var(--line)' }}>As autorizações dos responsáveis são registradas pela coordenação da escola.</p></div>
      <div className="panel"><div className="panel-h"><h3><Icon name="folder" /> Projetos da turma</h3></div><ProjectList list={d.projects} empty={['', 'Nenhum projeto nesta turma.']} /></div>
    </div>}</Loaded></>;
}
