import React from 'react';
import { get, post } from '../api';
import { useAuth } from '../auth';
import { REQ_KIND, ROLE_LABEL, fmtDate } from '../lib';
import { ApiLink, Icon, PageHead, Note, useUi, useLoad, Form, Field, Select, Textarea, Submit } from '../ui';
import { PasswordForm } from './auth';

export function Conta() {
  const { user, school, company, turma } = useAuth();
  const { toast } = useUi();
  const reqs = useLoad(() => get<any[]>('/me/requests'), []);
  const bySchool = user!.role === 'student' || user!.role === 'teacher';
  return <><PageHead title="Minha conta" eyebrow={ROLE_LABEL[user!.role]} />
    <div className="grid g2" style={{ alignItems: 'start' }}>
      <div className="stack">
        <div className="card stack-sm"><h3>Dados de acesso</h3><dl className="dl"><dt>Nome</dt><dd>{user!.name}</dd><dt>{user!.role === 'student' ? 'Usuário institucional' : 'Login'}</dt><dd className="mono">{user!.login}</dd>
          {user!.studentCode && <><dt>Identificação</dt><dd>{user!.studentCode}</dd></>}
          {school && <><dt>Escola</dt><dd>{school.name}</dd></>}{turma && <><dt>Turma</dt><dd>{turma.name}</dd></>}{company && <><dt>Empresa</dt><dd>{company.name}</dd></>}</dl>
          <p className="small muted">{bySchool ? 'Seus dados de cadastro são mantidos pela escola.' : 'Para alterar nome ou login, fale com a administração.'}</p></div>
        <div className="card stack"><h3><Icon name="key" /> Trocar senha</h3><PasswordForm onDone={() => toast('Senha alterada. Outras sessões foram encerradas.')} /></div>
      </div>
      <div className="stack">
        <div className="card stack-sm"><h3><Icon name="shield" /> Meus dados (LGPD)</h3>
          <p className="small muted">Baixe uma cópia dos dados registrados sobre você, incluindo o histórico de acessos.</p>
          <div><ApiLink className="btn btn-ghost btn-sm" href="/api/me/export" download="meus-dados-conectatec.json"><Icon name="download" /> Baixar meus dados</ApiLink></div></div>
        <div className="card"><Form onSubmit={async (fd, form) => { const r = await post('/me/requests', { kind: String(fd.get('kind')), text: String(fd.get('text') || '') }); form.reset(); toast(`Pedido enviado. Quem responde: ${r.handledBy}.`); reqs.reload(true); }}>
          <div className="stack-sm"><h3><Icon name="clip" /> Corrigir ou remover informações</h3><p className="small muted">Peça correção de dados, remoção de uma informação indevida (por exemplo, uma mensagem no mural) ou a exclusão da conta. {bySchool ? 'A escola responde.' : 'A administração responde.'}</p></div>
          <Field name="kind" label="Tipo de pedido" required><Select name="kind" defaultValue="correcao">{Object.entries(REQ_KIND).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></Field>
          <Field name="text" label="Descreva o pedido" required><Textarea name="text" maxLength={1000} req style={{ minHeight: 80 }} /></Field>
          <div><Submit><Icon name="send" /> Enviar pedido</Submit></div></Form></div>
        {reqs.data && reqs.data.length > 0 && <div className="panel"><div className="panel-h"><h3>Meus pedidos</h3></div><ul className="list">{reqs.data.map((r) => <li key={r.id}><div className="grow stack-sm"><div className="row"><span className="chip">{REQ_KIND[r.kind]}</span><span className={'pill ' + (r.status === 'aberto' ? 'st-pend' : 'st-done')}>{r.status === 'aberto' ? 'Em análise' : 'Respondido'}</span><span className="small muted">{fmtDate(r.createdAt)}</span></div><p className="small">{r.text}</p>{r.response && <Note kind="ok" icon="check">{r.response}</Note>}</div></li>)}</ul></div>}
      </div></div></>;
}
