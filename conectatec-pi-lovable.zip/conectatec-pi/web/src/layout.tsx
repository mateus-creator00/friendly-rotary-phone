import React, { useEffect, useState } from 'react';
import { Link, NavLink, Navigate, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { post } from './api';
import { useAuth } from './auth';
import { HOME, ROLE_LABEL, SLOGAN, initials, type Role } from './lib';
import { Icon, LogoLink, LogoFull, useUi } from './ui';

function useOnline() {
  const [on, setOn] = useState(navigator.onLine);
  useEffect(() => {
    const a = () => setOn(true), b = () => setOn(false);
    window.addEventListener('online', a); window.addEventListener('offline', b);
    return () => { window.removeEventListener('online', a); window.removeEventListener('offline', b); };
  }, []);
  return on;
}
function OfflineBar() {
  return useOnline() ? null : <div className="offline" role="status">Você está sem internet. As telas voltam a carregar quando a conexão retornar.</div>;
}

export function PublicLayout() {
  const { user } = useAuth();
  const nl = (to: string, l: string) => <NavLink className={({ isActive }) => 'nl link-plain' + (isActive ? ' on' : '')} to={to} end={to === '/'}>{l}</NavLink>;
  return <>
    <OfflineBar />
    <header className="ph"><div className="wrap ph-in"><LogoLink />
      <nav aria-label="Principal" className="row">{nl('/', 'Início')}{nl('/como-funciona', 'Como funciona')}{nl('/demandas', 'Demandas')}{nl('/oportunidades', 'Oportunidades')}
        {user ? <Link className="btn btn-primary btn-sm" to={HOME[user.role]}><Icon name="dash" /> Meu painel</Link> : <Link className="btn btn-primary btn-sm" to="/entrar"><Icon name="lock" /> Entrar</Link>}
      </nav></div></header>
    <main id="main"><Outlet /></main>
    <footer className="pf"><div className="wrap pf-in">
      <div className="stack-sm" style={{ maxWidth: '62ch' }}><b style={{ fontFamily: 'var(--f-display)', fontSize: '1rem' }}>ConectaTec PI · {SLOGAN}</b>
        <span>Projeto educacional ligado ao Programa Do Piauí para o Mundo — Edição 2026 (SEDUC-PI), Trilha de Tecnologia da Informação, Eixo 5: Novas Tecnologias para Cidadãos, Indústria e Governo.</span></div>
      <div className="stack-sm"><Link to="/privacidade">Política de privacidade</Link><Link to="/termos">Termos de uso</Link><Link to="/certificado">Verificar certificado</Link></div>
    </div></footer>
  </>;
}

type NavItem = [string, string, string];
const NAV: Record<Role, NavItem[]> = {
  school: [['/escola', 'dash', 'Painel'], ['/escola/projetos', 'folder', 'Projetos'], ['/demandas', 'brief', 'Demandas'], ['/escola/pessoas', 'users', 'Turmas e pessoas'], ['/escola/relatorios', 'chart', 'Relatórios'], ['/conta', 'user', 'Conta']],
  teacher: [['/professor', 'dash', 'Painel'], ['/demandas', 'brief', 'Demandas'], ['/professor/turmas', 'users', 'Turmas'], ['/conta', 'user', 'Conta']],
  student: [['/estudante', 'dash', 'Atividades'], ['/estudante/portfolio', 'award', 'Portfólio'], ['/oportunidades', 'target', 'Oportunidades'], ['/conta', 'user', 'Conta']],
  company: [['/empresa', 'dash', 'Painel'], ['/empresa/nova-demanda', 'plus', 'Nova demanda'], ['/empresa/oportunidades', 'brief', 'Vagas'], ['/empresa/perfil', 'building', 'Perfil'], ['/conta', 'user', 'Conta']],
  admin: [['/admin', 'chart', 'Visão geral'], ['/admin/cadastros', 'shield', 'Escolas e empresas'], ['/admin/demandas', 'brief', 'Moderação'], ['/admin/usuarios', 'users', 'Permissões'], ['/admin/registros', 'clip', 'Registros']],
};

export function AppShell() {
  const { user, company, school, turma, logout } = useAuth();
  const { toast } = useUi();
  const nav = useNavigate();
  const loc = useLocation();
  if (!user) return <Navigate to="/entrar" replace state={{ from: loc.pathname }} />;
  if (user.mustChangePassword) return <Navigate to="/trocar-senha" replace />;
  const items = NAV[user.role];
  const active = (to: string) => loc.pathname === to || (to !== HOME[user.role] && loc.pathname.startsWith(to + '/'));
  const sub = user.role === 'company' ? company?.name : user.role === 'student' ? turma?.name : user.role === 'admin' ? '' : school?.name;
  async function out() { await logout(); toast('Você saiu da plataforma.'); nav('/'); }
  return <>
    <OfflineBar />
    <div className="shell">
      <aside className="side" aria-label="Menu"><LogoLink />
        <nav>{items.map(([to, ic, l]) => <Link key={to} to={to} className={'link-plain ' + (active(to) ? 'on' : '')}><Icon name={ic} /><span>{l}</span></Link>)}
          <Link to="/" className="link-plain"><Icon name="home" /><span>Página inicial</span></Link></nav>
        <div className="who"><div className="row" style={{ flexWrap: 'nowrap' }}><span className="avatar">{initials(user.name)}</span>
          <div className="minw0"><div style={{ fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name}</div><div className="role">{ROLE_LABEL[user.role]}</div></div></div>
          {sub && <div style={{ opacity: .8, fontSize: '.78rem' }}>{sub}</div>}
          <div className="row"><button className="btn btn-light btn-sm" onClick={out}><Icon name="logout" /> Sair</button></div></div>
      </aside>
      <div className="minw0">
        <div className="mtop"><LogoLink /><div className="row" style={{ flexWrap: 'nowrap' }}><Link className="iconbtn" to="/conta" aria-label="Minha conta"><Icon name="user" /></Link><button className="iconbtn" onClick={out} aria-label="Sair"><Icon name="logout" /></button></div></div>
        <main className="main" id="main"><Outlet /></main>
      </div>
    </div>
    <nav className="bnav" aria-label="Navegação">{items.map(([to, ic, l]) => <Link key={to} to={to} className={'link-plain ' + (active(to) ? 'on' : '')}><Icon name={ic} /><span>{l.split(' ')[0]}</span></Link>)}</nav>
  </>;
}

export function RequireRole({ roles, children }: { roles: Role[]; children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/entrar" replace />;
  if (!roles.includes(user.role)) return <Navigate to={HOME[user.role]} replace />;
  return <>{children}</>;
}

/** Catálogo de demandas e oportunidades: dentro do painel para quem entrou, página pública para visitantes. */
export function Adaptive() {
  const { user } = useAuth();
  if (user && !user.mustChangePassword) return <AppShell />;
  return <PublicLayout />;
}

export function Splash() {
  return <div className="loading-screen"><div className="stack" style={{ alignItems: 'center' }}><LogoFull max={260} /><p className="muted"><span className="spin" /> Carregando…</p></div></div>;
}
