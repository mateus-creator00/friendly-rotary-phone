import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { get, post } from './api';
import type { Role } from './lib';

export type User = {
  id: string; role: Role; name: string; login: string; email: string | null; mustChangePassword: boolean;
  schoolId: string | null; turmaId: string | null; companyId: string | null; consentStatus: string; isMinor: boolean;
  isDemo: boolean; year: string | null; studentCode: string | null;
};
export type Org = { id: string; name: string; city: string; status: string; note: string; sector?: string } | null;
export type Session = { user: User; company: Org; school: Org; turma: { id: string; name: string; course: string; year: string } | null };
type Ctx = {
  user: User | null; company: Org; school: Org; turma: Session['turma']; ready: boolean;
  refresh: () => Promise<void>; setSession: (d: Session) => void; logout: () => Promise<void>;
};

const AuthCtx = createContext<Ctx>(null as any);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [s, setS] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const refresh = useCallback(async () => {
    try { const d = await get('/auth/me'); setS(d.user ? d : null); }
    catch { /* sem conexão: mantém estado */ }
    finally { setReady(true); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    const h = () => setS(null);
    window.addEventListener('ctpi:unauthorized', h);
    return () => window.removeEventListener('ctpi:unauthorized', h);
  }, []);
  const logout = async () => { try { await post('/auth/logout'); } finally { setS(null); } };
  return <AuthCtx.Provider value={{ user: s?.user ?? null, company: s?.company ?? null, school: s?.school ?? null, turma: s?.turma ?? null, ready,
    refresh, setSession: (d) => setS(d), logout }}>{children}</AuthCtx.Provider>;
}
export const useAuth = () => useContext(AuthCtx);
