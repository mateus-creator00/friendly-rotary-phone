import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import markUrl from './assets/mark.jpg';
import logoUrl from './assets/logo.jpg';
import { ApiError } from './api';
import { P_STATUS, D_PHASE, ORG_STATUS, OPP_STATUS, CONSENT, FLOW, SLOGAN, daysLeft, fmtDate } from './lib';

/* ---------- ícones ---------- */
const IC: Record<string, string> = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  dash: '<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="5" rx="1.5"/><rect x="13" y="10" width="8" height="11" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  folder: '<path d="M3 7h6l2 2h10v10H3z"/>',
  award: '<circle cx="12" cy="9" r="6"/><path d="M8.5 14L7 22l5-3 5 3-1.5-8"/>',
  brief: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5h6v2M3 13h18"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c.8-3.5 3.5-5 7-5s6.2 1.5 7 5"/><path d="M16 4.5a3.5 3.5 0 010 7M18 15c2 .6 3.5 2.2 4 5"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  clip: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  flag: '<path d="M5 21V4M5 4h12l-2 4 2 4H5"/>',
  building: '<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 7h2M14 7h2M8 11h2M14 11h2M10 21v-4h4v4"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  send: '<path d="M4 12l16-8-6 16-2-7z"/>',
  logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  msg: '<path d="M4 5h16v11H9l-5 4z"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 11l7.6-4M8.2 13l7.6 4"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  left: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  right: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  link: '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17h.01"/>',
  heart: '<path d="M12 20s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.5-7 10-7 10z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>',
  refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
  print: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  school: '<path d="M3 21h18M5 21V10l7-5 7 5v11"/><path d="M10 21v-5h4v5"/>',
};
export function Icon({ name }: { name: string }) {
  return <svg className="i" viewBox="0 0 24 24" aria-hidden="true" dangerouslySetInnerHTML={{ __html: IC[name] || '' }} />;
}

/* ---------- marca ---------- */
export function Mark({ size = 34 }: { size?: number }) { return <img className="mark" src={markUrl} width={size} height={size} alt="" />; }
export function LogoFull({ max = 420 }: { max?: number }) {
  return <img className="logo-full" src={logoUrl} alt="ConectaTec PI" style={{ maxWidth: max }} />;
}
export function LogoLink({ to = '/' }: { to?: string }) {
  return <Link className="logo link-plain" to={to} aria-label="ConectaTec PI, página inicial"><Mark /><span><b>Conecta<em>Tec</em> <i>| PI</i></b><small>{SLOGAN.replace(/\.$/, '')}</small></span></Link>;
}

/* ---------- etiquetas ---------- */
function P({ map, k }: { map: Record<string, [string, string]>; k: string }) { const x = map[k] || [k, '']; return <span className={'pill ' + x[1]}>{x[0]}</span>; }
export const StatusPill = ({ s }: { s: string }) => <P map={P_STATUS} k={s} />;
export const DemandPill = ({ s }: { s: string }) => <P map={D_PHASE} k={s} />;
export const OrgPill = ({ s }: { s: string }) => <P map={ORG_STATUS} k={s} />;
export const OppPill = ({ s }: { s: string }) => <P map={OPP_STATUS} k={s} />;
export const ConsentPill = ({ s }: { s: string }) => <P map={CONSENT} k={s} />;
export const DemoTag = ({ on }: { on?: boolean }) => on ? <span className="tag tag-demo" title="Dado fictício de demonstração">DEMO</span> : null;
export function Deadline({ d, label = 'Prazo sugerido' }: { d: string; label?: string }) {
  const n = daysLeft(d);
  if (n < 0) return <span className="chip chip-danger"><Icon name="clock" /> {label}: {fmtDate(d)} (vencido)</span>;
  return <span className={'chip ' + (n <= 7 ? 'chip-warn' : '')}><Icon name="clock" /> {label}: {fmtDate(d)}</span>;
}
/** Linha do tempo do projeto colaborativo. */
export function Flow({ s }: { s: string }) {
  if (s === 'nao_adequada' || s === 'nao_autorizado') return <Note kind="danger" icon="info">{P_STATUS[s][0]}. O projeto foi encerrado antes do início.</Note>;
  const i = FLOW.findIndex(([k]) => k === s);
  return <ol className="flow" aria-label={'Etapa atual: ' + (P_STATUS[s]?.[0] || s)}>
    {FLOW.map(([k, l], j) => <li key={k} className={s === 'concluido' || j < i ? 'done' : j === i ? 'now' : ''}><span className="dot">{s === 'concluido' || j < i ? '✓' : j + 1}</span><span className="lab">{l}</span></li>)}
  </ol>;
}

/* ---------- blocos ---------- */
export function Empty({ icon, title, text, children }: { icon: string; title: string; text: string; children?: React.ReactNode }) {
  return <div className="empty"><Icon name={icon} /><h3>{title}</h3><p className="small">{text}</p>{children}</div>;
}
export function Skeleton() {
  return <div className="stack" aria-busy="true" aria-label="Carregando"><div className="skel" style={{ height: 22, width: '40%' }} /><div className="skel" style={{ height: 38, width: '65%' }} />
    <div className="grid g3">{[1, 2, 3].map((i) => <div key={i} className="skel" style={{ height: 150 }} />)}</div><div className="skel" style={{ height: 220 }} /></div>;
}
export function ErrorBox({ error, retry }: { error: string; retry?: () => void }) {
  return <div className="panel"><Empty icon="alert" title="Não foi possível carregar" text={error}>{retry && <button className="btn btn-ghost btn-sm" onClick={retry}>Tentar novamente</button>}</Empty></div>;
}
export function Note({ kind = '', icon = 'info', children }: { kind?: '' | 'warn' | 'danger' | 'ok'; icon?: string; children: React.ReactNode }) {
  return <div className={'note ' + kind}><Icon name={icon} /><span>{children}</span></div>;
}
export function PageHead({ title, eyebrow, actions, back }: { title: React.ReactNode; eyebrow?: React.ReactNode; actions?: React.ReactNode; back?: [string, string] }) {
  return <>
    {back && <Link className="back link-plain" to={back[0]}><Icon name="left" /> {back[1]}</Link>}
    <div className="phead"><div className="t">{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1></div>{actions && <div className="row">{actions}</div>}</div>
  </>;
}
export function Kpi({ n, l, s, children }: { n: React.ReactNode; l: string; s?: React.ReactNode; children?: React.ReactNode }) {
  return <div className="kpi"><span className="l">{l}</span><span className="n">{n}</span>{s && <span className="s">{s}</span>}{children}</div>;
}
export function Bars({ rows, gold }: { rows: [string, number][]; gold?: boolean }) {
  const max = Math.max(1, ...rows.map((r) => r[1]));
  const top = Math.ceil(max / 4) * 4 || 4;
  return <><div className="bars">{rows.map(([l, v]) => <div className="bar" key={l}><span className="lab" title={l}>{l}</span><span className="tr"><span className={'fl' + (gold ? ' g' : '')} style={{ width: (v / top) * 100 + '%' }} /></span><span className="v">{v}</span></div>)}</div>
    <p className="small muted" style={{ marginTop: 8 }}>Escala de 0 a {top}. Linhas de grade a cada {top / 4}.</p></>;
}
export function ExtLink({ url }: { url: string }) {
  return <a href={url} target="_blank" rel="noopener noreferrer nofollow" style={{ wordBreak: 'break-all' }}>{url}</a>;
}

/* ---------- carregamento de dados ---------- */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const seq = useRef(0);
  const reload = useCallback(async (quiet = false) => {
    const n = ++seq.current;
    if (!quiet) setLoading(true);
    setError('');
    try { const d = await fn(); if (n === seq.current) setData(d); }
    catch (e: any) { if (n === seq.current) setError(e?.message || 'Erro ao carregar.'); }
    finally { if (n === seq.current) setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { reload(); }, [reload]);
  return { data, error, loading, reload, setData };
}
export function Loaded<T>({ s, children }: { s: { data: T | null; error: string; loading: boolean; reload: (q?: boolean) => void }; children: (d: T) => React.ReactNode }) {
  if (s.loading && !s.data) return <Skeleton />;
  if (s.error && !s.data) return <ErrorBox error={s.error} retry={() => s.reload()} />;
  if (!s.data) return <Skeleton />;
  return <>{children(s.data)}</>;
}

/* ---------- avisos (toasts) e confirmações ---------- */
type Toast = { id: number; msg: string; kind: string };
const UiCtx = createContext<{ toast: (m: string, k?: string) => void; confirm: (o: ConfirmOpts) => void }>({ toast: () => {}, confirm: () => {} });
type ConfirmOpts = { title: string; text: React.ReactNode; ok: string; danger?: boolean; onOk: () => Promise<void> | void };
export function UiProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [conf, setConf] = useState<ConfirmOpts | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useCallback((msg: string, kind = '') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500);
  }, []);
  const confirm = useCallback((o: ConfirmOpts) => setConf(o), []);
  async function ok() {
    if (!conf) return;
    setBusy(true);
    try { await conf.onOk(); setConf(null); }
    catch (e: any) { toast(e?.message || 'Não foi possível concluir.', 'err'); }
    finally { setBusy(false); }
  }
  return <UiCtx.Provider value={{ toast, confirm }}>
    {children}
    <div className="toasts" role="status" aria-live="polite">{toasts.map((t) => <div key={t.id} className={'toast ' + t.kind}><Icon name={t.kind === 'err' ? 'alert' : t.kind === 'warn' ? 'info' : 'check'} /><span>{t.msg}</span></div>)}</div>
    {conf && <Modal title={conf.title} onClose={() => !busy && setConf(null)} foot={<>
      <button className="btn btn-ghost" onClick={() => setConf(null)} disabled={busy}>Cancelar</button>
      <button className={'btn ' + (conf.danger ? 'btn-danger' : 'btn-primary')} onClick={ok} disabled={busy} autoFocus>{busy ? <><span className="spin" /> Aguarde…</> : conf.ok}</button></>}>
      <div>{conf.text}</div></Modal>}
  </UiCtx.Provider>;
}
export const useUi = () => useContext(UiCtx);

export function Modal({ title, children, foot, onClose, wide }: { title: string; children: React.ReactNode; foot?: React.ReactNode; onClose: () => void; wide?: boolean }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', h); return () => document.removeEventListener('keydown', h);
  }, [onClose]);
  return <div className="modal-bg" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="modal" role="dialog" aria-modal="true" aria-label={title} style={wide ? { maxWidth: 760 } : undefined}>
      <div className="modal-h"><h3>{title}</h3><button className="iconbtn" onClick={onClose} aria-label="Fechar"><Icon name="x" /></button></div>
      <div className="modal-b">{children}</div>
      {foot && <div className="modal-f">{foot}</div>}
    </div></div>;
}

/* ---------- formulários ---------- */
const FormCtx = createContext<{ errors: Record<string, string>; busy: boolean }>({ errors: {}, busy: false });
type FormProps = {
  onSubmit: (fd: FormData, form: HTMLFormElement) => Promise<void>;
  validate?: (fd: FormData) => Record<string, string>;
  children: React.ReactNode; className?: string; id?: string;
};
export function Form({ onSubmit, validate, children, className = 'stack', id }: FormProps) {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLFormElement>(null);
  async function handle(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget, fd = new FormData(form);
    const errs: Record<string, string> = {};
    // validação no navegador: campos obrigatórios
    form.querySelectorAll<HTMLInputElement>('[data-required]').forEach((el) => {
      const empty = el.type === 'checkbox' ? !el.checked : !String(el.value || '').trim();
      if (empty && el.name && !errs[el.name]) errs[el.name] = el.dataset.required || 'Campo obrigatório.';
    });
    Object.assign(errs, validate ? validate(fd) : {});
    setErrors(errs);
    if (Object.keys(errs).length) {
      setMsg('Revise os campos destacados antes de continuar.');
      (form.querySelector(`[name="${Object.keys(errs)[0]}"]`) as HTMLElement | null)?.focus();
      return;
    }
    setMsg(''); setBusy(true);
    try { await onSubmit(fd, form); }
    catch (err: any) {
      if (err instanceof ApiError) {
        setErrors(err.fields || {}); setMsg(err.message);
        const k = Object.keys(err.fields || {})[0];
        if (k) (form.querySelector(`[name="${k}"]`) as HTMLElement | null)?.focus();
      } else setMsg('Algo deu errado. Tente novamente.');
    } finally { if (ref.current) setBusy(false); }
  }
  return <FormCtx.Provider value={{ errors, busy }}>
    <form ref={ref} noValidate onSubmit={handle} className={className} id={id}>
      {children}
      <div className={'form-msg' + (msg ? ' is-error' : '')} role="alert">{msg}</div>
    </form>
  </FormCtx.Provider>;
}
export function Field({ name, label, hint, required, children }: { name: string; label: React.ReactNode; hint?: string; required?: boolean; children: React.ReactNode }) {
  const { errors } = useContext(FormCtx);
  return <div className="field"><label htmlFor={'f-' + name}>{label}{required && <span className="req"> *</span>} {hint && <span className="hint">{hint}</span>}</label>{children}{errors[name] && <p className="err">{errors[name]}</p>}</div>;
}
export function FieldError({ name }: { name: string }) { const { errors } = useContext(FormCtx); return errors[name] ? <p className="err">{errors[name]}</p> : null; }
type InputProps = React.InputHTMLAttributes<HTMLInputElement> & { name: string; req?: string | boolean };
export function Input({ name, req, ...p }: InputProps) {
  const { errors } = useContext(FormCtx);
  return <input id={'f-' + name} name={name} aria-invalid={errors[name] ? true : undefined} data-required={req ? (req === true ? 'Campo obrigatório.' : req) : undefined} {...p} />;
}
export function Textarea({ name, req, ...p }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { name: string; req?: string | boolean }) {
  const { errors } = useContext(FormCtx);
  return <textarea id={'f-' + name} name={name} aria-invalid={errors[name] ? true : undefined} data-required={req ? (req === true ? 'Campo obrigatório.' : req) : undefined} {...p} />;
}
export function Select({ name, req, children, ...p }: React.SelectHTMLAttributes<HTMLSelectElement> & { name: string; req?: string | boolean }) {
  const { errors } = useContext(FormCtx);
  return <select id={'f-' + name} name={name} aria-invalid={errors[name] ? true : undefined} data-required={req ? (req === true ? 'Selecione uma opção.' : req) : undefined} {...p}>{children}</select>;
}
export function Check({ name, req, children, ...p }: React.InputHTMLAttributes<HTMLInputElement> & { name: string; req?: string; children: React.ReactNode }) {
  const { errors } = useContext(FormCtx);
  return <div className="stack-sm" style={{ gap: 4 }}><label className="check"><input type="checkbox" name={name} value="true" data-required={req} aria-invalid={errors[name] ? true : undefined} {...p} /> <span>{children}</span></label>{errors[name] && <p className="err">{errors[name]}</p>}</div>;
}
export function Submit({ children, className = 'btn btn-primary', busyLabel = 'Enviando…', ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { busyLabel?: string }) {
  const { busy } = useContext(FormCtx);
  return <button type="submit" className={className} disabled={busy || p.disabled} {...p}>{busy ? <><span className="spin" /> {busyLabel}</> : children}</button>;
}

/** Botão que executa uma ação assíncrona e mostra aviso. */
export function ActionButton({ action, children, className = 'btn btn-ghost btn-sm', success, ...p }:
  React.ButtonHTMLAttributes<HTMLButtonElement> & { action: () => Promise<unknown>; success?: string }) {
  const [busy, setBusy] = useState(false);
  const { toast } = useUi();
  return <button className={className} disabled={busy || p.disabled} {...p} onClick={async () => {
    setBusy(true);
    try { await action(); if (success) toast(success); }
    catch (e: any) { toast(e?.message || 'Não foi possível concluir.', 'err'); }
    finally { setBusy(false); }
  }}>{busy ? <span className="spin" /> : null}{children}</button>;
}

export function useGo() { const nav = useNavigate(); return (to: string) => { nav(to); window.scrollTo({ top: 0 }); }; }
export function copyText(text: string, toast: (m: string, k?: string) => void) {
  navigator.clipboard?.writeText(text).then(() => toast('Copiado para a área de transferência.'), () => toast('Não foi possível copiar. Selecione o texto e use Ctrl+C.', 'warn'));
}

/** Link para arquivo servido pela API (anexo, exportação). Na versão do navegador, downloads ficam desativados. */
export function ApiLink({ href, className, children, download }: { href: string; className?: string; children: React.ReactNode; download?: string }) {
  return <a className={className} href={href} download={download}>{children}</a>;
}
