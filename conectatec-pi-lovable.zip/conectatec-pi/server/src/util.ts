import crypto from 'node:crypto';
import type { Request, Response, NextFunction, RequestHandler } from 'express';
import { z, ZodError } from 'zod';
import { q, Client, pool } from './db.js';

export class HttpError extends Error {
  constructor(public status: number, message: string, public fields?: Record<string, string>) { super(message); }
}
export const bad = (msg: string, fields?: Record<string, string>) => new HttpError(400, msg, fields);
export const forbidden = (msg = 'Você não tem permissão para esta ação.') => new HttpError(403, msg);
export const notFound = (msg = 'Registro não encontrado.') => new HttpError(404, msg);

export const ah = (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => { fn(req, res, next).catch(next); };

export function parse<T extends z.ZodTypeAny>(schema: T, data: unknown): z.infer<T> {
  try {
    return schema.parse(data);
  } catch (e) {
    if (e instanceof ZodError) {
      const fields: Record<string, string> = {};
      for (const i of e.issues) { const k = String(i.path[0] ?? '_'); if (!fields[k]) fields[k] = i.message; }
      throw bad('Revise os campos destacados.', fields);
    }
    throw e;
  }
}

/* validadores reutilizáveis (mensagens em português) */
export const zText = (min: number, max: number, label: string) =>
  z.string({ required_error: `${label} é obrigatório.`, invalid_type_error: `${label} inválido.` })
    .trim().min(min, min <= 1 ? `${label} é obrigatório.` : `${label}: mínimo de ${min} caracteres.`).max(max, `${label}: máximo de ${max} caracteres.`);
export const zEmail = z.string().trim().toLowerCase().email('Informe um e-mail válido.').max(160);
export const zPassword = z.string().min(8, 'Use pelo menos 8 caracteres.').max(128)
  .refine((s) => /[a-zA-Z]/.test(s) && /\d/.test(s), 'Use letras e números.');
export const zList = (max = 20) => z.union([z.array(z.string()), z.string()]).optional()
  .transform((v) => (Array.isArray(v) ? v : String(v ?? '').split(/[,;\n]/)).map((s) => s.trim()).filter(Boolean).slice(0, max).map((s) => s.slice(0, 60)));
export const zUuid = z.string().uuid('Identificador inválido.');
export const zDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Informe uma data válida.');
export const YEARS = ['1ª série', '2ª série', '3ª série'] as const;

export function slugify(s: string) {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}
export function shortName(name: string) {
  const p = String(name || '').trim().split(/\s+/);
  return p[0] + (p[1] ? ' ' + p[1][0] + '.' : '');
}
export function randomCode(len = 8) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const b = crypto.randomBytes(len);
  return Array.from(b, (x) => alphabet[x % alphabet.length]).join('');
}
export function tempPassword() {
  return 'Ct' + randomCode(6) + String(crypto.randomInt(10, 99));
}

/** Oculta telefones e e-mails escritos em murais; sinaliza pedidos de contato fora da plataforma. */
export function sanitizePost(t: string) {
  let flagged = false;
  const text = t
    .replace(/(\+?55[\s.-]?)?\(?\d{2}\)?[\s.-]?9?\d{4}[\s.-]?\d{4}/g, () => { flagged = true; return '[contato removido]'; })
    .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, () => { flagged = true; return '[e-mail removido]'; });
  if (/whats\s?app|\bzap\b|instagram|telegram|me chama no privado|\bdirect\b|\bdm\b|meu n[uú]mero/i.test(t)) flagged = true;
  return { text, flagged, masked: text !== t };
}

/** Registro de acessos e ações relevantes. */
export async function audit(req: Request | null, action: string, opts: { targetType?: string; targetId?: string | null; detail?: string; schoolId?: string | null; user?: { id: string; name: string; role: string; school_id?: string | null } } = {}, c: Client = pool) {
  const u = opts.user || (req as any)?.user;
  const ip = req ? String(req.ip || '').slice(0, 64) : null;
  await q(`INSERT INTO audit_log (user_id, user_label, role, action, target_type, target_id, detail, school_id, ip) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [u?.id ?? null, u?.name ?? '', u?.role ?? null, action, opts.targetType ?? null, opts.targetId ?? null, (opts.detail ?? '').slice(0, 400), opts.schoolId ?? u?.school_id ?? null, ip], c);
}
export async function addFlag(type: string, text: string, projectId: string | null, schoolId: string | null, c: Client = pool) {
  await q('INSERT INTO flags (type, text, project_id, school_id) VALUES ($1,$2,$3,$4)', [type, text.slice(0, 500), projectId, schoolId], c);
}

export function todayPlus(n: number) {
  const d = new Date(Date.now() - 3 * 3600e3); // horário de Brasília
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** Gera um usuário institucional único para estudante: nome.sobrenome[n] */
export async function uniqueLogin(name: string, c: Client = pool) {
  const p = slugify(name).split('-').filter(Boolean);
  const base = (p[0] || 'estudante') + (p.length > 1 ? '.' + p[p.length - 1] : '');
  for (let i = 0; i < 50; i++) {
    const cand = i === 0 ? base : base + (i + 1);
    const r = await q('SELECT 1 FROM users WHERE lower(login) = $1', [cand], c);
    if (!r.length) return cand;
  }
  return base + '.' + randomCode(4).toLowerCase();
}
