import pg from 'pg';

// Datas (tipo DATE) chegam como texto 'AAAA-MM-DD', sem conversão de fuso.
pg.types.setTypeParser(1082, (v: string) => v);

const ssl = process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined;

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl,
  max: Number(process.env.DATABASE_POOL_MAX || 10),
});

export type Client = pg.PoolClient | pg.Pool;

export async function q<T = any>(text: string, params: unknown[] = [], c: Client = pool): Promise<T[]> {
  const r = await c.query(text, params as any[]);
  return r.rows as T[];
}

export async function one<T = any>(text: string, params: unknown[] = [], c: Client = pool): Promise<T | null> {
  const rows = await q<T>(text, params, c);
  return rows[0] ?? null;
}

export async function tx<T>(fn: (c: pg.PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    await c.query('ROLLBACK');
    throw e;
  } finally {
    c.release();
  }
}
