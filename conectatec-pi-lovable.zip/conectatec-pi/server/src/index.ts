import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { pool, one, q } from './db.js';
import { migrate } from './migrate.js';
import { sessionMiddleware, loadUser, csrfGuard, hashPassword } from './auth.js';
import { HttpError } from './util.js';
import { authRouter } from './routes/auth.js';
import { publicRouter } from './routes/public.js';
import { demandsRouter } from './routes/demands.js';
import { projectsRouter, submissionsRouter, postsRouter } from './routes/projects.js';
import { studentRouter, meRouter } from './routes/student.js';
import { teacherRouter } from './routes/teacher.js';
import { schoolRouter } from './routes/school.js';
import { companyRouter, opportunitiesRouter } from './routes/company.js';
import { adminRouter } from './routes/admin.js';

const here = path.dirname(fileURLToPath(import.meta.url));

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  if (process.env.TRUST_PROXY !== 'false') app.set('trust proxy', 1);
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        scriptSrc: ["'self'"],
        connectSrc: ["'self'"],
        frameAncestors: ["'none'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null,
      },
    },
    crossOriginEmbedderPolicy: false,
  }));
  app.use(compression());
  app.use(express.json({ limit: '200kb' }));
  app.use(express.urlencoded({ extended: false, limit: '200kb' }));

  app.get('/api/health', async (_req, res) => {
    try { await pool.query('SELECT 1'); res.json({ ok: true }); } catch { res.status(503).json({ ok: false }); }
  });

  app.use('/api', sessionMiddleware(), loadUser, csrfGuard);
  app.use('/api/auth', authRouter);
  app.use('/api/public', publicRouter);
  app.use('/api/demands', demandsRouter);
  app.use('/api/projects', projectsRouter);
  app.use('/api/submissions', submissionsRouter);
  app.use('/api/posts', postsRouter);
  app.use('/api/student', studentRouter);
  app.use('/api/me', meRouter);
  app.use('/api/teacher', teacherRouter);
  app.use('/api/school', schoolRouter);
  app.use('/api/company', companyRouter);
  app.use('/api/opportunities', opportunitiesRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Rota não encontrada.')));

  const webDir = process.env.WEB_DIR ? path.resolve(process.env.WEB_DIR) : path.resolve(here, '..', '..', 'web', 'dist');
  if (fs.existsSync(webDir)) {
    app.use(express.static(webDir, {
      index: false,
      setHeaders: (res, file) => {
        if (file.endsWith('sw.js') || file.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
        else if (file.includes(`${path.sep}assets${path.sep}`)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      },
    }));
    app.get('*', (_req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(webDir, 'index.html')); });
  }

  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, fields: err.fields });
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Conteúdo muito grande.' });
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Dados inválidos.' });
    console.error(err);
    res.status(500).json({ error: 'Erro interno. Tente novamente em instantes.' });
  });
  return app;
}

async function bootstrapAdmin() {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const pw = process.env.ADMIN_PASSWORD;
  if (!email || !pw) return;
  if (await one(`SELECT 1 FROM users WHERE role = 'admin' AND NOT is_demo LIMIT 1`)) return;
  if (await one('SELECT 1 FROM users WHERE lower(login) = $1', [email])) return;
  if (pw.length < 10) { console.warn('[admin] ADMIN_PASSWORD precisa ter 10+ caracteres. Administrador não criado.'); return; }
  await q(`INSERT INTO users (role, name, login, email, password_hash, must_change_password) VALUES ('admin', $1, $2, $2, $3, true)`,
    [process.env.ADMIN_NAME || 'Administração ConectaTec', email, await hashPassword(pw)]);
  console.log(`[admin] Administrador criado: ${email} (troca de senha obrigatória no primeiro acesso).`);
}

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);
if (isMain) {
  if (!process.env.DATABASE_URL) { console.error('Defina DATABASE_URL.'); process.exit(1); }
  (async () => {
    await migrate();
    await bootstrapAdmin();
    const port = Number(process.env.PORT || 3000);
    createApp().listen(port, () => console.log(`ConectaTec PI rodando na porta ${port}`));
  })().catch((e) => { console.error(e); process.exit(1); });
}
