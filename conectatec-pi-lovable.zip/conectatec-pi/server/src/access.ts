import { one, q, Client, pool } from './db.js';
import type { SessionUser } from './auth.js';
import { shortName } from './util.js';

/** Situações em que a empresa acompanha o projeto (depois da autorização da escola). */
export const COMPANY_VISIBLE = ['aprovado', 'em_andamento', 'entregue', 'validado', 'concluido'];
/** Situações em que estudantes da turma (fora da equipe) veem o resumo. */
export const TURMA_VISIBLE = COMPANY_VISIBLE;

export type Access = 'admin' | 'school' | 'teacher' | 'member' | 'turma' | 'company' | null;

export async function loadProject(id: string, c: Client = pool) {
  return one(`SELECT p.*, d.company_id, d.title, d.need, d.objectives, d.expected_results, d.techs, d.area, d.city AS demand_city,
      d.suggested_deadline, d.hours, d.criteria, d.status AS demand_status, d.max_projects,
      co.name AS company_name, co.sector AS company_sector, s.name AS school_name, s.city AS school_city,
      t.name AS turma_name, t.course AS turma_course, t.year AS turma_year, t.teacher_id AS turma_teacher_id,
      tu.name AS teacher_name
    FROM projects p JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = d.company_id
    JOIN schools s ON s.id = p.school_id JOIN turmas t ON t.id = p.turma_id LEFT JOIN users tu ON tu.id = p.teacher_id
    WHERE p.id = $1`, [id], c);
}

export async function projectAccess(u: SessionUser | undefined, p: any): Promise<Access> {
  if (!u || !p) return null;
  if (u.role === 'admin') return 'admin';
  if (u.role === 'school') return u.school_id === p.school_id ? 'school' : null;
  if (u.role === 'teacher') return p.teacher_id === u.id || p.turma_teacher_id === u.id ? 'teacher' : null;
  if (u.role === 'company') return u.company_id === p.company_id && COMPANY_VISIBLE.includes(p.status) ? 'company' : null;
  if (u.role === 'student') {
    if (await one('SELECT 1 FROM project_members WHERE project_id = $1 AND student_id = $2', [p.id, u.id])) return 'member';
    if (u.turma_id === p.turma_id && TURMA_VISIBLE.includes(p.status)) return 'turma';
  }
  return null;
}
export const isStaff = (a: Access) => a === 'admin' || a === 'school' || a === 'teacher';
export const canMural = (a: Access) => a === 'admin' || a === 'school' || a === 'teacher' || a === 'member' || a === 'company';

/** Como cada perfil vê o nome de um estudante. Empresas nunca veem nomes. */
export function studentLabel(a: Access, name: string) {
  if (a === 'company') return 'Estudante da equipe';
  if (isStaff(a)) return name;
  return shortName(name);
}

export async function members(projectId: string, a: Access, viewerId?: string) {
  const rows = await q<{ id: string; name: string; student_code: string | null }>(
    'SELECT u.id, u.name, u.student_code FROM project_members m JOIN users u ON u.id = m.student_id WHERE m.project_id = $1 ORDER BY u.name', [projectId]);
  if (a === 'company') return [];
  return rows.map((r) => ({ id: r.id, name: studentLabel(a, r.name), code: isStaff(a) ? r.student_code : undefined, isMe: r.id === viewerId }));
}

export async function isTeacherOfTurma(userId: string, turmaId: string, c: Client = pool) {
  return !!(await one('SELECT 1 FROM turmas WHERE id = $1 AND teacher_id = $2', [turmaId, userId], c));
}
