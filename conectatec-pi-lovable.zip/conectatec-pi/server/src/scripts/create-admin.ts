/**
 * Cria uma conta de administrador da plataforma pela linha de comando.
 * Uso: npm run create-admin -- "Nome Completo" email@exemplo.com
 * Uma senha temporária é exibida; ela precisa ser trocada no primeiro acesso.
 */
import { pool, one, q } from '../db.js';
import { hashPassword } from '../auth.js';
import { migrate } from '../migrate.js';
import { tempPassword } from '../util.js';

const [name, email] = process.argv.slice(2);
if (!name || !email || !email.includes('@')) {
  console.error('Uso: npm run create-admin -- "Nome Completo" email@exemplo.com');
  process.exit(1);
}
(async () => {
  await migrate();
  if (await one('SELECT 1 FROM users WHERE lower(login) = lower($1)', [email])) { console.error('Já existe uma conta com este e-mail.'); process.exit(1); }
  const pw = tempPassword();
  await q(`INSERT INTO users (role, name, login, email, password_hash, must_change_password) VALUES ('admin',$1,lower($2),lower($2),$3,true)`, [name, email, await hashPassword(pw)]);
  console.log(`Administrador criado: ${email}\nSenha temporária: ${pw}\nTroque a senha no primeiro acesso.`);
  await pool.end();
})().catch((e) => { console.error(e); process.exit(1); });
