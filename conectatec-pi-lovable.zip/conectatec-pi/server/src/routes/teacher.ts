import { Router } from 'express';
import { one, q } from '../db.js';
import { requireRole } from '../auth.js';
import { isTeacherOfTurma } from '../access.js';
import { ah, parse, forbidden, zUuid } from '../util.js';

export const teacherRouter = Router();
teacherRouter.use(requireRole('teacher'));

const PROJ = `SELECT p.id, p.status, p.is_demo, p.created_at, d.title, d.suggested_deadline, co.name AS company_name, t.name AS turma_name,
    (SELECT count(*)::int FROM project_members m WHERE m.project_id = p.id) AS members,
    (SELECT max(s.created_at) FROM submissions s WHERE s.project_id = p.id) AS last_submission
  FROM projects p JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = d.company_id JOIN turmas t ON t.id = p.turma_id`;
export const mapProj = (p: any) => ({ id: p.id, status: p.status, isDemo: p.is_demo, createdAt: p.created_at, title: p.title, deadline: p.suggested_deadline,
  companyName: p.company_name, turmaName: p.turma_name, members: p.members, lastSubmission: p.last_submission });

teacherRouter.get('/dashboard', ah(async (req, res) => {
  const u = req.user!;
  const school = await one('SELECT name, status FROM schools WHERE id = $1', [u.school_id]);
  const turmas = await q(`SELECT t.id, t.name, t.course, t.year,
      (SELECT count(*)::int FROM users x WHERE x.turma_id = t.id AND x.role='student' AND x.active) AS students,
      (SELECT count(*)::int FROM users x WHERE x.turma_id = t.id AND x.role='student' AND x.active AND x.consent_status='pendente') AS consent_pending
    FROM turmas t WHERE t.teacher_id = $1 ORDER BY t.name`, [u.id]);
  const projects = await q(`${PROJ} WHERE p.teacher_id = $1 OR t.teacher_id = $1 ORDER BY p.created_at DESC`, [u.id]);
  const milestones = await q(`SELECT m.title, m.due_date, d.title AS project_title, p.id AS project_id FROM milestones m JOIN projects p ON p.id = m.project_id
    JOIN demands d ON d.id = p.demand_id WHERE p.teacher_id = $1 AND NOT m.done AND p.status IN ('em_andamento','entregue') ORDER BY m.due_date LIMIT 8`, [u.id]);
  const posts = await q(`SELECT po.text, po.created_at, po.masked, us.role, us.name, d.title, p.id AS project_id FROM posts po JOIN projects p ON p.id = po.project_id
    JOIN demands d ON d.id = p.demand_id LEFT JOIN users us ON us.id = po.author_id WHERE p.teacher_id = $1 AND NOT po.hidden ORDER BY po.created_at DESC LIMIT 6`, [u.id]);
  res.json({
    school,
    turmas: turmas.map((t) => ({ id: t.id, name: t.name, course: t.course, year: t.year, students: t.students, consentPending: t.consent_pending })),
    projects: projects.map(mapProj),
    milestones: milestones.map((m) => ({ title: m.title, dueDate: m.due_date, projectTitle: m.project_title, projectId: m.project_id })),
    posts: posts.map((p) => ({ text: p.text, createdAt: p.created_at, masked: p.masked, role: p.role, author: p.role === 'company' ? 'Empresa' : p.name, title: p.title, projectId: p.project_id })),
  });
}));

teacherRouter.get('/turmas/:id', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  if (!(await isTeacherOfTurma(req.user!.id, id))) throw forbidden('Esta turma não é sua.');
  const turma = await one('SELECT id, name, course, year FROM turmas WHERE id = $1', [id]);
  const students = await q(`SELECT u.id, u.name, u.student_code, u.consent_status, u.is_minor, u.last_login_at,
      (SELECT count(*)::int FROM project_members m WHERE m.student_id = u.id) AS projects
    FROM users u WHERE u.turma_id = $1 AND u.role = 'student' AND u.active ORDER BY u.name`, [id]);
  const projects = await q(`${PROJ} WHERE p.turma_id = $1 ORDER BY p.created_at DESC`, [id]);
  res.json({
    turma,
    students: students.map((s) => ({ id: s.id, name: s.name, code: s.student_code, consentStatus: s.consent_status, isMinor: s.is_minor, lastLoginAt: s.last_login_at, projects: s.projects })),
    projects: projects.map(mapProj),
  });
}));
