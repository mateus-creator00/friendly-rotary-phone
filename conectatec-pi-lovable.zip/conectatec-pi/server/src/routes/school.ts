import { Router } from 'express';
import { z } from 'zod';
import { one, q, tx } from '../db.js';
import { requireRole, hashPassword } from '../auth.js';
import { ah, parse, bad, forbidden, notFound, zText, zEmail, zUuid, audit, tempPassword, uniqueLogin, YEARS, slugify, randomCode, shortName } from '../util.js';

export const schoolRouter = Router();
schoolRouter.use(requireRole('school'));

async function mySchool(req: any) {
  const s = await one('SELECT * FROM schools WHERE id = $1', [req.user.school_id]);
  if (!s) throw notFound('Escola não encontrada.');
  return s;
}
const approved = async (req: any, _res: any, next: any) => {
  try { const s = await mySchool(req); if (s.status !== 'aprovada') throw forbidden('A escola ainda aguarda aprovação da administração da plataforma.'); next(); }
  catch (e) { next(e); }
};

schoolRouter.get('/dashboard', ah(async (req, res) => {
  const s = await mySchool(req);
  const sid = s.id;
  const k = await one(`SELECT
    (SELECT count(*)::int FROM users WHERE school_id=$1 AND role='student' AND active) AS students,
    (SELECT count(*)::int FROM users WHERE school_id=$1 AND role='teacher' AND active) AS teachers,
    (SELECT count(*)::int FROM turmas WHERE school_id=$1) AS turmas,
    (SELECT count(*)::int FROM users WHERE school_id=$1 AND role='student' AND active AND consent_status='pendente') AS consent_pending,
    (SELECT count(*)::int FROM projects WHERE school_id=$1 AND status IN ('aprovado','em_andamento','entregue','validado')) AS active_projects,
    (SELECT count(*)::int FROM projects WHERE school_id=$1 AND status='concluido') AS concluded,
    (SELECT count(DISTINCT m.student_id)::int FROM project_members m JOIN projects p ON p.id = m.project_id WHERE p.school_id=$1) AS participants`, [sid]);
  const projects = await q(`SELECT p.id, p.status, p.is_demo, p.created_at, d.title, co.name AS company_name, t.name AS turma_name, u.name AS teacher_name,
      (SELECT count(*)::int FROM project_members m WHERE m.project_id = p.id) AS members
    FROM projects p JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = d.company_id JOIN turmas t ON t.id = p.turma_id LEFT JOIN users u ON u.id = p.teacher_id
    WHERE p.school_id = $1 ORDER BY p.created_at DESC`, [sid]);
  const interests = await q(`SELECT ci.message, ci.created_at, co.name AS company_name, d.title, p.id AS project_id FROM company_interests ci
    JOIN projects p ON p.id = ci.project_id JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = ci.company_id WHERE p.school_id = $1 ORDER BY ci.created_at DESC`, [sid]);
  const corrections = await q(`SELECT cr.id, cr.kind, cr.text, cr.status, cr.created_at, u.name FROM correction_requests cr LEFT JOIN users u ON u.id = cr.user_id
    WHERE cr.school_id = $1 ORDER BY (cr.status = 'aberto') DESC, cr.created_at DESC LIMIT 50`, [sid]);
  const flags = await q(`SELECT id, type, text, project_id, status, created_at FROM flags WHERE school_id = $1 AND status = 'aberta' ORDER BY created_at DESC`, [sid]);
  const oppInterests = await q(`SELECT u.name, o.title, co.name AS company_name, oi.created_at FROM opportunity_interests oi JOIN users u ON u.id = oi.student_id
    JOIN opportunities o ON o.id = oi.opportunity_id JOIN companies co ON co.id = o.company_id WHERE u.school_id = $1 ORDER BY oi.created_at DESC LIMIT 30`, [sid]);
  res.json({
    school: { id: s.id, name: s.name, city: s.city, inep: s.inep, status: s.status, note: s.note, isDemo: s.is_demo },
    kpis: k,
    projects: projects.map((p) => ({ id: p.id, status: p.status, isDemo: p.is_demo, createdAt: p.created_at, title: p.title, companyName: p.company_name, turmaName: p.turma_name, teacherName: p.teacher_name, members: p.members })),
    interests: interests.map((i) => ({ message: i.message, createdAt: i.created_at, companyName: i.company_name, title: i.title, projectId: i.project_id })),
    corrections: corrections.map((c) => ({ id: c.id, kind: c.kind, text: c.text, status: c.status, createdAt: c.created_at, name: c.name })),
    flags: flags.map((f) => ({ id: f.id, type: f.type, text: f.text, projectId: f.project_id, createdAt: f.created_at })),
    oppInterests: oppInterests.map((o) => ({ name: o.name, title: o.title, companyName: o.company_name, createdAt: o.created_at })),
  });
}));

schoolRouter.get('/people', approved, ah(async (req, res) => {
  const sid = req.user!.school_id;
  const turmas = await q(`SELECT t.id, t.name, t.course, t.year, t.teacher_id, u.name AS teacher_name, t.is_demo,
      (SELECT count(*)::int FROM users x WHERE x.turma_id = t.id AND x.role='student' AND x.active) AS students
    FROM turmas t LEFT JOIN users u ON u.id = t.teacher_id WHERE t.school_id = $1 ORDER BY t.name`, [sid]);
  const teachers = await q(`SELECT id, name, login, active, must_change_password, last_login_at, is_demo FROM users WHERE school_id = $1 AND role = 'teacher' ORDER BY name`, [sid]);
  const students = await q(`SELECT u.id, u.name, u.login, u.student_code, u.turma_id, t.name AS turma_name, u.year, u.is_minor, u.consent_status,
      u.portfolio_public_allowed, u.active, u.must_change_password, u.last_login_at, u.is_demo
    FROM users u LEFT JOIN turmas t ON t.id = u.turma_id WHERE u.school_id = $1 AND u.role = 'student' ORDER BY u.name`, [sid]);
  res.json({
    turmas: turmas.map((t) => ({ id: t.id, name: t.name, course: t.course, year: t.year, teacherId: t.teacher_id, teacherName: t.teacher_name, students: t.students, isDemo: t.is_demo })),
    teachers: teachers.map((t) => ({ id: t.id, name: t.name, login: t.login, active: t.active, mustChangePassword: t.must_change_password, lastLoginAt: t.last_login_at, isDemo: t.is_demo })),
    students: students.map((s) => ({ id: s.id, name: s.name, login: s.login, code: s.student_code, turmaId: s.turma_id, turmaName: s.turma_name, year: s.year, isMinor: s.is_minor,
      consentStatus: s.consent_status, portfolioAllowed: s.portfolio_public_allowed, active: s.active, mustChangePassword: s.must_change_password, lastLoginAt: s.last_login_at, isDemo: s.is_demo })),
  });
}));

schoolRouter.post('/teachers', approved, ah(async (req, res) => {
  const b = parse(z.object({ name: zText(5, 80, 'Nome'), email: zEmail }), req.body);
  if (await one('SELECT 1 FROM users WHERE lower(login) = $1', [b.email])) throw bad('E-mail já cadastrado.', { email: 'Já existe uma conta com este e-mail.' });
  const pw = tempPassword();
  const u = await one(`INSERT INTO users (role, name, login, email, password_hash, must_change_password, school_id, created_by) VALUES ('teacher',$1,$2,$2,$3,true,$4,$5) RETURNING id`,
    [b.name, b.email, await hashPassword(pw), req.user!.school_id, req.user!.id]);
  await audit(req, 'Cadastrou professor(a)', { targetType: 'user', targetId: u.id, detail: b.name });
  res.status(201).json({ login: b.email, temporaryPassword: pw });
}));

schoolRouter.post('/turmas', approved, ah(async (req, res) => {
  const b = parse(z.object({
    course: zText(2, 80, 'Curso'), year: z.enum(YEARS, { errorMap: () => ({ message: 'Selecione a série.' }) }),
    letter: zText(1, 4, 'Identificação'), teacherId: zUuid.optional().nullable().or(z.literal('')),
  }), req.body);
  if (!(await one('SELECT 1 FROM courses WHERE name = $1', [b.course]))) throw bad('Curso inválido.', { course: 'Selecione um curso da lista.' });
  if (b.teacherId && !(await one(`SELECT 1 FROM users WHERE id = $1 AND role = 'teacher' AND school_id = $2`, [b.teacherId, req.user!.school_id]))) throw bad('Professor inválido.', { teacherId: 'Selecione um professor da escola.' });
  const name = `${b.year} ${b.letter.toUpperCase()} — ${b.course}`;
  if (await one('SELECT 1 FROM turmas WHERE school_id = $1 AND name = $2', [req.user!.school_id, name])) throw bad('Turma já existe.', { letter: 'Já existe uma turma com esta identificação.' });
  await q('INSERT INTO turmas (school_id, name, course, year, teacher_id) VALUES ($1,$2,$3,$4,$5)', [req.user!.school_id, name, b.course, b.year, b.teacherId || null]);
  await audit(req, 'Cadastrou turma', { detail: name });
  res.status(201).json({ ok: true });
}));

schoolRouter.put('/turmas/:id', approved, ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(z.object({ teacherId: zUuid.nullable().or(z.literal('')) }), req.body);
  const t = await one('SELECT id, name FROM turmas WHERE id = $1 AND school_id = $2', [id, req.user!.school_id]);
  if (!t) throw notFound('Turma não encontrada.');
  if (b.teacherId && !(await one(`SELECT 1 FROM users WHERE id = $1 AND role = 'teacher' AND school_id = $2`, [b.teacherId, req.user!.school_id]))) throw bad('Professor inválido.');
  await tx(async (c) => {
    await q('UPDATE turmas SET teacher_id = $1 WHERE id = $2', [b.teacherId || null, id], c);
    // projetos ainda não concluídos passam a ser acompanhados pelo novo professor
    if (b.teacherId) await q(`UPDATE projects SET teacher_id = $1 WHERE turma_id = $2 AND status <> 'concluido'`, [b.teacherId, id], c);
    await audit(req, 'Alterou professor-orientador da turma', { detail: t.name }, c);
  });
  res.json({ ok: true });
}));

async function turmaOfSchool(turmaId: string, schoolId: string) {
  const t = await one('SELECT id, name, year FROM turmas WHERE id = $1 AND school_id = $2', [turmaId, schoolId]);
  if (!t) throw bad('Turma inválida.', { turmaId: 'Selecione uma turma da escola.' });
  return t;
}

schoolRouter.post('/students', approved, ah(async (req, res) => {
  const b = parse(z.object({
    name: zText(5, 80, 'Nome').refine((s) => s.split(/\s+/).length >= 2, 'Informe nome e sobrenome.'),
    studentCode: z.string().trim().max(30).optional().default(''),
    turmaId: zUuid, isMinor: z.boolean(),
  }), req.body);
  const t = await turmaOfSchool(b.turmaId, req.user!.school_id!);
  const login = await uniqueLogin(b.name);
  const pw = tempPassword();
  const u = await one(`INSERT INTO users (role, name, login, password_hash, must_change_password, school_id, turma_id, year, student_code, is_minor, consent_status, created_by)
    VALUES ('student',$1,$2,$3,true,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
    [b.name, login, await hashPassword(pw, 10), req.user!.school_id, t.id, t.year, b.studentCode || null, b.isMinor, b.isMinor ? 'pendente' : 'nao_aplica', req.user!.id]);
  await audit(req, 'Habilitou conta de estudante', { targetType: 'user', targetId: u.id, detail: `${shortName(b.name)} — ${t.name}` });
  res.status(201).json({ credentials: [{ name: b.name, login, temporaryPassword: pw }] });
}));

/** Cadastro em lote: uma linha por estudante, "Nome completo; matrícula". */
schoolRouter.post('/students/batch', approved, ah(async (req, res) => {
  const b = parse(z.object({ turmaId: zUuid, isMinor: z.boolean(), lines: zText(5, 20000, 'Lista') }), req.body);
  const t = await turmaOfSchool(b.turmaId, req.user!.school_id!);
  const rows = b.lines.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const [name, code] = l.split(/[;\t]/).map((x) => (x || '').trim()); return { name, code }; });
  if (!rows.length) throw bad('Lista vazia.', { lines: 'Informe pelo menos um estudante.' });
  if (rows.length > 60) throw bad('Lista muito grande.', { lines: 'Envie no máximo 60 estudantes por vez.' });
  const badLine = rows.findIndex((r) => !r.name || r.name.split(/\s+/).length < 2 || r.name.length > 80);
  if (badLine >= 0) throw bad('Linha inválida.', { lines: `Linha ${badLine + 1}: informe nome e sobrenome.` });
  const out = await tx(async (c) => {
    const creds: any[] = [];
    for (const r of rows) {
      const login = await uniqueLogin(r.name, c);
      const pw = tempPassword();
      await q(`INSERT INTO users (role, name, login, password_hash, must_change_password, school_id, turma_id, year, student_code, is_minor, consent_status, created_by)
        VALUES ('student',$1,$2,$3,true,$4,$5,$6,$7,$8,$9,$10)`,
        [r.name, login, await hashPassword(pw, 10), req.user!.school_id, t.id, t.year, (r.code || '').slice(0, 30) || null, b.isMinor, b.isMinor ? 'pendente' : 'nao_aplica', req.user!.id], c);
      creds.push({ name: r.name, login, temporaryPassword: pw });
    }
    await audit(req, `Habilitou ${creds.length} contas de estudantes em lote`, { detail: t.name }, c);
    return creds;
  });
  res.status(201).json({ credentials: out });
}));

schoolRouter.put('/students/:id', approved, ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(z.object({
    name: zText(5, 80, 'Nome').optional(), studentCode: z.string().trim().max(30).optional(),
    turmaId: zUuid.optional(), consentStatus: z.enum(['pendente', 'registrado', 'nao_aplica']).optional(),
    portfolioAllowed: z.boolean().optional(), active: z.boolean().optional(),
  }), req.body);
  const s = await one(`SELECT id, name FROM users WHERE id = $1 AND school_id = $2 AND role = 'student'`, [id, req.user!.school_id]);
  if (!s) throw notFound('Estudante não encontrado na sua escola.');
  const changes: string[] = [];
  await tx(async (c) => {
    if (b.name !== undefined) { await q('UPDATE users SET name = $1 WHERE id = $2', [b.name, id], c); changes.push('nome'); }
    if (b.studentCode !== undefined) { await q('UPDATE users SET student_code = $1 WHERE id = $2', [b.studentCode || null, id], c); changes.push('identificação'); }
    if (b.turmaId) { const t = await turmaOfSchool(b.turmaId, req.user!.school_id!); await q('UPDATE users SET turma_id = $1, year = $2 WHERE id = $3', [t.id, t.year, id], c); changes.push('turma'); }
    if (b.consentStatus) { await q('UPDATE users SET consent_status = $1 WHERE id = $2', [b.consentStatus, id], c); changes.push('autorização: ' + b.consentStatus); }
    if (b.portfolioAllowed !== undefined) {
      await q('UPDATE users SET portfolio_public_allowed = $1, portfolio_public = CASE WHEN $1 THEN portfolio_public ELSE false END WHERE id = $2', [b.portfolioAllowed, id], c);
      changes.push(b.portfolioAllowed ? 'portfólio público autorizado' : 'portfólio público revogado');
    }
    if (b.active !== undefined) {
      await q('UPDATE users SET active = $1 WHERE id = $2', [b.active, id], c);
      if (!b.active) await q(`DELETE FROM "session" WHERE sess->>'userId' = $1`, [id], c);
      changes.push(b.active ? 'reativado' : 'desativado');
    }
    await audit(req, 'Atualizou cadastro de estudante', { targetType: 'user', targetId: id, detail: `${shortName(s.name)}: ${changes.join(', ')}` }, c);
  });
  res.json({ ok: true });
}));

schoolRouter.put('/teachers/:id', approved, ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(z.object({ active: z.boolean() }), req.body);
  const t = await one(`SELECT name FROM users WHERE id = $1 AND school_id = $2 AND role = 'teacher'`, [id, req.user!.school_id]);
  if (!t) throw notFound();
  await q('UPDATE users SET active = $1 WHERE id = $2', [b.active, id]);
  if (!b.active) await q(`DELETE FROM "session" WHERE sess->>'userId' = $1`, [id]);
  await audit(req, b.active ? 'Reativou professor(a)' : 'Desativou professor(a)', { targetType: 'user', targetId: id, detail: t.name });
  res.json({ ok: true });
}));

schoolRouter.post('/users/:id/reset-password', approved, ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const u = await one(`SELECT name, login, role FROM users WHERE id = $1 AND school_id = $2 AND role IN ('student','teacher')`, [id, req.user!.school_id]);
  if (!u) throw notFound('Usuário não encontrado na sua escola.');
  const pw = tempPassword();
  await q('UPDATE users SET password_hash = $1, must_change_password = true WHERE id = $2', [await hashPassword(pw, u.role === 'student' ? 10 : 12), id]);
  await q(`DELETE FROM "session" WHERE sess->>'userId' = $1`, [id]);
  await audit(req, 'Gerou nova senha temporária', { targetType: 'user', targetId: id, detail: u.role === 'student' ? shortName(u.name) : u.name });
  res.json({ login: u.login, temporaryPassword: pw });
}));

schoolRouter.post('/corrections/:id/resolve', approved, ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(z.object({ response: zText(5, 600, 'Resposta') }), req.body);
  const r = await one(`UPDATE correction_requests SET status = 'resolvido', response = $1 WHERE id = $2 AND school_id = $3 RETURNING id`, [b.response, id, req.user!.school_id]);
  if (!r) throw notFound();
  await audit(req, 'Respondeu pedido de correção/remoção', { targetType: 'correction', targetId: id });
  res.json({ ok: true });
}));

schoolRouter.post('/flags/:id/resolve', approved, ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const r = await one(`UPDATE flags SET status = 'resolvida' WHERE id = $1 AND school_id = $2 RETURNING id`, [id, req.user!.school_id]);
  if (!r) throw notFound();
  await audit(req, 'Resolveu sinalização', { targetType: 'flag', targetId: id });
  res.json({ ok: true });
}));

schoolRouter.get('/report', approved, ah(async (req, res) => {
  const sid = req.user!.school_id;
  const byTurma = await q(`SELECT t.name, t.course,
      (SELECT count(*)::int FROM users u WHERE u.turma_id = t.id AND u.role='student' AND u.active) AS students,
      (SELECT count(DISTINCT m.student_id)::int FROM project_members m JOIN projects p ON p.id = m.project_id WHERE p.turma_id = t.id) AS participants,
      (SELECT count(*)::int FROM projects p WHERE p.turma_id = t.id AND p.status IN ('aprovado','em_andamento','entregue','validado')) AS active,
      (SELECT count(*)::int FROM projects p WHERE p.turma_id = t.id AND p.status = 'concluido') AS concluded,
      (SELECT count(*)::int FROM certificates ce JOIN projects p ON p.id = ce.project_id WHERE p.turma_id = t.id) AS certificates
    FROM turmas t WHERE t.school_id = $1 ORDER BY t.name`, [sid]);
  const byStatus = await q(`SELECT status, count(*)::int AS n FROM projects WHERE school_id = $1 GROUP BY status`, [sid]);
  const audits = await q(`SELECT user_label, role, action, detail, created_at FROM audit_log WHERE school_id = $1 ORDER BY created_at DESC LIMIT 60`, [sid]);
  res.json({ byTurma, byStatus, audit: audits.map((a) => ({ user: a.user_label, role: a.role, action: a.action, detail: a.detail, createdAt: a.created_at })) });
}));

export { slugify, randomCode };
