import { Router } from 'express';
import { z } from 'zod';
import { one, q } from '../db.js';
import { requireAuth, requireRole } from '../auth.js';
import { ah, parse, bad, forbidden, notFound, zText, zUuid, slugify, shortName, randomCode, audit } from '../util.js';

export const studentRouter = Router();
export const meRouter = Router();

studentRouter.get('/dashboard', requireRole('student'), ah(async (req, res) => {
  const u = req.user!;
  const turma = u.turma_id ? await one('SELECT t.name, t.course, t.year, us.name AS teacher_name FROM turmas t LEFT JOIN users us ON us.id = t.teacher_id WHERE t.id = $1', [u.turma_id]) : null;
  const school = await one('SELECT name, city FROM schools WHERE id = $1', [u.school_id]);
  const mine = await q(`SELECT p.id, p.status, p.is_demo, d.title, d.suggested_deadline, co.name AS company_name,
      (SELECT json_agg(json_build_object('title', m.title, 'dueDate', m.due_date, 'done', m.done) ORDER BY m.position) FROM milestones m WHERE m.project_id = p.id) AS milestones,
      (SELECT json_build_object('kind', r.kind, 'text', r.text, 'role', r.role, 'createdAt', r.created_at) FROM reviews r WHERE r.project_id = p.id ORDER BY r.created_at DESC LIMIT 1) AS last_review
    FROM projects p JOIN project_members m ON m.project_id = p.id JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = d.company_id
    WHERE m.student_id = $1 ORDER BY p.created_at DESC`, [u.id]);
  const turmaProjects = u.turma_id ? await q(`SELECT p.id, p.status, d.title, co.name AS company_name FROM projects p JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = d.company_id
    WHERE p.turma_id = $1 AND p.status IN ('aprovado','em_andamento','entregue','validado','concluido')
      AND NOT EXISTS (SELECT 1 FROM project_members m WHERE m.project_id = p.id AND m.student_id = $2) ORDER BY p.created_at DESC`, [u.turma_id, u.id]) : [];
  const certs = (await one('SELECT count(*)::int AS n FROM certificates WHERE student_id = $1', [u.id])).n;
  res.json({
    turma, school, certificates: certs,
    projects: mine.map((p) => ({ id: p.id, status: p.status, isDemo: p.is_demo, title: p.title, deadline: p.suggested_deadline, companyName: p.company_name, milestones: p.milestones || [], lastReview: p.last_review })),
    turmaProjects: turmaProjects.map((p) => ({ id: p.id, status: p.status, title: p.title, companyName: p.company_name })),
  });
}));

export async function buildPortfolio(userId: string, publicView: boolean) {
  const u = await one(`SELECT u.id, u.name, u.login, u.student_code, u.year, u.portfolio_public_allowed, u.portfolio_public, u.public_slug, u.is_demo,
      s.name AS school_name, s.city, t.course FROM users u LEFT JOIN schools s ON s.id = u.school_id LEFT JOIN turmas t ON t.id = u.turma_id WHERE u.id = $1`, [userId]);
  const projects = await q(`SELECT p.id, p.concluded_at, d.title, d.techs, d.hours, d.area, co.name AS company_name, s.name AS school_name, t.name AS turma_name,
      (SELECT count(*)::int FROM project_members x WHERE x.project_id = p.id) AS team_size
    FROM projects p JOIN project_members m ON m.project_id = p.id JOIN demands d ON d.id = p.demand_id JOIN companies co ON co.id = d.company_id
    JOIN schools s ON s.id = p.school_id JOIN turmas t ON t.id = p.turma_id
    WHERE m.student_id = $1 AND p.status = 'concluido' ORDER BY p.concluded_at DESC`, [userId]);
  const out: any[] = [];
  const comps = new Set<string>();
  for (const p of projects) {
    const sub = await one('SELECT title, description, link FROM submissions WHERE project_id = $1 ORDER BY version DESC LIMIT 1', [p.id]);
    const val = await one(`SELECT competencies, text FROM reviews WHERE project_id = $1 AND kind = 'validacao' ORDER BY created_at DESC LIMIT 1`, [p.id]);
    const ret = await one(`SELECT criteria, text FROM reviews WHERE project_id = $1 AND kind = 'retorno' ORDER BY created_at DESC LIMIT 1`, [p.id]);
    const cert = await one('SELECT code, created_at FROM certificates WHERE project_id = $1 AND student_id = $2', [p.id, userId]);
    (val?.competencies || []).forEach((c: string) => comps.add(c));
    out.push({
      title: sub?.title || p.title, demandTitle: p.title, description: sub?.description || '', link: publicView ? null : sub?.link || null,
      companyName: p.company_name, schoolName: p.school_name, techs: p.techs, hours: p.hours, area: p.area, teamSize: p.team_size, concludedAt: p.concluded_at,
      competencies: val?.competencies || [], teacherFeedback: val?.text || null, companyFeedback: ret?.text || null, companyCriteria: ret?.criteria || null,
      certificate: cert ? { code: cert.code, createdAt: cert.created_at } : null,
    });
  }
  return {
    name: publicView ? shortName(u.name) : u.name, login: publicView ? undefined : u.login, code: publicView ? undefined : u.student_code,
    schoolName: u.school_name, city: u.city, course: u.course, year: u.year, isDemo: u.is_demo,
    competencies: [...comps], techs: [...new Set(out.flatMap((p) => p.techs))], projects: out,
    publicAllowed: publicView ? undefined : u.portfolio_public_allowed, isPublic: publicView ? undefined : u.portfolio_public, publicSlug: publicView ? undefined : u.public_slug,
  };
}

export async function publicPortfolio(slug: string) {
  const u = await one(`SELECT id FROM users WHERE public_slug = $1 AND portfolio_public AND portfolio_public_allowed AND active AND role = 'student'`, [slug]);
  return u ? buildPortfolio(u.id, true) : null;
}

studentRouter.get('/portfolio', requireRole('student'), ah(async (req, res) => {
  res.json(await buildPortfolio(req.user!.id, req.query.view === 'public'));
}));

studentRouter.put('/portfolio', requireRole('student'), ah(async (req, res) => {
  const b = parse(z.object({ public: z.boolean() }), req.body);
  const u = await one('SELECT name, portfolio_public_allowed, public_slug FROM users WHERE id = $1', [req.user!.id]);
  if (b.public && !u.portfolio_public_allowed) throw forbidden('A escola ainda não autorizou a publicação do seu portfólio.');
  const slug = u.public_slug || slugify(shortName(u.name)) + '-' + randomCode(5).toLowerCase();
  await q('UPDATE users SET portfolio_public = $1, public_slug = $2 WHERE id = $3', [b.public, slug, req.user!.id]);
  await audit(req, b.public ? 'Ativou portfólio público' : 'Desativou portfólio público');
  res.json({ ok: true, publicSlug: slug });
}));

studentRouter.post('/opportunities/:id/interest', requireRole('student'), ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const o = await one(`SELECT id, status FROM opportunities WHERE id = $1`, [id]);
  if (!o || o.status !== 'publicada') throw notFound('Oportunidade não disponível.');
  const ex = await one('SELECT 1 FROM opportunity_interests WHERE opportunity_id = $1 AND student_id = $2', [id, req.user!.id]);
  if (ex) await q('DELETE FROM opportunity_interests WHERE opportunity_id = $1 AND student_id = $2', [id, req.user!.id]);
  else await q('INSERT INTO opportunity_interests (opportunity_id, student_id) VALUES ($1,$2)', [id, req.user!.id]);
  await audit(req, ex ? 'Retirou interesse em oportunidade' : 'Registrou interesse em oportunidade', { targetType: 'opportunity', targetId: id });
  res.json({ interested: !ex });
}));

/* ---------- direitos do titular (todos os perfis) ---------- */
meRouter.get('/export', requireAuth, ah(async (req, res) => {
  const id = req.user!.id;
  const data = {
    geradoEm: new Date().toISOString(),
    aviso: 'Cópia dos seus dados pessoais registrados no ConectaTec PI.',
    usuario: await one(`SELECT role, name, login, email, student_code, year, is_minor, consent_status, portfolio_public_allowed, portfolio_public, created_at, last_login_at FROM users WHERE id = $1`, [id]),
    projetos: await q(`SELECT d.title AS demanda, p.status, s.name AS escola FROM project_members m JOIN projects p ON p.id = m.project_id JOIN demands d ON d.id = p.demand_id JOIN schools s ON s.id = p.school_id WHERE m.student_id = $1`, [id]),
    entregas: await q('SELECT version, title, description, link, file_name, created_at FROM submissions WHERE submitted_by = $1', [id]),
    mensagens: await q('SELECT text, created_at FROM posts WHERE author_id = $1', [id]),
    certificados: await q('SELECT code, created_at FROM certificates WHERE student_id = $1', [id]),
    pedidos: await q('SELECT kind, text, status, response, created_at FROM correction_requests WHERE user_id = $1', [id]),
    acessos: await q('SELECT action, created_at FROM audit_log WHERE user_id = $1 ORDER BY created_at DESC LIMIT 200', [id]),
  };
  await audit(req, 'Exportou os próprios dados');
  res.setHeader('Content-Disposition', 'attachment; filename="meus-dados-conectatec.json"');
  res.json(data);
}));

meRouter.get('/requests', requireAuth, ah(async (req, res) => {
  const rows = await q('SELECT id, kind, text, status, response, created_at FROM correction_requests WHERE user_id = $1 ORDER BY created_at DESC', [req.user!.id]);
  res.json(rows.map((r) => ({ id: r.id, kind: r.kind, text: r.text, status: r.status, response: r.response, createdAt: r.created_at })));
}));

meRouter.post('/requests', requireAuth, ah(async (req, res) => {
  const b = parse(z.object({ kind: z.enum(['correcao', 'remocao', 'exclusao_conta'], { errorMap: () => ({ message: 'Escolha o tipo de pedido.' }) }), text: zText(10, 1000, 'Descrição') }), req.body);
  const u = req.user!;
  const open = (await one(`SELECT count(*)::int AS n FROM correction_requests WHERE user_id = $1 AND status = 'aberto'`, [u.id])).n;
  if (open >= 5) throw bad('Você já tem 5 pedidos em aberto. Aguarde a resposta.');
  // estudantes e professores: a escola responde; empresas, escolas e administradores: a administração da plataforma
  const schoolId = u.role === 'student' || u.role === 'teacher' ? u.school_id : null;
  await q('INSERT INTO correction_requests (user_id, school_id, kind, text) VALUES ($1,$2,$3,$4)', [u.id, schoolId, b.kind, b.text]);
  await audit(req, 'Enviou pedido de ' + { correcao: 'correção', remocao: 'remoção de informação', exclusao_conta: 'exclusão de conta' }[b.kind]);
  res.status(201).json({ ok: true, handledBy: schoolId ? 'escola' : 'administração' });
}));
