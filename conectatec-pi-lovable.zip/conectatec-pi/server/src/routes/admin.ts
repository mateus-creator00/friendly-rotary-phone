import { Router } from 'express';
import { z } from 'zod';
import { one, q, tx } from '../db.js';
import { requireRole, hashPassword } from '../auth.js';
import { DEMAND_COLS, mapDemand } from './demands.js';
import { ah, parse, bad, notFound, zText, zEmail, zUuid, audit, tempPassword, shortName } from '../util.js';

export const adminRouter = Router();
adminRouter.use(requireRole('admin'));

adminRouter.get('/dashboard', ah(async (_req, res) => {
  const k = await one(`SELECT
    (SELECT count(*)::int FROM schools WHERE status='aprovada') AS schools,
    (SELECT count(*)::int FROM companies WHERE status='aprovada') AS companies,
    (SELECT count(*)::int FROM users WHERE role='student' AND active) AS students,
    (SELECT count(*)::int FROM users WHERE role='teacher' AND active) AS teachers,
    (SELECT count(*)::int FROM demands WHERE status='disponivel') AS demands,
    (SELECT count(*)::int FROM projects WHERE status IN ('aprovado','em_andamento','entregue','validado')) AS active_projects,
    (SELECT count(*)::int FROM projects WHERE status='concluido') AS concluded,
    (SELECT count(*)::int FROM flags WHERE status='aberta') AS flags,
    (SELECT count(*)::int FROM correction_requests WHERE status='aberto' AND school_id IS NULL) AS requests`);
  const pendingSchools = await q(`SELECT id, name, city, status, created_at FROM schools WHERE status IN ('pendente','ajustes') ORDER BY created_at`);
  const pendingCompanies = await q(`SELECT id, name, city, sector, status, created_at FROM companies WHERE status IN ('pendente','ajustes') ORDER BY created_at`);
  const pendingDemands = await q(`SELECT d.id, d.title, d.created_at, co.name AS company_name FROM demands d JOIN companies co ON co.id = d.company_id WHERE d.status = 'pendente' ORDER BY d.created_at`);
  const pendingOpps = (await one(`SELECT count(*)::int AS n FROM opportunities WHERE status = 'pendente'`)).n;
  const byCity = await q(`SELECT s.city,
      count(DISTINCT s.id)::int AS schools,
      (SELECT count(*)::int FROM users u JOIN schools s2 ON s2.id = u.school_id WHERE s2.city = s.city AND u.role='student' AND u.active) AS students,
      (SELECT count(*)::int FROM projects p JOIN schools s2 ON s2.id = p.school_id WHERE s2.city = s.city AND p.status = 'concluido') AS concluded,
      (SELECT count(*)::int FROM projects p JOIN schools s2 ON s2.id = p.school_id WHERE s2.city = s.city AND p.status IN ('aprovado','em_andamento','entregue','validado')) AS active
    FROM schools s WHERE s.status = 'aprovada' GROUP BY s.city ORDER BY s.city`);
  const byArea = await q(`SELECT d.area, count(p.id)::int AS projects FROM demands d LEFT JOIN projects p ON p.demand_id = d.id AND p.status NOT IN ('nao_adequada','nao_autorizado') GROUP BY d.area ORDER BY d.area`);
  const activity = await q('SELECT user_label, role, action, detail, created_at FROM audit_log WHERE action NOT IN (\'Consultou projeto\') ORDER BY created_at DESC LIMIT 12');
  res.json({
    kpis: k, pendingSchools, pendingCompanies,
    pendingDemands: pendingDemands.map((d) => ({ id: d.id, title: d.title, createdAt: d.created_at, companyName: d.company_name })),
    pendingOpps, byCity, byArea,
    activity: activity.map((a) => ({ user: a.user_label, role: a.role, action: a.action, detail: a.detail, createdAt: a.created_at })),
  });
}));

const decision = <T extends [string, ...string[]]>(vals: T) => z.object({ status: z.enum(vals), note: z.string().trim().max(400).optional().default('') });

adminRouter.get('/schools', ah(async (_req, res) => {
  const rows = await q(`SELECT s.*, (SELECT json_agg(json_build_object('name', u.name, 'login', u.login)) FROM users u WHERE u.school_id = s.id AND u.role = 'school') AS managers,
      (SELECT count(*)::int FROM users u WHERE u.school_id = s.id AND u.role='student') AS students,
      (SELECT count(*)::int FROM turmas t WHERE t.school_id = s.id) AS turmas
    FROM schools s ORDER BY s.created_at DESC`);
  res.json(rows.map((s) => ({ id: s.id, name: s.name, city: s.city, inep: s.inep, status: s.status, note: s.note, isDemo: s.is_demo, createdAt: s.created_at, managers: s.managers || [], students: s.students, turmas: s.turmas })));
}));
adminRouter.post('/schools/:id/status', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(decision(['aprovada', 'ajustes', 'rejeitada']), req.body);
  if (b.status !== 'aprovada' && b.note.length < 5) throw bad('Escreva uma observação.', { note: 'Escreva uma observação (mínimo de 5 caracteres).' });
  const s = await one('UPDATE schools SET status = $1, note = $2 WHERE id = $3 RETURNING name', [b.status, b.status === 'aprovada' ? '' : b.note, id]);
  if (!s) throw notFound();
  await audit(req, `Escola ${b.status}`, { targetType: 'school', targetId: id, detail: s.name, schoolId: id });
  res.json({ ok: true });
}));

adminRouter.get('/companies', ah(async (_req, res) => {
  const rows = await q(`SELECT c.*, (SELECT login FROM users u WHERE u.company_id = c.id ORDER BY created_at LIMIT 1) AS email,
      (SELECT count(*)::int FROM demands d WHERE d.company_id = c.id) AS demands FROM companies c ORDER BY c.created_at DESC`);
  res.json(rows.map((c) => ({ id: c.id, name: c.name, cnpj: c.cnpj, sector: c.sector, city: c.city, description: c.description, responsibleName: c.responsible_name,
    email: c.email, status: c.status, note: c.note, isDemo: c.is_demo, createdAt: c.created_at, demands: c.demands })));
}));
adminRouter.post('/companies/:id/status', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(decision(['aprovada', 'ajustes', 'rejeitada']), req.body);
  if (b.status !== 'aprovada' && b.note.length < 5) throw bad('Escreva uma observação.', { note: 'Escreva uma observação (mínimo de 5 caracteres).' });
  const c = await one('UPDATE companies SET status = $1, note = $2 WHERE id = $3 RETURNING name', [b.status, b.status === 'aprovada' ? '' : b.note, id]);
  if (!c) throw notFound();
  await audit(req, `Empresa ${b.status}`, { targetType: 'company', targetId: id, detail: c.name });
  res.json({ ok: true });
}));

adminRouter.get('/demands', ah(async (_req, res) => {
  const rows = await q(`SELECT ${DEMAND_COLS} FROM demands d JOIN companies co ON co.id = d.company_id ORDER BY (d.status = 'pendente') DESC, d.created_at DESC`);
  res.json(rows.map(mapDemand));
}));
adminRouter.post('/demands/:id/moderation', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(decision(['disponivel', 'ajustes', 'rejeitada', 'encerrada']), req.body);
  if ((b.status === 'ajustes' || b.status === 'rejeitada') && b.note.length < 5) throw bad('Escreva uma observação.', { note: 'Explique à empresa o motivo (mínimo de 5 caracteres).' });
  const d = await one(`SELECT d.title, co.status AS company_status FROM demands d JOIN companies co ON co.id = d.company_id WHERE d.id = $1`, [id]);
  if (!d) throw notFound();
  if (b.status === 'disponivel' && d.company_status !== 'aprovada') throw bad('A empresa precisa estar verificada antes de a demanda ser encaminhada às escolas.');
  await q('UPDATE demands SET status = $1, mod_note = $2 WHERE id = $3', [b.status, b.status === 'disponivel' ? '' : b.note, id]);
  await audit(req, ({ disponivel: 'Encaminhou demanda às escolas', ajustes: 'Pediu ajustes/redimensionamento da demanda', rejeitada: 'Rejeitou demanda', encerrada: 'Encerrou demanda' } as Record<string, string>)[b.status], { targetType: 'demand', targetId: id, detail: d.title });
  res.json({ ok: true });
}));

adminRouter.post('/opportunities/:id/moderation', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(decision(['publicada', 'ajustes', 'rejeitada', 'encerrada']), req.body);
  if ((b.status === 'ajustes' || b.status === 'rejeitada') && b.note.length < 5) throw bad('Escreva uma observação.', { note: 'Escreva uma observação (mínimo de 5 caracteres).' });
  const o = await one('UPDATE opportunities SET status = $1, mod_note = $2 WHERE id = $3 RETURNING title', [b.status, b.note, id]);
  if (!o) throw notFound();
  await audit(req, `Vaga ${b.status}`, { targetType: 'opportunity', targetId: id, detail: o.title });
  res.json({ ok: true });
}));

adminRouter.get('/users', ah(async (_req, res) => {
  const rows = await q(`SELECT u.id, u.role, u.name, u.login, u.active, u.must_change_password, u.last_login_at, u.is_demo, s.name AS school_name, co.name AS company_name
    FROM users u LEFT JOIN schools s ON s.id = u.school_id LEFT JOIN companies co ON co.id = u.company_id ORDER BY u.role, u.name`);
  res.json(rows.map((u) => ({ id: u.id, role: u.role, name: u.role === 'student' ? shortName(u.name) : u.name, login: u.role === 'student' ? '—' : u.login, active: u.active,
    mustChangePassword: u.must_change_password, lastLoginAt: u.last_login_at, isDemo: u.is_demo, schoolName: u.school_name, companyName: u.company_name })));
}));
adminRouter.post('/users', ah(async (req, res) => {
  const b = parse(z.object({ name: zText(5, 80, 'Nome'), email: zEmail }), req.body);
  if (await one('SELECT 1 FROM users WHERE lower(login) = $1', [b.email])) throw bad('E-mail já cadastrado.', { email: 'Já existe uma conta com este e-mail.' });
  const pw = tempPassword();
  await q(`INSERT INTO users (role, name, login, email, password_hash, must_change_password, created_by) VALUES ('admin',$1,$2,$2,$3,true,$4)`, [b.name, b.email, await hashPassword(pw), req.user!.id]);
  await audit(req, 'Criou conta de administrador', { detail: b.name });
  res.status(201).json({ login: b.email, temporaryPassword: pw });
}));
adminRouter.put('/users/:id', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(z.object({ active: z.boolean() }), req.body);
  if (id === req.user!.id) throw bad('Você não pode desativar a própria conta.');
  const u = await one('UPDATE users SET active = $1 WHERE id = $2 RETURNING name, role', [b.active, id]);
  if (!u) throw notFound();
  if (!b.active) await q(`DELETE FROM "session" WHERE sess->>'userId' = $1`, [id]);
  await audit(req, b.active ? 'Reativou conta' : 'Desativou conta', { targetType: 'user', targetId: id, detail: `${u.role}` });
  res.json({ ok: true });
}));
adminRouter.post('/users/:id/reset-password', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const u = await one('SELECT login, role FROM users WHERE id = $1', [id]);
  if (!u) throw notFound();
  if (u.role === 'student') throw bad('Senhas de estudantes são redefinidas pela escola.');
  const pw = tempPassword();
  await q('UPDATE users SET password_hash = $1, must_change_password = true WHERE id = $2', [await hashPassword(pw), id]);
  await q(`DELETE FROM "session" WHERE sess->>'userId' = $1`, [id]);
  await audit(req, 'Gerou senha temporária', { targetType: 'user', targetId: id, detail: u.role });
  res.json({ login: u.login, temporaryPassword: pw });
}));
adminRouter.delete('/users/:id', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  if (id === req.user!.id) throw bad('Você não pode excluir a própria conta.');
  const u = await one('SELECT role FROM users WHERE id = $1', [id]);
  if (!u) throw notFound();
  await tx(async (c) => {
    await q(`DELETE FROM "session" WHERE sess->>'userId' = $1`, [id], c);
    await q('DELETE FROM users WHERE id = $1', [id], c);
    await audit(req, 'Excluiu conta (pedido de exclusão)', { detail: u.role }, c);
  });
  res.json({ ok: true });
}));

adminRouter.post('/courses', ah(async (req, res) => {
  const b = parse(z.object({ name: zText(3, 80, 'Nome do curso') }), req.body);
  if (await one('SELECT 1 FROM courses WHERE lower(name) = lower($1)', [b.name])) throw bad('Curso já existe.', { name: 'Este curso já existe.' });
  await q('INSERT INTO courses (name) VALUES ($1)', [b.name]);
  await audit(req, 'Cadastrou curso técnico', { detail: b.name });
  res.status(201).json({ ok: true });
}));

adminRouter.get('/audit', ah(async (req, res) => {
  const term = String(req.query.q || '').trim().slice(0, 80);
  const p: any[] = [];
  let where = `action <> 'Consultou projeto'`;
  if (req.query.all === '1') where = 'true';
  if (term) { p.push('%' + term + '%'); where += ` AND (action ILIKE $1 OR user_label ILIKE $1 OR detail ILIKE $1)`; }
  const rows = await q(`SELECT a.user_label, a.role, a.action, a.detail, a.ip, a.created_at, s.name AS school_name FROM audit_log a LEFT JOIN schools s ON s.id = a.school_id
    WHERE ${where} ORDER BY a.created_at DESC LIMIT 300`, p);
  res.json(rows.map((a) => ({ user: a.role === 'student' ? shortName(a.user_label) : a.user_label, role: a.role, action: a.action, detail: a.detail, ip: a.ip, createdAt: a.created_at, schoolName: a.school_name })));
}));

adminRouter.get('/flags', ah(async (_req, res) => {
  const rows = await q('SELECT f.*, s.name AS school_name FROM flags f LEFT JOIN schools s ON s.id = f.school_id ORDER BY f.created_at DESC LIMIT 300');
  res.json(rows.map((f) => ({ id: f.id, type: f.type, text: f.text, projectId: f.project_id, schoolName: f.school_name, status: f.status, createdAt: f.created_at })));
}));
adminRouter.post('/flags/:id/resolve', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  await q(`UPDATE flags SET status = 'resolvida' WHERE id = $1`, [id]);
  await audit(req, 'Resolveu sinalização', { targetType: 'flag', targetId: id });
  res.json({ ok: true });
}));

adminRouter.get('/requests', ah(async (_req, res) => {
  const rows = await q(`SELECT cr.id, cr.kind, cr.text, cr.status, cr.response, cr.created_at, u.name, u.role FROM correction_requests cr LEFT JOIN users u ON u.id = cr.user_id
    WHERE cr.school_id IS NULL ORDER BY (cr.status = 'aberto') DESC, cr.created_at DESC LIMIT 100`);
  res.json(rows.map((r) => ({ id: r.id, kind: r.kind, text: r.text, status: r.status, response: r.response, createdAt: r.created_at, name: r.name, role: r.role })));
}));
adminRouter.post('/requests/:id/resolve', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const b = parse(z.object({ response: zText(5, 600, 'Resposta') }), req.body);
  await q(`UPDATE correction_requests SET status = 'resolvido', response = $1 WHERE id = $2`, [b.response, id]);
  await audit(req, 'Respondeu pedido de correção/remoção', { targetType: 'correction', targetId: id });
  res.json({ ok: true });
}));
