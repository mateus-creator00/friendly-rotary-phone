import { Router } from 'express';
import { z } from 'zod';
import { one, q } from '../db.js';
import { requireRole } from '../auth.js';
import { COMPANY_VISIBLE } from '../access.js';
import { DEMAND_COLS, mapDemand } from './demands.js';
import { ah, parse, bad, forbidden, notFound, zText, zList, zUuid, zDate, audit, todayPlus } from '../util.js';

export const companyRouter = Router();
export const opportunitiesRouter = Router();

async function myCompany(req: any) {
  const c = await one('SELECT * FROM companies WHERE id = $1', [req.user.company_id]);
  if (!c) throw notFound('Empresa não encontrada.');
  return c;
}
function requireApproved(c: any) {
  if (c.status !== 'aprovada') throw forbidden('A empresa precisa estar verificada pela administração para esta ação.');
}

companyRouter.use(requireRole('company'));

companyRouter.get('/dashboard', ah(async (req, res) => {
  const c = await myCompany(req);
  const demands = await q(`SELECT ${DEMAND_COLS} FROM demands d JOIN companies co ON co.id = d.company_id WHERE d.company_id = $1 ORDER BY d.created_at DESC`, [c.id]);
  const projects = await q(`SELECT p.id, p.status, p.is_demo, p.started_at, d.title, s.name AS school_name, s.city AS school_city, t.course, t.year,
      (SELECT count(*)::int FROM project_members m WHERE m.project_id = p.id) AS team_size,
      (SELECT count(*)::int FROM milestones m WHERE m.project_id = p.id) AS ms_total,
      (SELECT count(*)::int FROM milestones m WHERE m.project_id = p.id AND m.done) AS ms_done
    FROM projects p JOIN demands d ON d.id = p.demand_id JOIN schools s ON s.id = p.school_id JOIN turmas t ON t.id = p.turma_id
    WHERE d.company_id = $1 AND p.status = ANY($2) ORDER BY p.created_at DESC`, [c.id, COMPANY_VISIBLE]);
  const analysing = (await one(`SELECT count(*)::int AS n FROM projects p JOIN demands d ON d.id = p.demand_id WHERE d.company_id = $1 AND p.status IN ('analise_pedagogica','aguardando_coordenacao')`, [c.id])).n;
  res.json({
    company: { id: c.id, name: c.name, sector: c.sector, city: c.city, description: c.description, status: c.status, note: c.note, cnpj: c.cnpj, responsibleName: c.responsible_name, isDemo: c.is_demo },
    demands: demands.map(mapDemand),
    projects: projects.map((p) => ({ id: p.id, status: p.status, isDemo: p.is_demo, startedAt: p.started_at, title: p.title, school: `${p.school_name} (${p.school_city})`,
      turma: `${p.year} — ${p.course}`, teamSize: p.team_size, milestonesTotal: p.ms_total, milestonesDone: p.ms_done })),
    analysing,
  });
}));

const demandSchema = z.object({
  title: zText(8, 100, 'Título'),
  need: zText(40, 1500, 'Necessidade'),
  objectives: zText(20, 800, 'Objetivos'),
  expectedResults: zText(20, 800, 'Resultados esperados'),
  techs: zList(10).refine((a) => a.length > 0, 'Informe ao menos uma tecnologia.'),
  area: zText(2, 80, 'Área técnica'),
  suggestedDeadline: zDate,
  hours: z.coerce.number().int().min(4, 'Use de 4 a 80 horas.').max(80, 'Projetos acima de 80 horas devem ser redimensionados ou contratados profissionalmente.'),
  maxProjects: z.coerce.number().int().min(1, 'Use de 1 a 5.').max(5, 'Use de 1 a 5.'),
  criteria: z.union([z.array(z.string()), z.string()]).transform((v) => (Array.isArray(v) ? v : v.split('\n')).map((s) => s.trim().slice(0, 80)).filter(Boolean))
    .refine((a) => a.length >= 2 && a.length <= 6, 'Liste de 2 a 6 critérios.').refine((a) => new Set(a).size === a.length, 'Os critérios não podem se repetir.'),
  scopeDeclared: z.literal(true, { errorMap: () => ({ message: 'Confirme que a demanda é de escopo limitado e não substitui trabalho remunerado.' }) }),
}).refine((v) => v.suggestedDeadline >= todayPlus(14), { path: ['suggestedDeadline'], message: 'O prazo sugerido precisa ser de pelo menos 14 dias, para a análise da escola.' });

companyRouter.post('/demands', ah(async (req, res) => {
  const c = await myCompany(req); requireApproved(c);
  const b = parse(demandSchema, req.body);
  if (!(await one('SELECT 1 FROM courses WHERE name = $1', [b.area]))) throw bad('Área inválida.', { area: 'Selecione uma área técnica da lista.' });
  const r = await one(`INSERT INTO demands (company_id, title, need, objectives, expected_results, techs, area, city, suggested_deadline, hours, max_projects, criteria, scope_declared)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,true) RETURNING id`,
    [c.id, b.title, b.need, b.objectives, b.expectedResults, b.techs, b.area, c.city, b.suggestedDeadline, b.hours, b.maxProjects, b.criteria]);
  await audit(req, 'Submeteu demanda para moderação', { targetType: 'demand', targetId: r.id, detail: b.title });
  res.status(201).json(r);
}));

companyRouter.put('/demands/:id', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const c = await myCompany(req); requireApproved(c);
  const d = await one('SELECT status FROM demands WHERE id = $1 AND company_id = $2', [id, c.id]);
  if (!d) throw notFound('Demanda não encontrada.');
  if (!['pendente', 'ajustes'].includes(d.status)) throw bad('Só é possível editar demandas em moderação ou com ajustes solicitados.');
  const b = parse(demandSchema, req.body);
  await q(`UPDATE demands SET title=$1, need=$2, objectives=$3, expected_results=$4, techs=$5, area=$6, suggested_deadline=$7, hours=$8, max_projects=$9, criteria=$10, status='pendente' WHERE id=$11`,
    [b.title, b.need, b.objectives, b.expectedResults, b.techs, b.area, b.suggestedDeadline, b.hours, b.maxProjects, b.criteria, id]);
  await audit(req, 'Reenviou demanda para moderação', { targetType: 'demand', targetId: id, detail: b.title });
  res.json({ ok: true });
}));

companyRouter.post('/demands/:id/close', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const c = await myCompany(req);
  const d = await one(`UPDATE demands SET status = 'encerrada' WHERE id = $1 AND company_id = $2 AND status = 'disponivel' RETURNING title`, [id, c.id]);
  if (!d) throw bad('Só demandas disponíveis podem ser encerradas.');
  await audit(req, 'Encerrou demanda para novas turmas', { targetType: 'demand', targetId: id, detail: d.title });
  res.json({ ok: true });
}));

companyRouter.put('/profile', ah(async (req, res) => {
  const c = await myCompany(req);
  const b = parse(z.object({
    name: zText(3, 80, 'Nome'), sector: zText(2, 60, 'Setor'), city: zText(2, 60, 'Município'),
    description: zText(40, 800, 'Descrição'), responsibleName: zText(5, 80, 'Responsável'),
  }), req.body);
  const resend = c.status === 'ajustes' || c.status === 'rejeitada';
  await q(`UPDATE companies SET name=$1, sector=$2, city=$3, description=$4, responsible_name=$5, status = CASE WHEN $6 THEN 'pendente' ELSE status END WHERE id=$7`,
    [b.name, b.sector, b.city, b.description, b.responsibleName, resend, c.id]);
  await audit(req, resend ? 'Atualizou e reenviou cadastro empresarial' : 'Atualizou cadastro empresarial', { targetType: 'company', targetId: c.id });
  res.json({ ok: true, resent: resend });
}));

companyRouter.post('/opportunities', ah(async (req, res) => {
  const c = await myCompany(req); requireApproved(c);
  const b = parse(z.object({
    title: zText(5, 90, 'Cargo'), area: zText(2, 50, 'Área'), city: zText(2, 60, 'Município'),
    requirements: zList(10).refine((a) => a.length > 0, 'Informe ao menos um requisito.'),
    description: zText(30, 1000, 'Descrição'), workload: zText(2, 60, 'Carga horária'),
    selectionInfo: zText(10, 400, 'Processo seletivo'),
  }), req.body);
  await q(`INSERT INTO opportunities (company_id, title, area, city, requirements, description, workload, selection_info) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [c.id, b.title, b.area, b.city, b.requirements, b.description, b.workload, b.selectionInfo]);
  await audit(req, 'Submeteu vaga para moderação', { detail: b.title });
  res.status(201).json({ ok: true });
}));

companyRouter.post('/opportunities/:id/close', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const c = await myCompany(req);
  const o = await one(`UPDATE opportunities SET status = 'encerrada' WHERE id = $1 AND company_id = $2 RETURNING id`, [id, c.id]);
  if (!o) throw notFound();
  res.json({ ok: true });
}));

/* ---------- banco de oportunidades (etapa futura, vagas reais verificadas) ---------- */
opportunitiesRouter.get('/', ah(async (req, res) => {
  const u = req.user;
  const p: any[] = [];
  let where = `o.status = 'publicada' AND co.status = 'aprovada'`;
  if (u?.role === 'company') { p.push(u.company_id); where = `(${where} OR o.company_id = $1)`; }
  if (u?.role === 'admin') where = 'true';
  let interestedCol = '';
  if (u?.role === 'student') { p.push(u.id); interestedCol = `, EXISTS (SELECT 1 FROM opportunity_interests oi WHERE oi.opportunity_id = o.id AND oi.student_id = $${p.length}) AS interested`; }
  const rows = await q(`SELECT o.*, co.name AS company_name,
      (SELECT count(*)::int FROM opportunity_interests oi WHERE oi.opportunity_id = o.id) AS interest_count ${interestedCol}
    FROM opportunities o JOIN companies co ON co.id = o.company_id WHERE ${where} ORDER BY o.created_at DESC`, p);
  res.json(rows.map((o) => {
    const mine = u?.role === 'company' && o.company_id === u.company_id;
    return {
      id: o.id, title: o.title, area: o.area, city: o.city, requirements: o.requirements, description: o.description, workload: o.workload,
      selectionInfo: o.selection_info, status: o.status, modNote: mine || u?.role === 'admin' ? o.mod_note : '', companyName: o.company_name, isDemo: o.is_demo,
      interested: !!o.interested, mine, interestCount: mine || u?.role === 'admin' ? o.interest_count : undefined,
    };
  }));
}));
