import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { one, q, tx, Client } from '../db.js';
import { requireAuth, requireRole } from '../auth.js';
import { loadProject, projectAccess, isStaff, canMural, members, studentLabel, isTeacherOfTurma } from '../access.js';
import { ah, parse, bad, forbidden, notFound, zText, zUuid, zDate, sanitizePost, audit, addFlag, randomCode, todayPlus, shortName } from '../util.js';

export const projectsRouter = Router();
export const submissionsRouter = Router();
export const postsRouter = Router();

const LEVELS = ['atendeu', 'parcial', 'em_desenvolvimento'] as const;
const ACTIVE = ['analise_pedagogica', 'aguardando_coordenacao', 'aprovado', 'em_andamento', 'entregue', 'validado'];

function detectType(buf: Buffer): { mime: string } | null {
  if (buf.length < 4) return null;
  if (buf.subarray(0, 4).toString('latin1') === '%PDF') return { mime: 'application/pdf' };
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return { mime: 'image/png' };
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg' };
  if (buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04) return { mime: 'application/zip' };
  return null;
}
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 10 } });

async function need(req: any, ...allowed: string[]) {
  const id = parse(zUuid, req.params.id);
  const p = await loadProject(id);
  if (!p) throw notFound('Projeto não encontrado.');
  const a = await projectAccess(req.user, p);
  if (!a) throw forbidden('Você não tem acesso a este projeto.');
  if (allowed.length && !allowed.includes(a)) throw forbidden();
  return { p, a };
}

export async function issueCertificates(projectId: string, c: Client) {
  const ms = await q('SELECT student_id FROM project_members WHERE project_id = $1', [projectId], c);
  for (const m of ms) {
    await q('INSERT INTO certificates (code, student_id, project_id) VALUES ($1,$2,$3) ON CONFLICT (student_id, project_id) DO NOTHING',
      ['CTPI-' + randomCode(10), m.student_id, projectId], c);
  }
}

/* ---------- iniciar análise (professor ou escola) ---------- */
projectsRouter.post('/', requireRole('teacher', 'school'), ah(async (req, res) => {
  const b = parse(z.object({ demandId: zUuid, turmaId: zUuid }), req.body);
  const u = req.user!;
  const t = await one('SELECT t.id, t.school_id, t.teacher_id, t.name, s.status AS school_status FROM turmas t JOIN schools s ON s.id = t.school_id WHERE t.id = $1', [b.turmaId]);
  if (!t) throw bad('Turma não encontrada.', { turmaId: 'Selecione uma turma.' });
  if (t.school_status !== 'aprovada') throw forbidden('A escola precisa estar aprovada pela administração.');
  if (u.role === 'teacher' && t.teacher_id !== u.id) throw forbidden('Esta turma não é sua.');
  if (u.role === 'school' && t.school_id !== u.school_id) throw forbidden('Esta turma não é da sua escola.');
  if (!t.teacher_id) throw bad('A turma precisa de um professor-orientador antes da análise.', { turmaId: 'Defina o professor-orientador desta turma.' });
  const d = await one(`SELECT id, title, status, max_projects FROM demands WHERE id = $1`, [b.demandId]);
  if (!d || d.status !== 'disponivel') throw bad('Esta demanda não está disponível para análise.');
  const p = await tx(async (c) => {
    const n = await one(`SELECT count(*)::int AS n FROM projects WHERE demand_id = $1 AND status = ANY($2)`, [d.id, [...ACTIVE, 'concluido']], c);
    if (n.n >= d.max_projects) throw bad('Esta demanda já atingiu o número de turmas que a empresa pode acompanhar.');
    if (await one('SELECT 1 FROM projects WHERE demand_id = $1 AND turma_id = $2', [d.id, t.id], c)) throw bad('Esta turma já tem um projeto com esta demanda.');
    const p = await one(`INSERT INTO projects (demand_id, school_id, turma_id, teacher_id) VALUES ($1,$2,$3,$4) RETURNING id`, [d.id, t.school_id, t.id, t.teacher_id], c);
    await audit(req, 'Iniciou análise pedagógica', { targetType: 'project', targetId: p.id, detail: `${d.title} — ${t.name}`, schoolId: t.school_id }, c);
    return p;
  });
  res.status(201).json(p);
}));

/* ---------- detalhe ---------- */
projectsRouter.get('/:id', requireAuth, ah(async (req, res) => {
  const { p, a } = await need(req);
  const u = req.user!;
  const showSubs = a !== 'turma' && (a !== 'company' || ['validado', 'concluido'].includes(p.status));
  const subs = showSubs ? await q(`SELECT s.id, s.version, s.title, s.description, s.link, s.file_name, s.file_size, s.file_type, s.created_at, us.name AS by_name
      FROM submissions s LEFT JOIN users us ON us.id = s.submitted_by WHERE s.project_id = $1 ORDER BY s.version DESC`, [p.id]) : [];
  const companyOnlyLatest = a === 'company';
  const reviews = await q(`SELECT r.id, r.submission_id, r.role, r.kind, r.criteria, r.competencies, r.text, r.created_at, us.name AS author_name
      FROM reviews r LEFT JOIN users us ON us.id = r.author_id WHERE r.project_id = $1 ORDER BY r.created_at DESC`, [p.id]);
  const milestones = await q('SELECT id, title, due_date, done FROM milestones WHERE project_id = $1 ORDER BY position, due_date', [p.id]);
  const team = await members(p.id, a, u.id);
  const teamCount = (await one('SELECT count(*)::int AS n FROM project_members WHERE project_id = $1', [p.id])).n;
  const interest = await one('SELECT message, created_at FROM company_interests WHERE project_id = $1', [p.id]);
  let turmaStudents: any[] | undefined;
  if (a === 'teacher' || a === 'school' || a === 'admin') {
    turmaStudents = (await q(`SELECT id, name, student_code, consent_status, is_minor FROM users WHERE turma_id = $1 AND role = 'student' AND active ORDER BY name`, [p.turma_id]))
      .map((s) => ({ id: s.id, name: s.name, code: s.student_code, consentStatus: s.consent_status, isMinor: s.is_minor }));
  }
  if (a === 'company' || a === 'admin') await audit(req, 'Consultou projeto', { targetType: 'project', targetId: p.id, schoolId: p.school_id }).catch(() => {});
  res.json({
    id: p.id, status: p.status, access: a, isDemo: p.is_demo, createdAt: p.created_at, startedAt: p.started_at, concludedAt: p.concluded_at,
    demand: { id: p.demand_id, title: p.title, need: p.need, objectives: p.objectives, expectedResults: p.expected_results, techs: p.techs, area: p.area,
      city: p.demand_city, suggestedDeadline: p.suggested_deadline, hours: p.hours, criteria: p.criteria, company: { id: p.company_id, name: p.company_name, sector: p.company_sector } },
    school: { id: p.school_id, name: p.school_name, city: p.school_city },
    turma: { id: p.turma_id, name: a === 'company' ? `${p.turma_year} — ${p.turma_course}` : p.turma_name, course: p.turma_course, year: p.turma_year },
    teacher: a === 'company' ? null : { id: p.teacher_id, name: p.teacher_name },
    pedagogical: a === 'company' || a === 'turma' || a === 'member' ? null : { relevance: p.ped_relevance, safety: p.ped_safety, feasibility: p.ped_feasibility, curriculum: p.ped_curriculum, at: p.ped_at },
    coordination: a === 'company' ? null : { note: p.coord_note, at: p.coord_at },
    team, teamCount, turmaStudents,
    milestones: milestones.map((m) => ({ id: m.id, title: m.title, dueDate: m.due_date, done: m.done })),
    submissions: (companyOnlyLatest ? subs.slice(0, 1) : subs).map((s) => ({ id: s.id, version: s.version, title: s.title, description: s.description, link: s.link,
      file: s.file_name ? { name: s.file_name, size: s.file_size, type: s.file_type } : null, createdAt: s.created_at,
      by: a === 'company' ? undefined : s.by_name ? studentLabel(a, s.by_name) : '' })),
    reviews: reviews.filter((r) => a !== 'company' || r.role === 'company').filter((r) => a !== 'turma')
      .map((r) => ({ id: r.id, submissionId: r.submission_id, role: r.role, kind: r.kind, criteria: r.criteria, competencies: r.competencies, text: r.text, createdAt: r.created_at,
        author: r.role === 'company' ? p.company_name : (r.author_name || 'Professor(a)') })),
    interest: interest && (a === 'company' || isStaff(a)) ? { message: interest.message, createdAt: interest.created_at } : null,
    canMural: canMural(a),
  });
}));

/* ---------- 1. análise pedagógica (professor) ---------- */
projectsRouter.post('/:id/pedagogical', requireRole('teacher'), ah(async (req, res) => {
  const { p } = await need(req, 'teacher');
  if (p.status !== 'analise_pedagogica') throw bad('Este projeto não está em análise pedagógica.');
  const b = parse(z.object({
    decision: z.enum(['favoravel', 'inadequada'], { errorMap: () => ({ message: 'Escolha o parecer.' }) }),
    relevance: zText(10, 1200, 'Relevância pedagógica'), safety: zText(10, 1200, 'Segurança'),
    feasibility: zText(10, 1200, 'Viabilidade'), curriculum: z.string().trim().max(400).optional().default(''),
  }), req.body);
  const next = b.decision === 'favoravel' ? 'aguardando_coordenacao' : 'nao_adequada';
  await q(`UPDATE projects SET status=$1, ped_relevance=$2, ped_safety=$3, ped_feasibility=$4, ped_curriculum=$5, ped_at=now() WHERE id=$6`,
    [next, b.relevance, b.safety, b.feasibility, b.curriculum, p.id]);
  await audit(req, b.decision === 'favoravel' ? 'Parecer pedagógico favorável' : 'Parecer: demanda inadequada', { targetType: 'project', targetId: p.id, schoolId: p.school_id });
  res.json({ ok: true, status: next });
}));

/* ---------- 2. autorização da coordenação (escola) ---------- */
projectsRouter.post('/:id/coordination', requireRole('school'), ah(async (req, res) => {
  const { p } = await need(req, 'school');
  if (p.status !== 'aguardando_coordenacao') throw bad('Este projeto não está aguardando autorização.');
  const b = parse(z.object({ decision: z.enum(['autorizar', 'devolver', 'negar']), note: z.string().trim().max(600).optional().default('') }), req.body);
  if (b.decision !== 'autorizar' && b.note.length < 5) throw bad('Explique o motivo.', { note: 'Escreva uma observação (mínimo de 5 caracteres).' });
  const next = { autorizar: 'aprovado', devolver: 'analise_pedagogica', negar: 'nao_autorizado' }[b.decision];
  await q('UPDATE projects SET status=$1, coord_note=$2, coord_by=$3, coord_at=now() WHERE id=$4', [next, b.note, req.user!.id, p.id]);
  await audit(req, { autorizar: 'Autorizou participação da turma', devolver: 'Devolveu para nova análise', negar: 'Não autorizou participação' }[b.decision], { targetType: 'project', targetId: p.id });
  res.json({ ok: true, status: next });
}));

/* ---------- 3. organização da equipe e cronograma (professor) ---------- */
projectsRouter.post('/:id/organize', requireRole('teacher'), ah(async (req, res) => {
  const { p } = await need(req, 'teacher');
  if (!['aprovado', 'em_andamento'].includes(p.status)) throw bad('A equipe só pode ser organizada depois da autorização da escola.');
  const b = parse(z.object({
    members: z.array(zUuid).min(2, 'Selecione pelo menos 2 estudantes.').max(10, 'Selecione no máximo 10 estudantes.'),
    milestones: z.array(z.object({ title: zText(3, 120, 'Etapa'), dueDate: zDate })).min(1, 'Inclua pelo menos uma etapa no cronograma.').max(12),
  }), req.body);
  const ids = [...new Set(b.members)];
  const studs = await q(`SELECT id, name, consent_status FROM users WHERE id = ANY($1) AND turma_id = $2 AND role = 'student' AND active`, [ids, p.turma_id]);
  if (studs.length !== ids.length) throw bad('Há estudantes que não são desta turma.', { members: 'Selecione apenas estudantes ativos desta turma.' });
  const pend = studs.filter((s) => s.consent_status === 'pendente');
  if (pend.length) throw bad('Autorização pendente.', { members: `A escola ainda não registrou a autorização de: ${pend.map((s) => s.name).join(', ')}.` });
  await tx(async (c) => {
    await q('DELETE FROM project_members WHERE project_id = $1', [p.id], c);
    for (const m of ids) await q('INSERT INTO project_members (project_id, student_id) VALUES ($1,$2)', [p.id, m], c);
    const old = await q('SELECT title, done FROM milestones WHERE project_id = $1', [p.id], c);
    await q('DELETE FROM milestones WHERE project_id = $1', [p.id], c);
    for (const [i, m] of b.milestones.entries()) {
      const wasDone = old.find((o) => o.title === m.title)?.done ?? false;
      await q('INSERT INTO milestones (project_id, title, due_date, position, done) VALUES ($1,$2,$3,$4,$5)', [p.id, m.title, m.dueDate, i, wasDone], c);
    }
    if (p.status === 'aprovado') await q(`UPDATE projects SET status='em_andamento', started_at=now() WHERE id=$1`, [p.id], c);
    await audit(req, p.status === 'aprovado' ? 'Organizou a equipe e iniciou o projeto' : 'Atualizou equipe/cronograma', { targetType: 'project', targetId: p.id, schoolId: p.school_id }, c);
  });
  res.json({ ok: true });
}));

projectsRouter.post('/:id/milestones/:mid', requireAuth, ah(async (req, res) => {
  const { p } = await need(req, 'teacher', 'member');
  const mid = parse(zUuid, req.params.mid);
  if (!['em_andamento', 'entregue'].includes(p.status)) throw bad('O cronograma só pode ser atualizado durante o desenvolvimento.');
  const m = await one('UPDATE milestones SET done = NOT done WHERE id = $1 AND project_id = $2 RETURNING done', [mid, p.id]);
  if (!m) throw notFound('Etapa não encontrada.');
  res.json({ done: m.done });
}));

/* ---------- 4. entregas (estudantes da equipe) ---------- */
projectsRouter.post('/:id/submissions', requireRole('student'), (req, res, next) => {
  upload.single('file')(req, res, (err: any) => {
    if (err?.code === 'LIMIT_FILE_SIZE') return next(bad('Arquivo muito grande.', { file: 'O limite é 5 MB.' }));
    if (err) return next(bad('Não foi possível receber o arquivo.', { file: 'Envie um único arquivo PDF, PNG, JPG ou ZIP.' }));
    next();
  });
}, ah(async (req, res) => {
  const { p } = await need(req, 'member');
  if (p.status !== 'em_andamento') throw bad('O projeto não está aberto para entregas agora.');
  const b = parse(z.object({
    title: zText(5, 100, 'Título'),
    description: zText(40, 2000, 'Descrição'),
    link: z.string().trim().max(400).refine((s) => { try { const u = new URL(s); return u.protocol === 'https:' || u.protocol === 'http:'; } catch { return false; } }, 'Informe um link válido começando com https://'),
    confirm: z.enum(['true', '1', 'on'], { errorMap: () => ({ message: 'Confirme a autoria e a ausência de dados pessoais.' }) }),
  }), req.body);
  let file: { name: string; data: Buffer; size: number; type: string } | null = null;
  const f = (req as any).file as Express.Multer.File | undefined;
  if (f) {
    const det = detectType(f.buffer);
    if (!det) throw bad('Tipo de arquivo não permitido.', { file: 'Use PDF, PNG, JPG ou ZIP.' });
    const safe = f.originalname.replace(/[^\w.\-À-ú ]+/g, '_').slice(0, 120) || 'anexo';
    file = { name: safe, data: f.buffer, size: f.size, type: det.mime };
  }
  const s = await tx(async (c) => {
    const v = await one('SELECT COALESCE(max(version),0)+1 AS v FROM submissions WHERE project_id = $1', [p.id], c);
    const s = await one(`INSERT INTO submissions (project_id, version, title, description, link, file_name, file_data, file_size, file_type, submitted_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id, version`,
      [p.id, v.v, b.title, b.description, b.link, file?.name ?? null, file?.data ?? null, file?.size ?? null, file?.type ?? null, req.user!.id], c);
    await q(`UPDATE projects SET status = 'entregue' WHERE id = $1`, [p.id], c);
    await audit(req, `Enviou entrega v${v.v}`, { targetType: 'project', targetId: p.id }, c);
    return s;
  });
  res.status(201).json(s);
}));

submissionsRouter.get('/:sid/file', requireAuth, ah(async (req, res) => {
  const sid = parse(zUuid, req.params.sid);
  const s = await one('SELECT project_id, file_name, file_type, (file_data IS NOT NULL) AS has FROM submissions WHERE id = $1', [sid]);
  if (!s || !s.has) throw notFound('Arquivo não encontrado.');
  const p = await loadProject(s.project_id);
  const a = await projectAccess(req.user, p);
  if (!a || a === 'turma' || (a === 'company' && !['validado', 'concluido'].includes(p.status))) throw forbidden('Você não tem acesso a este arquivo.');
  const row = await one('SELECT file_data FROM submissions WHERE id = $1', [sid]);
  await audit(req, 'Baixou anexo de entrega', { targetType: 'project', targetId: p.id, schoolId: p.school_id });
  res.setHeader('Content-Type', s.file_type);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'private, no-store');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(s.file_name)}`);
  res.end(row.file_data);
}));

/* ---------- 5. validação pedagógica (professor) ---------- */
const zCriteria = z.record(z.enum(LEVELS, { errorMap: () => ({ message: 'Nível inválido.' }) }));
projectsRouter.post('/:id/validation', requireRole('teacher'), ah(async (req, res) => {
  const { p } = await need(req, 'teacher');
  if (p.status !== 'entregue') throw bad('Não há entrega aguardando validação.');
  const b = parse(z.object({
    decision: z.enum(['validar', 'ajustes']),
    text: zText(20, 1500, 'Feedback'),
    competencies: z.array(z.string().trim().min(1).max(60)).max(15).optional().default([]),
  }), req.body);
  const sub = await one('SELECT id FROM submissions WHERE project_id = $1 ORDER BY version DESC LIMIT 1', [p.id]);
  await tx(async (c) => {
    await q(`INSERT INTO reviews (project_id, submission_id, author_id, role, kind, competencies, text) VALUES ($1,$2,$3,'teacher',$4,$5,$6)`,
      [p.id, sub?.id ?? null, req.user!.id, b.decision === 'validar' ? 'validacao' : 'ajustes', b.decision === 'validar' ? b.competencies : [], b.text], c);
    await q('UPDATE projects SET status = $1 WHERE id = $2', [b.decision === 'validar' ? 'validado' : 'em_andamento', p.id], c);
    await audit(req, b.decision === 'validar' ? 'Validou a entrega pedagógica' : 'Solicitou ajustes à equipe', { targetType: 'project', targetId: p.id, schoolId: p.school_id }, c);
  });
  res.json({ ok: true });
}));

/* ---------- 6. retorno da empresa ---------- */
projectsRouter.post('/:id/company-feedback', requireRole('company'), ah(async (req, res) => {
  const { p } = await need(req, 'company');
  if (p.status !== 'validado') throw bad('O professor ainda precisa validar a entrega antes do retorno da empresa.');
  const b = parse(z.object({
    criteria: zCriteria,
    text: zText(20, 1500, 'Feedback'),
    interest: z.boolean().optional().default(false),
    interestMessage: z.string().trim().max(600).optional().default(''),
  }), req.body);
  const missing = p.criteria.filter((c: string) => !(c in b.criteria));
  if (missing.length) throw bad('Avalie todos os critérios.', { criteria: `Faltam: ${missing.join(', ')}.` });
  if (b.interest && b.interestMessage.length < 10) throw bad('Descreva o interesse.', { interestMessage: 'Explique à escola o tipo de oportunidade futura (mínimo de 10 caracteres).' });
  const crit: Record<string, string> = {}; for (const c of p.criteria) crit[c] = b.criteria[c];
  await tx(async (c) => {
    await q(`INSERT INTO reviews (project_id, author_id, role, kind, criteria, text) VALUES ($1,$2,'company','retorno',$3,$4)`, [p.id, req.user!.id, JSON.stringify(crit), b.text], c);
    await q(`UPDATE projects SET status = 'concluido', concluded_at = now() WHERE id = $1`, [p.id], c);
    await issueCertificates(p.id, c);
    if (b.interest) await q(`INSERT INTO company_interests (project_id, company_id, message) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`, [p.id, p.company_id, b.interestMessage], c);
    await audit(req, 'Registrou retorno da empresa e concluiu o projeto', { targetType: 'project', targetId: p.id, schoolId: p.school_id }, c);
  });
  res.json({ ok: true });
}));

/** Conclusão sem retorno da empresa (prazo vencido ou empresa sem resposta). */
projectsRouter.post('/:id/conclude', requireRole('teacher'), ah(async (req, res) => {
  const { p } = await need(req, 'teacher');
  if (p.status !== 'validado') throw bad('Só é possível concluir depois da validação pedagógica.');
  await tx(async (c) => {
    await q(`UPDATE projects SET status = 'concluido', concluded_at = now() WHERE id = $1`, [p.id], c);
    await issueCertificates(p.id, c);
    await audit(req, 'Concluiu o projeto sem retorno da empresa', { targetType: 'project', targetId: p.id, schoolId: p.school_id }, c);
  });
  res.json({ ok: true });
}));

/* ---------- mural do projeto (acessível ao professor) ---------- */
projectsRouter.get('/:id/posts', requireAuth, ah(async (req, res) => {
  const { p, a } = await need(req);
  if (!canMural(a)) throw forbidden('O mural é restrito à equipe, ao professor, à escola e à empresa responsável.');
  const rows = await q(`SELECT po.id, po.text, po.masked, po.hidden, po.created_at, u.name, u.role FROM posts po LEFT JOIN users u ON u.id = po.author_id
    WHERE po.project_id = $1 ORDER BY po.created_at`, [p.id]);
  const mod = isStaff(a);
  res.json({
    canModerate: mod,
    posts: rows.filter((r) => mod || !r.hidden).map((r) => ({
      id: r.id, text: r.hidden && !mod ? '' : r.text, masked: r.masked, hidden: r.hidden, createdAt: r.created_at, role: r.role || 'student',
      author: r.role === 'company' ? p.company_name : r.role === 'student' ? studentLabel(a, r.name || 'Estudante') : (r.name || 'Usuário removido'),
    })),
  });
}));
projectsRouter.post('/:id/posts', requireAuth, ah(async (req, res) => {
  const { p, a } = await need(req);
  if (!canMural(a)) throw forbidden('Você não pode escrever neste mural.');
  if (p.status === 'concluido' && a !== 'teacher' && a !== 'school') throw bad('O projeto foi concluído. O mural está fechado.');
  const b = parse(z.object({ text: zText(3, 800, 'Mensagem') }), req.body);
  const s = sanitizePost(b.text);
  await tx(async (c) => {
    await q('INSERT INTO posts (project_id, author_id, text, masked) VALUES ($1,$2,$3,$4)', [p.id, req.user!.id, s.text, s.masked], c);
    if (s.flagged) await addFlag('Possível contato pessoal no mural', `Mensagem de ${req.user!.role === 'student' ? shortName(req.user!.name) : req.user!.name} no projeto "${p.title}" continha contato pessoal ou pedido de conversa fora da plataforma.${s.masked ? ' O contato foi ocultado.' : ''}`, p.id, p.school_id, c);
  });
  res.status(201).json({ ok: true, masked: s.masked, flagged: s.flagged });
}));
postsRouter.post('/:pid/hide', requireAuth, ah(async (req, res) => {
  const pid = parse(zUuid, req.params.pid);
  const post = await one('SELECT id, project_id, hidden FROM posts WHERE id = $1', [pid]);
  if (!post) throw notFound('Mensagem não encontrada.');
  const p = await loadProject(post.project_id);
  const a = await projectAccess(req.user, p);
  if (!isStaff(a)) throw forbidden('Apenas professor, escola ou administração moderam o mural.');
  await q('UPDATE posts SET hidden = NOT hidden, hidden_by = $1 WHERE id = $2', [req.user!.id, pid]);
  await audit(req, post.hidden ? 'Reexibiu mensagem do mural' : 'Ocultou mensagem do mural', { targetType: 'project', targetId: p.id, schoolId: p.school_id });
  res.json({ hidden: !post.hidden });
}));

export { isTeacherOfTurma, todayPlus };
