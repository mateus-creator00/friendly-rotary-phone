import { Router } from 'express';
import { z } from 'zod';
import { one, q } from '../db.js';
import { COMPANY_VISIBLE } from '../access.js';
import { ah, parse, bad, notFound, zUuid } from '../util.js';

export const demandsRouter = Router();

export const ACTIVE = ['analise_pedagogica', 'aguardando_coordenacao', 'aprovado', 'em_andamento', 'entregue', 'validado'];

export const DEMAND_COLS = `d.id, d.company_id, d.title, d.need, d.objectives, d.expected_results, d.techs, d.area, d.city, d.suggested_deadline,
  d.hours, d.criteria, d.max_projects, d.status, d.mod_note, d.is_demo, d.created_at, d.scope_declared,
  co.name AS company_name, co.sector AS company_sector, co.status AS company_status,
  (SELECT count(*)::int FROM projects p WHERE p.demand_id = d.id AND p.status = ANY('{${ACTIVE.join(',')}}')) AS active_count,
  (SELECT count(*)::int FROM projects p WHERE p.demand_id = d.id AND p.status = 'concluido') AS concluded_count`;

export function mapDemand(r: any) {
  const used = r.active_count + r.concluded_count;
  const phase = r.status !== 'disponivel' ? r.status : r.active_count > 0 ? 'em_projeto' : r.concluded_count > 0 && used >= r.max_projects ? 'concluida' : 'disponivel';
  return {
    id: r.id, title: r.title, need: r.need, objectives: r.objectives, expectedResults: r.expected_results, techs: r.techs, area: r.area, city: r.city,
    suggestedDeadline: r.suggested_deadline, hours: r.hours, criteria: r.criteria, maxProjects: r.max_projects, status: r.status, modNote: r.mod_note,
    isDemo: r.is_demo, createdAt: r.created_at, scopeDeclared: r.scope_declared,
    company: { id: r.company_id, name: r.company_name, sector: r.company_sector, status: r.company_status },
    activeCount: r.active_count, concludedCount: r.concluded_count, slotsLeft: Math.max(0, r.max_projects - used), phase,
  };
}

demandsRouter.get('/', ah(async (_req, res) => {
  const rows = await q(`SELECT ${DEMAND_COLS} FROM demands d JOIN companies co ON co.id = d.company_id
    WHERE d.status = 'disponivel' AND co.status = 'aprovada' ORDER BY d.created_at DESC`);
  res.json(rows.map(mapDemand));
}));

demandsRouter.get('/:id', ah(async (req, res) => {
  const id = parse(zUuid, req.params.id);
  const r = await one(`SELECT ${DEMAND_COLS} FROM demands d JOIN companies co ON co.id = d.company_id WHERE d.id = $1`, [id]);
  if (!r) throw notFound('Demanda não encontrada.');
  const u = req.user;
  const owner = u?.role === 'company' && u.company_id === r.company_id;
  let related = false;
  if (u && (u.role === 'school' || u.role === 'teacher')) {
    related = !!(await one(`SELECT 1 FROM projects p JOIN turmas t ON t.id = p.turma_id WHERE p.demand_id = $1 AND (p.school_id = $2 OR t.teacher_id = $3)`, [id, u.school_id, u.id]));
  }
  const visible = (r.status === 'disponivel' && r.company_status === 'aprovada') || owner || u?.role === 'admin' || related;
  if (!visible) throw notFound('Esta demanda não está disponível.');
  const d: any = mapDemand(r);

  let projSql = `SELECT p.id, p.status, p.is_demo, s.name AS school_name, s.city AS school_city, t.name AS turma_name, t.course, t.year
    FROM projects p JOIN schools s ON s.id = p.school_id JOIN turmas t ON t.id = p.turma_id WHERE p.demand_id = $1`;
  const pp: any[] = [id];
  if (!u) projSql += ' AND false';
  else if (u.role === 'company') { if (!owner) projSql += ' AND false'; else { projSql += ' AND p.status = ANY($2)'; pp.push(COMPANY_VISIBLE); } }
  else if (u.role === 'school') { projSql += ' AND p.school_id = $2'; pp.push(u.school_id); }
  else if (u.role === 'teacher') { projSql += ' AND t.teacher_id = $2'; pp.push(u.id); }
  else if (u.role === 'student') projSql += ' AND false';
  const projects = await q(projSql + ' ORDER BY p.created_at', pp);
  d.projects = projects.map((p) => ({ id: p.id, status: p.status, isDemo: p.is_demo, school: `${p.school_name} (${p.school_city})`,
    turma: u?.role === 'company' ? `${p.year} — ${p.course}` : p.turma_name }));
  if (owner) d.inAnalysis = (await one(`SELECT count(*)::int AS n FROM projects WHERE demand_id = $1 AND status IN ('analise_pedagogica','aguardando_coordenacao')`, [id])).n;

  if (u?.role === 'teacher' || u?.role === 'school') {
    const ts = u.role === 'teacher'
      ? await q(`SELECT t.id, t.name, t.teacher_id, s.status AS school_status FROM turmas t JOIN schools s ON s.id = t.school_id WHERE t.teacher_id = $1 ORDER BY t.name`, [u.id])
      : await q(`SELECT t.id, t.name, t.teacher_id, s.status AS school_status FROM turmas t JOIN schools s ON s.id = t.school_id WHERE t.school_id = $1 ORDER BY t.name`, [u.school_id]);
    const existing = await q('SELECT turma_id, id, status FROM projects WHERE demand_id = $1', [id]);
    d.myTurmas = ts.map((t) => {
      const ex = existing.find((e) => e.turma_id === t.id);
      return { id: t.id, name: t.name, hasTeacher: !!t.teacher_id, schoolApproved: t.school_status === 'aprovada', projectId: ex?.id ?? null, projectStatus: ex?.status ?? null };
    });
  }
  res.json(d);
}));

export { bad, z };
