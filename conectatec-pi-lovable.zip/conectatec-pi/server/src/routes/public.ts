import { Router } from 'express';
import { one, q } from '../db.js';
import { ah, notFound, shortName } from '../util.js';
import { publicPortfolio } from './student.js';

export const publicRouter = Router();

publicRouter.get('/courses', ah(async (_req, res) => {
  res.json(await q('SELECT id, name FROM courses ORDER BY name'));
}));

publicRouter.get('/stats', ah(async (_req, res) => {
  res.json(await one(`SELECT
    (SELECT count(*)::int FROM schools WHERE status='aprovada') AS schools,
    (SELECT count(*)::int FROM companies WHERE status='aprovada') AS companies,
    (SELECT count(*)::int FROM demands WHERE status='disponivel') AS demands,
    (SELECT count(*)::int FROM projects WHERE status='concluido') AS concluded`));
}));

publicRouter.get('/certificates/:code', ah(async (req, res) => {
  const code = String(req.params.code || '').toUpperCase().slice(0, 30);
  const r = await one(`SELECT ce.code, ce.created_at, u.name, u.is_demo, d.title, d.hours, d.techs, co.name AS company_name, s.name AS school_name, t.course,
      (SELECT competencies FROM reviews r WHERE r.project_id = ce.project_id AND r.kind = 'validacao' ORDER BY r.created_at DESC LIMIT 1) AS competencies
    FROM certificates ce JOIN users u ON u.id = ce.student_id JOIN projects p ON p.id = ce.project_id JOIN demands d ON d.id = p.demand_id
    JOIN companies co ON co.id = d.company_id JOIN schools s ON s.id = p.school_id JOIN turmas t ON t.id = p.turma_id WHERE ce.code = $1`, [code]);
  if (!r) throw notFound('Certificado não encontrado. Confira o código.');
  res.json({ code: r.code, createdAt: r.created_at, studentName: shortName(r.name), course: r.course, projectTitle: r.title, hours: r.hours, techs: r.techs,
    competencies: r.competencies || [], companyName: r.company_name, schoolName: r.school_name, isDemo: r.is_demo });
}));

publicRouter.get('/portfolio/:slug', ah(async (req, res) => {
  const p = await publicPortfolio(String(req.params.slug).slice(0, 80));
  if (!p) throw notFound('Portfólio não encontrado ou não autorizado para publicação.');
  res.json(p);
}));
