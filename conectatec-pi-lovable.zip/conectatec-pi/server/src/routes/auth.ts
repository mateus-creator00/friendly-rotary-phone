import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { one, q, tx } from '../db.js';
import { hashPassword, checkPassword, publicUser, regenerate, USER_COLS } from '../auth.js';
import { ah, parse, bad, zText, zEmail, zPassword, audit, HttpError } from '../util.js';

export const authRouter = Router();

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Muitas tentativas. Aguarde 15 minutos e tente novamente.' } });
const registerLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Muitos cadastros a partir desta conexão. Tente mais tarde.' } });

let dummy: Promise<string> | null = null;
const dummyHash = () => (dummy ??= hashPassword('senha-inexistente-123'));

export async function sessionPayload(u: any) {
  const company = u.company_id ? await one('SELECT id, name, sector, city, status, note FROM companies WHERE id = $1', [u.company_id]) : null;
  const school = u.school_id ? await one('SELECT id, name, city, status, note FROM schools WHERE id = $1', [u.school_id]) : null;
  const turma = u.turma_id ? await one('SELECT id, name, course, year FROM turmas WHERE id = $1', [u.turma_id]) : null;
  return { user: publicUser(u), company, school, turma };
}

authRouter.get('/me', ah(async (req, res) => {
  if (!req.user) return res.json({ user: null });
  res.json(await sessionPayload(req.user));
}));

authRouter.post('/login', loginLimiter, ah(async (req, res) => {
  const b = parse(z.object({ login: z.string().trim().toLowerCase().min(1, 'Informe o e-mail ou usuário.').max(160), password: z.string().min(1, 'Informe a senha.') }), req.body);
  const u = await one(`SELECT ${USER_COLS}, password_hash FROM users WHERE lower(login) = $1`, [b.login]);
  const ok = await checkPassword(b.password, u?.password_hash || (await dummyHash()));
  if (!u || !ok) {
    await audit(req, 'Tentativa de acesso recusada', { detail: b.login, user: { id: '', name: b.login, role: '' } as any }).catch(() => {});
    throw new HttpError(401, 'Usuário ou senha incorretos.');
  }
  if (!u.active) throw new HttpError(403, 'Esta conta está desativada. Procure a escola ou a administração.');
  await regenerate(req);
  req.session.userId = u.id;
  await q('UPDATE users SET last_login_at = now() WHERE id = $1', [u.id]);
  await audit(req, 'Entrou na plataforma', { user: u });
  res.json(await sessionPayload(u));
}));

authRouter.post('/logout', ah(async (req, res) => {
  if (req.user) await audit(req, 'Saiu da plataforma').catch(() => {});
  await new Promise<void>((resolve) => req.session.destroy(() => resolve()));
  res.clearCookie('ctpi.sid');
  res.json({ ok: true });
}));

authRouter.post('/change-password', ah(async (req, res) => {
  if (!req.user) throw new HttpError(401, 'Entre na plataforma para continuar.');
  const b = parse(z.object({ current: z.string().min(1, 'Informe a senha atual.'), newPassword: zPassword }), req.body);
  const u = await one('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
  if (!(await checkPassword(b.current, u.password_hash))) throw bad('Senha atual incorreta.', { current: 'Senha atual incorreta.' });
  if (b.current === b.newPassword) throw bad('A nova senha precisa ser diferente.', { newPassword: 'A nova senha precisa ser diferente da atual.' });
  await q('UPDATE users SET password_hash = $1, must_change_password = false WHERE id = $2', [await hashPassword(b.newPassword), req.user.id]);
  await q(`DELETE FROM "session" WHERE sess->>'userId' = $1 AND sid <> $2`, [req.user.id, req.sessionID]);
  await audit(req, 'Alterou a própria senha');
  res.json({ ok: true });
}));

/* Estudantes NÃO se cadastram sozinhos: contas são criadas pela escola. */

authRouter.post('/register/company', registerLimiter, ah(async (req, res) => {
  const b = parse(z.object({
    name: zText(3, 80, 'Nome da empresa'),
    cnpj: z.string().trim().max(20).optional().default('').refine((s) => !s || /^\d{14}$/.test(s.replace(/\D/g, '')), 'CNPJ deve ter 14 dígitos.'),
    sector: zText(2, 60, 'Setor'), city: zText(2, 60, 'Município'),
    description: zText(40, 800, 'Descrição'), responsibleName: zText(5, 80, 'Responsável'),
    email: zEmail, password: zPassword,
    terms: z.literal(true, { errorMap: () => ({ message: 'É preciso aceitar os compromissos com a escola e os estudantes.' }) }),
  }), req.body);
  if (await one('SELECT 1 FROM users WHERE lower(login) = $1', [b.email])) throw bad('E-mail já cadastrado.', { email: 'Já existe uma conta com este e-mail.' });
  const hash = await hashPassword(b.password);
  const user = await tx(async (c) => {
    const co = await one('INSERT INTO companies (name, cnpj, sector, city, description, responsible_name) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
      [b.name, b.cnpj.replace(/\D/g, '') || null, b.sector, b.city, b.description, b.responsibleName], c);
    const u = await one(`INSERT INTO users (role, name, login, email, password_hash, company_id) VALUES ('company',$1,$2,$2,$3,$4) RETURNING ${USER_COLS}`,
      [b.responsibleName, b.email, hash, co.id], c);
    await audit(req, 'Empresa solicitou verificação', { targetType: 'company', targetId: co.id, detail: b.name, user: u }, c);
    return u;
  });
  await regenerate(req); req.session.userId = user.id;
  res.status(201).json(await sessionPayload(user));
}));

authRouter.post('/register/school', registerLimiter, ah(async (req, res) => {
  const b = parse(z.object({
    schoolName: zText(5, 120, 'Nome da escola'), city: zText(2, 60, 'Município'),
    inep: z.string().trim().max(12).optional().default('').refine((s) => !s || /^\d{8}$/.test(s), 'O código INEP tem 8 dígitos.'),
    name: zText(5, 80, 'Nome do responsável'), role: zText(3, 80, 'Cargo'),
    email: zEmail, password: zPassword,
    terms: z.literal(true, { errorMap: () => ({ message: 'Confirme que você está autorizado(a) pela direção da escola.' }) }),
  }), req.body);
  if (await one('SELECT 1 FROM users WHERE lower(login) = $1', [b.email])) throw bad('E-mail já cadastrado.', { email: 'Já existe uma conta com este e-mail.' });
  const hash = await hashPassword(b.password);
  const user = await tx(async (c) => {
    const s = await one('INSERT INTO schools (name, city, inep) VALUES ($1,$2,$3) RETURNING id', [b.schoolName, b.city, b.inep || null], c);
    const u = await one(`INSERT INTO users (role, name, login, email, password_hash, school_id) VALUES ('school',$1,$2,$2,$3,$4) RETURNING ${USER_COLS}`,
      [b.name, b.email, hash, s.id], c);
    await audit(req, 'Escola solicitou acesso institucional', { targetType: 'school', targetId: s.id, detail: `${b.schoolName} — ${b.name} (${b.role})`, user: u, schoolId: s.id }, c);
    return u;
  });
  await regenerate(req); req.session.userId = user.id;
  res.status(201).json(await sessionPayload(user));
}));
