import bcrypt from 'bcryptjs';
import session from 'express-session';
import pgSession from 'connect-pg-simple';
import type { Request, Response, NextFunction, RequestHandler } from 'express';
import { pool, one } from './db.js';
import { HttpError } from './util.js';

export type Role = 'admin' | 'school' | 'teacher' | 'student' | 'company';
export interface SessionUser {
  id: string; role: Role; name: string; login: string; email: string | null; active: boolean; must_change_password: boolean;
  school_id: string | null; turma_id: string | null; company_id: string | null; consent_status: string; is_minor: boolean; is_demo: boolean;
  year: string | null; student_code: string | null;
}

declare module 'express-session' {
  interface SessionData { userId?: string }
}
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express { interface Request { user?: SessionUser } }
}

export const hashPassword = (pw: string, cost = 12) => bcrypt.hash(pw, cost);
export const checkPassword = (pw: string, hash: string) => bcrypt.compare(pw, hash);

export function sessionMiddleware(): RequestHandler {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 32) {
    if (process.env.NODE_ENV === 'production') throw new Error('Defina SESSION_SECRET com pelo menos 32 caracteres.');
    console.warn('[aviso] SESSION_SECRET ausente ou curto. Use um valor forte em produção.');
  }
  const Store = pgSession(session);
  return session({
    store: new Store({ pool, tableName: 'session', pruneSessionInterval: 60 * 30 }),
    name: 'ctpi.sid',
    secret: secret || 'dev-only-secret-change-me-dev-only-secret',
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production' && process.env.COOKIE_SECURE !== 'false',
      maxAge: 1000 * 60 * 60 * 8, // 8 horas
    },
  });
}

export const USER_COLS = 'id, role, name, login, email, active, must_change_password, school_id, turma_id, company_id, consent_status, is_minor, is_demo, year, student_code';

export async function loadUser(req: Request, _res: Response, next: NextFunction) {
  try {
    if (req.session?.userId) {
      const u = await one<SessionUser>(`SELECT ${USER_COLS} FROM users WHERE id = $1`, [req.session.userId]);
      if (u && u.active) req.user = u;
      else req.session.userId = undefined;
    }
    next();
  } catch (e) { next(e); }
}

export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) return next(new HttpError(401, 'Entre na plataforma para continuar.'));
  if (req.user.must_change_password) return next(new HttpError(403, 'Troque sua senha temporária antes de continuar.'));
  next();
}

export const requireRole = (...roles: Role[]) => (req: Request, _res: Response, next: NextFunction) => {
  if (!req.user) return next(new HttpError(401, 'Entre na plataforma para continuar.'));
  if (!roles.includes(req.user.role)) return next(new HttpError(403, 'Seu perfil não tem acesso a esta área.'));
  if (req.user.must_change_password) return next(new HttpError(403, 'Troque sua senha temporária antes de continuar.'));
  next();
};

/** Proteção contra CSRF: ações que alteram dados exigem este cabeçalho (formulários de outros sites não o enviam). */
export function csrfGuard(req: Request, _res: Response, next: NextFunction) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('X-Requested-With') !== 'conectatec') return next(new HttpError(403, 'Requisição bloqueada por segurança.'));
  next();
}

export function publicUser(u: SessionUser) {
  return {
    id: u.id, role: u.role, name: u.name, login: u.login, email: u.email, mustChangePassword: u.must_change_password,
    schoolId: u.school_id, turmaId: u.turma_id, companyId: u.company_id, consentStatus: u.consent_status, isMinor: u.is_minor,
    isDemo: u.is_demo, year: u.year, studentCode: u.student_code,
  };
}

export function regenerate(req: Request) {
  return new Promise<void>((resolve, reject) => req.session.regenerate((e) => (e ? reject(e) : resolve())));
}
