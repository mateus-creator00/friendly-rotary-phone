-- Novo curso técnico: Marketing Digital
INSERT INTO courses (name) SELECT 'Marketing Digital' WHERE NOT EXISTS (SELECT 1 FROM courses WHERE lower(name) = lower('Marketing Digital'));
