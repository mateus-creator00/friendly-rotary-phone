-- ConectaTec PI — esquema (versão escola no centro)
-- Fluxo: empresa verificada → demanda moderada → análise pedagógica do professor →
--        autorização da escola → organização da equipe → entregas → validação → retorno da empresa.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE schools (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  city text NOT NULL,
  inep text,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','ajustes','aprovada','rejeitada')),
  note text NOT NULL DEFAULT '',
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  cnpj text,
  sector text NOT NULL,
  city text NOT NULL,
  description text NOT NULL,
  responsible_name text NOT NULL,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','ajustes','aprovada','rejeitada')),
  note text NOT NULL DEFAULT '',
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text NOT NULL CHECK (role IN ('admin','school','teacher','student','company')),
  name text NOT NULL,
  login text NOT NULL,                 -- e-mail (escola, professor, empresa) ou usuário institucional (estudante)
  email text,
  password_hash text NOT NULL,
  must_change_password boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  school_id uuid REFERENCES schools(id) ON DELETE CASCADE,
  company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
  turma_id uuid,
  student_code text,                   -- identificação interna (ex.: matrícula)
  year text,
  is_minor boolean NOT NULL DEFAULT false,
  consent_status text NOT NULL DEFAULT 'nao_aplica' CHECK (consent_status IN ('pendente','registrado','nao_aplica')),
  portfolio_public_allowed boolean NOT NULL DEFAULT false,  -- autorização institucional
  portfolio_public boolean NOT NULL DEFAULT false,          -- escolha do estudante
  public_slug text UNIQUE,
  is_demo boolean NOT NULL DEFAULT false,
  created_by uuid,
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_login_lower ON users (lower(login));

CREATE TABLE turmas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name text NOT NULL,
  course text NOT NULL,
  year text NOT NULL,
  teacher_id uuid REFERENCES users(id) ON DELETE SET NULL,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE users ADD CONSTRAINT users_turma_fk FOREIGN KEY (turma_id) REFERENCES turmas(id) ON DELETE SET NULL;

CREATE TABLE demands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  title text NOT NULL,
  need text NOT NULL,
  objectives text NOT NULL,
  expected_results text NOT NULL,
  techs text[] NOT NULL DEFAULT '{}',
  area text NOT NULL,
  city text NOT NULL,
  suggested_deadline date NOT NULL,
  hours int NOT NULL CHECK (hours BETWEEN 4 AND 80),
  criteria text[] NOT NULL,
  max_projects int NOT NULL DEFAULT 1 CHECK (max_projects BETWEEN 1 AND 5),
  scope_declared boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','ajustes','rejeitada','disponivel','encerrada')),
  mod_note text NOT NULL DEFAULT '',
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_id uuid NOT NULL REFERENCES demands(id) ON DELETE CASCADE,
  school_id uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  turma_id uuid NOT NULL REFERENCES turmas(id) ON DELETE CASCADE,
  teacher_id uuid REFERENCES users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'analise_pedagogica' CHECK (status IN (
    'analise_pedagogica','aguardando_coordenacao','nao_adequada','nao_autorizado',
    'aprovado','em_andamento','entregue','validado','concluido')),
  ped_relevance text NOT NULL DEFAULT '',
  ped_safety text NOT NULL DEFAULT '',
  ped_feasibility text NOT NULL DEFAULT '',
  ped_curriculum text NOT NULL DEFAULT '',
  ped_at timestamptz,
  coord_note text NOT NULL DEFAULT '',
  coord_by uuid REFERENCES users(id) ON DELETE SET NULL,
  coord_at timestamptz,
  started_at timestamptz,
  concluded_at timestamptz,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (demand_id, turma_id)
);

CREATE TABLE project_members (
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (project_id, student_id)
);

CREATE TABLE milestones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title text NOT NULL,
  due_date date NOT NULL,
  done boolean NOT NULL DEFAULT false,
  position int NOT NULL DEFAULT 0
);

CREATE TABLE submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  version int NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  link text NOT NULL,
  file_name text,
  file_data bytea,
  file_size int,
  file_type text,
  submitted_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, version)
);

-- Validação pedagógica (professor) e retorno da empresa. Sem notas numéricas nem comparação.
CREATE TABLE reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  submission_id uuid REFERENCES submissions(id) ON DELETE SET NULL,
  author_id uuid REFERENCES users(id) ON DELETE SET NULL,
  role text NOT NULL CHECK (role IN ('teacher','company')),
  kind text NOT NULL CHECK (kind IN ('validacao','ajustes','retorno')),
  criteria jsonb,            -- { "critério": "atendeu" | "parcial" | "em_desenvolvimento" }
  competencies text[] NOT NULL DEFAULT '{}',
  text text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  author_id uuid REFERENCES users(id) ON DELETE SET NULL,
  text text NOT NULL,
  masked boolean NOT NULL DEFAULT false,
  hidden boolean NOT NULL DEFAULT false,
  hidden_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  student_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, project_id)
);

-- Interesse da empresa em futuras oportunidades: dirigido à escola, nunca ao estudante.
CREATE TABLE company_interests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, company_id)
);

CREATE TABLE opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  title text NOT NULL,
  area text NOT NULL,
  city text NOT NULL,
  requirements text[] NOT NULL DEFAULT '{}',
  description text NOT NULL,
  workload text NOT NULL DEFAULT '',
  selection_info text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','ajustes','publicada','encerrada','rejeitada')),
  mod_note text NOT NULL DEFAULT '',
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE opportunity_interests (
  opportunity_id uuid NOT NULL REFERENCES opportunities(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (opportunity_id, student_id)
);

-- Pedidos de correção ou remoção de informações (LGPD)
CREATE TABLE correction_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  school_id uuid REFERENCES schools(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('correcao','remocao','exclusao_conta')),
  text text NOT NULL,
  status text NOT NULL DEFAULT 'aberto' CHECK (status IN ('aberto','resolvido')),
  response text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  text text NOT NULL,
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE,
  school_id uuid REFERENCES schools(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta','resolvida')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Registro de acessos e ações relevantes
CREATE TABLE audit_log (
  id bigserial PRIMARY KEY,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  user_label text NOT NULL DEFAULT '',
  role text,
  action text NOT NULL,
  target_type text,
  target_id uuid,
  detail text NOT NULL DEFAULT '',
  school_id uuid,
  ip text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON audit_log (created_at DESC);
CREATE INDEX ON audit_log (school_id, created_at DESC);

CREATE TABLE "session" (
  "sid" varchar NOT NULL PRIMARY KEY,
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL
);
CREATE INDEX "IDX_session_expire" ON "session" ("expire");

CREATE INDEX ON project_members (student_id);
CREATE INDEX ON projects (demand_id);
CREATE INDEX ON projects (school_id);
CREATE INDEX ON submissions (project_id);
CREATE INDEX ON posts (project_id);
CREATE INDEX ON demands (company_id);

INSERT INTO courses (name) VALUES ('Informática'),('Desenvolvimento de Sistemas'),('Informática para Internet'),('Redes de Computadores');
