// Teste de ponta a ponta da API com PostgreSQL real (o banco indicado é APAGADO).
// Uso: npm run build && DATABASE_URL=postgres://.../banco_de_teste npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

process.env.SESSION_SECRET ||= 'teste-'.repeat(8);
delete process.env.DEMO_MODE;
const { createApp } = await import('../dist/index.js');
const { migrate } = await import('../dist/migrate.js');
const { pool } = await import('../dist/db.js');
const { hashPassword } = await import('../dist/auth.js');

let server, base;
before(async () => {
  await pool.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await migrate();
  await pool.query(`INSERT INTO users (role,name,login,email,password_hash,must_change_password) VALUES ('admin','Admin Teste','admin@teste.br','admin@teste.br',$1,true)`, [await hashPassword('SenhaAdmin123')]);
  server = createApp().listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { server?.close(); await pool.end(); });

function client() {
  let cookie = '';
  const call = async (method, path, body, isForm) => {
    const headers = { 'X-Requested-With': 'conectatec' };
    if (cookie) headers.cookie = cookie;
    if (body && !isForm) headers['Content-Type'] = 'application/json';
    const r = await fetch(base + path, { method, headers, body: isForm ? body : body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    const ct = r.headers.get('content-type') || '';
    return { status: r.status, data: ct.includes('json') ? await r.json() : await r.text() };
  };
  return { get: (p) => call('GET', p), post: (p, b) => call('POST', p, b || {}), put: (p, b) => call('PUT', p, b), form: (p, f) => call('POST', p, f, true) };
}
const plus = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
async function loginChange(c, login, pw, newPw) {
  let r = await c.post('/api/auth/login', { login, password: pw }); assert.equal(r.status, 200, JSON.stringify(r.data));
  r = await c.post('/api/auth/change-password', { current: pw, newPassword: newPw }); assert.equal(r.status, 200, JSON.stringify(r.data));
}
function pdfForm(title) {
  const fd = new FormData();
  fd.set('title', title); fd.set('description', 'Página responsiva com produtos, horários e contato comercial da loja do bairro.');
  fd.set('link', 'https://github.com/exemplo/site'); fd.set('confirm', 'true');
  fd.set('file', new Blob([Buffer.from('%PDF-1.4\n%teste\n')], { type: 'application/pdf' }), 'relatorio.pdf');
  return fd;
}

test('fluxo institucional completo com permissões', async () => {
  const admin = client();
  await loginChange(admin, 'admin@teste.br', 'SenhaAdmin123', 'NovaSenha2026');

  // não existe cadastro independente de estudante
  assert.equal((await client().post('/api/auth/register/student', { name: 'X' })).status, 404);
  // versão oficial: não existe modo demonstração
  assert.equal((await client().get('/api/demo')).status, 404);
  assert.equal((await client().post('/api/demo/reset')).status, 404);

  // escola solicita acesso institucional
  const school = client();
  let r = await school.post('/api/auth/register/school', { schoolName: 'CETI Exemplo Teste', city: 'Teresina', inep: '22012345', name: 'Maria Coordenadora', role: 'Coordenadora pedagógica', email: 'coord@escola.br', password: 'Escola2026', terms: true });
  assert.equal(r.status, 201); assert.equal(r.data.school.status, 'pendente');
  assert.equal((await school.post('/api/school/teachers', { name: 'Márcia Oliveira', email: 'marcia@escola.br' })).status, 403, 'escola pendente não cadastra');
  const schoolId = r.data.school.id;
  assert.equal((await admin.post(`/api/admin/schools/${schoolId}/status`, { status: 'aprovada' })).status, 200);

  r = await school.post('/api/school/teachers', { name: 'Márcia Oliveira', email: 'marcia@escola.br' }); assert.equal(r.status, 201);
  const teacherPw = r.data.temporaryPassword;
  let people = (await school.get('/api/school/people')).data;
  const teacherId = people.teachers[0].id;
  assert.equal((await school.post('/api/school/turmas', { course: 'Informática', year: '3ª série', letter: 'a', teacherId })).status, 201);
  people = (await school.get('/api/school/people')).data;
  const turmaId = people.turmas[0].id;
  r = await school.post('/api/school/students', { name: 'Ana Clara Sousa', studentCode: '2026001', turmaId, isMinor: true }); assert.equal(r.status, 201);
  const anaCred = r.data.credentials[0]; assert.equal(anaCred.login, 'ana.sousa');
  r = await school.post('/api/school/students/batch', { turmaId, isMinor: true, lines: 'Bruno Lima Carvalho; 2026002\nCamila Rodrigues Araújo; 2026003\nDavi Rocha Monteiro; 2026004' });
  assert.equal(r.status, 201); assert.equal(r.data.credentials.length, 3);
  const creds = [anaCred, ...r.data.credentials];

  // empresa
  const co = client();
  r = await co.post('/api/auth/register/company', { name: 'Cajuína Digital', sector: 'Tecnologia', city: 'Teresina', description: 'Agência de sites para pequenos negócios do Piauí, com foco em comércio local.', responsibleName: 'Pedro Responsável', email: 'empresa@teste.br', password: 'Empresa2026', terms: true });
  assert.equal(r.status, 201);
  const dBody = { title: 'Página institucional para mercearia', need: 'A mercearia não tem presença na internet e os clientes perguntam horários por telefone.', objectives: 'Criar uma página simples e responsiva.', expectedResults: 'Página publicada e guia de atualização.', techs: 'HTML, CSS', area: 'Informática', suggestedDeadline: plus(30), hours: 24, maxProjects: 1, criteria: 'Funcionamento no celular\nOrganização do código\nClareza', scopeDeclared: true };
  assert.equal((await co.post('/api/company/demands', dBody)).status, 403, 'empresa não verificada');
  const coId = (await admin.get('/api/admin/companies')).data[0].id;
  assert.equal((await admin.post(`/api/admin/companies/${coId}/status`, { status: 'aprovada' })).status, 200);
  assert.equal((await co.post('/api/company/demands', { ...dBody, hours: 120 })).status, 400, 'escopo grande deve ser redimensionado');
  assert.equal((await co.post('/api/company/demands', { ...dBody, scopeDeclared: false })).status, 400);
  r = await co.post('/api/company/demands', dBody); assert.equal(r.status, 201);
  const demandId = r.data.id;
  assert.equal((await client().get('/api/demands')).data.length, 0, 'não aparece antes da moderação');
  assert.equal((await admin.post(`/api/admin/demands/${demandId}/moderation`, { status: 'disponivel' })).status, 200);
  assert.equal((await client().get('/api/demands')).data.length, 1);

  // empresa não pesquisa estudantes nem acessa áreas escolares
  assert.equal((await co.get('/api/school/people')).status, 403);
  assert.equal((await co.get('/api/teacher/dashboard')).status, 403);

  // professor: análise pedagógica
  const tc = client();
  await loginChange(tc, 'marcia@escola.br', teacherPw, 'Professora2026');
  r = await tc.post('/api/projects', { demandId, turmaId }); assert.equal(r.status, 201);
  const pid = r.data.id;
  assert.equal((await co.get(`/api/projects/${pid}`)).status, 403, 'empresa só acompanha após autorização');
  assert.equal((await tc.post(`/api/projects/${pid}/pedagogical`, { decision: 'favoravel', relevance: 'curta' , safety: 'x', feasibility: 'y' })).status, 400);
  r = await tc.post(`/api/projects/${pid}/pedagogical`, { decision: 'favoravel', relevance: 'Trabalha HTML e CSS do bimestre.', safety: 'Sem dados pessoais; mural mediado.', feasibility: 'Cabe em 6 aulas práticas.', curriculum: 'HTML e CSS' });
  assert.equal(r.data.status, 'aguardando_coordenacao');
  assert.equal((await tc.post(`/api/projects/${pid}/coordination`, { decision: 'autorizar' })).status, 403, 'professor não autoriza pela escola');
  assert.equal((await school.post(`/api/projects/${pid}/coordination`, { decision: 'autorizar', note: 'Autorizado.' })).status, 200);

  // organização: autorização dos responsáveis precisa estar registrada
  const studs = (await school.get('/api/school/people')).data.students;
  const memberIds = studs.filter((s) => s.name !== 'Davi Rocha Monteiro').map((s) => s.id);
  const ms = [{ title: 'Primeira versão', dueDate: plus(10) }, { title: 'Entrega final', dueDate: plus(25) }];
  r = await tc.post(`/api/projects/${pid}/organize`, { members: memberIds, milestones: ms }); assert.equal(r.status, 400);
  for (const s of studs) assert.equal((await school.put(`/api/school/students/${s.id}`, { consentStatus: 'registrado' })).status, 200);
  r = await tc.post(`/api/projects/${pid}/organize`, { members: memberIds, milestones: ms }); assert.equal(r.status, 200, JSON.stringify(r.data));

  // estudantes
  const ana = client(); await loginChange(ana, creds[0].login, creds[0].temporaryPassword, 'Estudante2026');
  const davi = client(); await loginChange(davi, creds[3].login, creds[3].temporaryPassword, 'Estudante2026');
  r = await ana.get('/api/student/dashboard'); assert.equal(r.data.projects.length, 1);
  r = await davi.get(`/api/projects/${pid}`); assert.equal(r.data.access, 'turma'); assert.equal(r.data.submissions.length, 0);
  assert.equal((await davi.get(`/api/projects/${pid}/posts`)).status, 403, 'fora da equipe não usa o mural');
  r = await co.get(`/api/projects/${pid}`); assert.equal(r.status, 200); assert.equal(r.data.team.length, 0, 'empresa não vê nomes'); assert.equal(r.data.teamCount, 3);

  // mural com telefone → ocultado
  r = await ana.post(`/api/projects/${pid}/posts`, { text: 'Meu número é 86 99999-1234' }); assert.equal(r.data.masked, true);
  r = await co.get(`/api/projects/${pid}/posts`); assert.ok(r.data.posts[0].text.includes('[contato removido]')); assert.equal(r.data.posts[0].author, 'Estudante da equipe');
  const postId = (await tc.get(`/api/projects/${pid}/posts`)).data.posts[0].id;
  assert.equal((await ana.post(`/api/posts/${postId}/hide`)).status, 403);
  assert.equal((await tc.post(`/api/posts/${postId}/hide`)).data.hidden, true);
  assert.equal((await co.get(`/api/projects/${pid}/posts`)).data.posts.length, 0, 'mensagem oculta some para a empresa');

  // entregas
  const bad = new FormData(); bad.set('title', 'Site'); bad.set('description', 'x'.repeat(50)); bad.set('link', 'https://a.b'); bad.set('confirm', 'true');
  bad.set('file', new Blob([Buffer.from('MZ executavel')]), 'virus.pdf');
  assert.equal((await ana.form(`/api/projects/${pid}/submissions`, bad)).status, 400);
  assert.equal((await davi.form(`/api/projects/${pid}/submissions`, pdfForm('Site v1'))).status, 403, 'fora da equipe não entrega');
  r = await ana.form(`/api/projects/${pid}/submissions`, pdfForm('Site Mercearia v1')); assert.equal(r.status, 201, JSON.stringify(r.data));
  const sub1 = (await tc.get(`/api/projects/${pid}`)).data.submissions[0].id;
  assert.equal((await co.get(`/api/submissions/${sub1}/file`)).status, 403, 'empresa só vê resultado após validação');
  assert.equal((await tc.get(`/api/submissions/${sub1}/file`)).status, 200);

  // validação pedagógica: ajustes, nova versão, validação
  r = await tc.post(`/api/projects/${pid}/validation`, { decision: 'ajustes', text: 'Faltam os horários de domingo na página.' }); assert.equal(r.status, 200);
  r = await ana.form(`/api/projects/${pid}/submissions`, pdfForm('Site Mercearia v2')); assert.equal(r.status, 201);
  r = await tc.post(`/api/projects/${pid}/validation`, { decision: 'validar', text: 'Entrega completa e bem organizada pela equipe.', competencies: ['HTML e CSS', 'Trabalho em equipe'] }); assert.equal(r.status, 200);

  // retorno da empresa (sem notas numéricas)
  r = await co.post(`/api/projects/${pid}/company-feedback`, { criteria: { 'Funcionamento no celular': 'atendeu' }, text: 'Ótimo trabalho, muito útil para a loja.' }); assert.equal(r.status, 400);
  r = await co.post(`/api/projects/${pid}/company-feedback`, { criteria: { 'Funcionamento no celular': 10 }, text: 'Ótimo trabalho, muito útil para a loja.' }); assert.equal(r.status, 400);
  r = await co.post(`/api/projects/${pid}/company-feedback`, { criteria: { 'Funcionamento no celular': 'atendeu', 'Organização do código': 'atendeu', 'Clareza': 'parcial' }, text: 'Ótimo trabalho, muito útil para a loja.', interest: true, interestMessage: 'Teremos uma vaga de Jovem Aprendiz no próximo semestre.' });
  assert.equal(r.status, 200);
  assert.equal((await co.get(`/api/submissions/${sub1}/file`)).status, 200);

  // portfólio e certificado
  r = await ana.get('/api/student/portfolio'); assert.equal(r.data.projects.length, 1); assert.deepEqual(r.data.competencies, ['HTML e CSS', 'Trabalho em equipe']);
  const code = r.data.projects[0].certificate.code;
  r = await client().get(`/api/public/certificates/${code}`); assert.equal(r.data.studentName, 'Ana C.'); assert.equal(r.data.schoolName, 'CETI Exemplo Teste');
  assert.equal((await ana.put('/api/student/portfolio', { public: true })).status, 403, 'precisa de autorização da escola');
  const anaId = studs.find((s) => s.name === 'Ana Clara Sousa').id;
  await school.put(`/api/school/students/${anaId}`, { portfolioAllowed: true });
  r = await ana.put('/api/student/portfolio', { public: true }); assert.equal(r.status, 200);
  r = await client().get(`/api/public/portfolio/${r.data.publicSlug}`); assert.equal(r.status, 200); assert.equal(r.data.login, undefined); assert.equal(r.data.name, 'Ana C.');

  // interesse da empresa chega à escola
  r = await school.get('/api/school/dashboard'); assert.equal(r.data.interests.length, 1); assert.equal(r.data.flags.length, 1);

  // pedidos de correção
  assert.equal((await ana.post('/api/me/requests', { kind: 'correcao', text: 'Meu sobrenome está incompleto no cadastro.' })).data.handledBy, 'escola');
  const reqId = (await school.get('/api/school/dashboard')).data.corrections[0].id;
  assert.equal((await school.post(`/api/school/corrections/${reqId}/resolve`, { response: 'Corrigido pela secretaria.' })).status, 200);
  assert.equal((await ana.get('/api/me/requests')).data[0].status, 'resolvido');

  // escola só gerencia a própria escola
  const other = client();
  await other.post('/api/auth/register/school', { schoolName: 'Outra Escola Teste', city: 'Picos', name: 'José Diretor', role: 'Diretor', email: 'dir@outra.br', password: 'Escola2026', terms: true });
  const otherId = (await admin.get('/api/admin/schools')).data.find((s) => s.name === 'Outra Escola Teste').id;
  await admin.post(`/api/admin/schools/${otherId}/status`, { status: 'aprovada' });
  assert.equal((await other.put(`/api/school/students/${anaId}`, { active: false })).status, 404);
  assert.equal((await other.get(`/api/projects/${pid}`)).status, 403);

  // registro de ações
  r = await admin.get('/api/admin/audit'); assert.ok(r.data.some((a) => a.action === 'Autorizou participação da turma'));
  assert.ok(r.data.some((a) => a.action === 'Validou a entrega pedagógica'));
});
